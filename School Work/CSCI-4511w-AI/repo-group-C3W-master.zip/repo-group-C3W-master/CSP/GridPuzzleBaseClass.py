import string

class GridPuzzleBaseClass:
    def createTable(self, size):
        newlist = []
        for i in string.ascii_uppercase[:size]:
            for j in string.digits[:size ]:
                newlist.append( i+j )
        return newlist

    def convertPair(self, pair):
        # This method takes in a [x,y] pair and returns a pair in the format  'A1'
        newPair = string.ascii_uppercase[pair[0]] + str(pair[1])
        return newPair

    def createDomains(self, size):
        newdict = dict()
        for var in list(self.neighbors.keys()):
            newdict[var] = list(range(1,size+1))
        return newdict

    def createTableNeighbors(self, size):
        # for table-based puzzles like KenKen, the neighbors are the other cells
        # in the the same row and column
        # this function creates a dictionary with the variables as keys, and the
        # values a list of variables
        # This function currently only works for up to 9 rows/columns.
        # It could easily be changed to do more.

        # first we set up the keys
        newdict = dict()
        variables = self.createTable(size)
        for var in variables:
            newdict[var] = []
        for var1 in variables:
            for var2 in variables:
                if var1 != var2 and ( (var1[0] == var2[0]) or (var1[1] == var2[1]) ):
                    newdict[var1].append(var2)
        return newdict

    def generateAllDiff(self, constraintlist, neighbors):
        # given a constraint list, and a dictionary of vars for keys and neighbors for values,
        # the method adds the lambda 'f' to the dictionary of constraints for each var,neighbor pair
        f = lambda a: a[0] != a[1]

        for k in list(neighbors.keys()):
            for neighbor in neighbors[k]:
                lambda_text = k + " != " + neighbor
                constraintlist[k].append( ((k,neighbor), f, lambda_text) )
#j                if self.DEBUG:
 #                   print("new rule:", lambda_text)

    def setupConstraintsDictionary(self, neighbors):
        # This function takes a list of neigbors and creates a dictionary
        # with keys consisting of variables
        # and values equalling an empty list
        constraints = dict()
        for k in list(neighbors.keys()):
            constraints[k] = []
        return constraints

    def setupPuzzle(self, size, debug = False):
        self.DEBUG = debug
        self.neighbors = self.createTableNeighbors(size)
        self.constraints = self.setupConstraintsDictionary(self.neighbors)
        self.generateAllDiff(self.constraints, self.neighbors)
        self.domains = self.createDomains(size)

    def puzzle(self):
        # A utility function that returns the main 3 parameters as a tuple
        return (self.neighbors, self.domain, self.constraints)

    def generateConstraintsKenKen(self, row):
        length = len(row)

        # row[2] is 1st variable
        # row[3] is 2nd variable
        # row[4] is 3rd variable
        # row[0] is the operation
        # row[1] is the constant

        if length == 3:
            a = list(row[2])
            if self.convertPair(row[2]) not in self.constraints:
                self.constraints[self.convertPair(row[2])] = []
            self.constraints[self.convertPair(row[2])].append(([(self.convertPair(row[2]))],
                                                              lambda a: self.OpKenKen(row[0], a[0], row[1])))
        if length == 4:
            a = list((row[2], row[3]))
            if self.convertPair(row[2]) not in self.constraints:
                self.constraints[self.convertPair(row[2])] = []
            if self.convertPair(row[3]) not in self.constraints:
                self.constraints[self.convertPair(row[3])] = []
            self.constraints[self.convertPair(row[2])].append(((self.convertPair(row[2]), self.convertPair(row[3])),
                                                               (lambda a: self.OpKenKen(row[0], [a[0], a[1]], row[1]))))
            self.constraints[self.convertPair(row[3])].append(((self.convertPair(row[3]), self.convertPair(row[2])),
                                                               (lambda a: self.OpKenKen(row[0], [a[0], a[1]], row[1]))))
        if length == 5:
            a = list((row[2], row[3], row[4]))
            if self.convertPair(row[2]) not in self.constraints:
                self.constraints[self.convertPair(row[2])] = []
            if self.convertPair(row[3]) not in self.constraints:
                self.constraints[self.convertPair(row[3])] = []
            if self.convertPair(row[4]) not in self.constraints:
                self.constraints[self.convertPair(row[4])] = []
            self.constraints[self.convertPair(row[2])].append(((self.convertPair(row[2]), self.convertPair(row[3]),
                                                                self.convertPair(row[4])), (
                                                               lambda a: self.OpKenKen(row[0], [a[0], a[1], a[2]],
                                                                                       row[1]))))
            self.constraints[self.convertPair(row[3])].append(((self.convertPair(row[3]), self.convertPair(row[2]),
                                                                self.convertPair(row[4])), (
                                                               lambda a: self.OpKenKen(row[0], [a[0], a[1], a[2]],
                                                                                       row[1]))))
            self.constraints[self.convertPair(row[4])].append(((self.convertPair(row[4]), self.convertPair(row[2]),
                                                                self.convertPair(row[3])), (
                                                               lambda a: self.OpKenKen(row[0], [a[0], a[1], a[2]],
                                                                                       row[1]))))
        if length == 6:
            a = list((row[2], row[3], row[4], row[5]))
            if self.convertPair(row[2]) not in self.constraints:
                self.constraints[self.convertPair(row[2])] = []
            if self.convertPair(row[3]) not in self.constraints:
                self.constraints[self.convertPair(row[3])] = []
            if self.convertPair(row[4]) not in self.constraints:
                self.constraints[self.convertPair(row[4])] = []
            if self.convertPair(row[5]) not in self.constraints:
                self.constraints[self.convertPair(row[5])] = []
            self.constraints[self.convertPair(row[2])].append(((self.convertPair(row[2]), self.convertPair(row[3]),
                                                                self.convertPair(row[4]), self.convertPair(row[5])), (
                                                               lambda a: self.OpKenKen(row[0], [a[0], a[1], a[2], a[3]],
                                                                                       row[1]))))
            self.constraints[self.convertPair(row[3])].append(((self.convertPair(row[3]), self.convertPair(row[2]),
                                                                self.convertPair(row[4]), self.convertPair(row[5])), (
                                                               lambda a: self.OpKenKen(row[0], [a[0], a[1], a[2], a[3]],
                                                                                       row[1]))))
            self.constraints[self.convertPair(row[4])].append(((self.convertPair(row[4]), self.convertPair(row[2]),
                                                                self.convertPair(row[3]), self.convertPair(row[5])), (
                                                               lambda a: self.OpKenKen(row[0], [a[0], a[1], a[2], a[3]],
                                                                                       row[1]))))
            self.constraints[self.convertPair(row[5])].append(((self.convertPair(row[5]), self.convertPair(row[2]),
                                                                self.convertPair(row[3]), self.convertPair(row[4])), (
                                                                   lambda a: self.OpKenKen(row[0], [a[0], a[1], a[2], a[3]],
                                                                                           row[1]))))

    def OpKenKen(self, op, values, result):
        if op == '+' and len(values) == 2:
            return values[0] + values[1] == result
        if op == '-' and len(values) == 2:
            return abs(values[0] - values[1]) == result
        if op == '*' and len(values) == 2:
            return values[0] * values[1] == result
        if op == '/' and len(values) == 2:
            return values[0] // values[1] == result or values[1] // values[0] == result
        if op == 'abs':
            return abs(values) == result
        if op == '+' and len(values) == 3:
            return values[0] + values[1] + values[2] == result
        if op == '*' and len(values) == 3:
            return values[0] * values[1] * values[2] == result
        if op == '+' and len(values) == 4:
            return values[0] + values[1] + values[2] + values[3] == result
        if op == '*' and len(values) == 4:
            return values[0] * values[1] * values[2] * values[3] == result

    def kenkenSetup(self, size, puzzle, solution):

        self.setupPuzzle(size)

        for row in puzzle:
            #print(row)
            self.generateConstraintsKenKen(row)

        return (self.neighbors, self.domains, self.constraints)
