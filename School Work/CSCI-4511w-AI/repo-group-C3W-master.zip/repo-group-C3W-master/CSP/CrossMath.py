from CSPtestCases import *
import string

import GridPuzzleBaseClass

import operator

opDict = {'+': operator.add,
       '-': operator.sub,
       '*': operator.mul,
       '/': operator.truediv,
       '==': operator.eq,
       '!=': operator.ne,
       '<': operator.lt,
       '<=': operator.le,
       '>': operator.gt,
       '>=': operator.ge,
       'abs': operator.abs,
       '^': operator.pow
       }


def crossmathSetup(size, puzzle, solution):
    global domain
    domain = {}
    global constraints
    #todo chainged constraints to a list because we can have (A1,A2,A3) allDiff & they have an equation constriant.
    #todo doesn't make sense to have a dictionary if we can have multiple constraints for a given set of variables(key)
    constraints = {}
    #constraints = AC3.setupConstraintsDictionary(neighbors)
    count = 1 #Used to count to width size of the array
    char = 'A' #Used to name our variables
    char_count = 65
    values = [] #This array holds all possible value of the variables
    puzzle_array = []
    temparray = []
    ops_array = [] #This array holds all the operations

    for i in range (1, (size[0]*size[1])+1):
        values.append(i)

    for i in range(0, (size[0]*size[1])):
        if count > size[0]:
            count = 1
            char_count += 1
            char = chr(char_count)
            puzzle_array.append(temparray)
            temparray = []

        string = char
        string += str(count)
        temparray.append(string)
        domain.update({string:values})
        count = count + 1

    puzzle_array.append(temparray)
    temparray = []

    char_count = 65
    string = "S"
    solveRows=[]
    solveCols =[]
    for i in range(0,size[0]):
        solveRows.append(puzzle[0][i][1])
        solveCols.append(puzzle[1][i][1])

        for j in range(0,size[1]-1):
            temparray.append(puzzle[0][i][0][j])
        ops_array.append(temparray)
        temparray = []

    for i in range(0,size[0]):
        for j in range(0,size[1]-1):
            temparray.append(puzzle[1][i][0][j])
        ops_array.append(temparray)
        temparray = []


    tempvalues =0

    #todo, this should be something like generateConstraint(int: size, puzzle_array, ops_array
    for i in range(size[0]):
        generateEquationConstraint(size, puzzle_array[i], ops_array[i], solveRows[i])
    transpose = [list(x) for x in zip(*puzzle_array)]
    puzzle_columns = transpose
    for j in range(size[1]):
        generateEquationConstraint(size, puzzle_columns[j], ops_array[size[1] + j], solveCols[j])

    generateAllDiffConstraint(puzzle_array)
    # print(puzzle_array)
    # print(ops_array)
    # print(solveRows)
    # print(solveCols)
    # print("Domains")
    # for d in domain:
    #     print((str(d), str(domain[d])))
    # print("Constraints")
    newconstraints = {}
    for c in constraints:
        newconstraints[str(c)] = (c, constraints[c])

    # for c in newconstraints:
    #     print(str(c), str(newconstraints[c]))

    neighbors = GridPuzzleBaseClass.GridPuzzleBaseClass().createTableNeighbors(size[0])
    # print(neighbors)
    return (neighbors, domain, newconstraints)


def generateEquationConstraint(size, names, ops, solution):
    global constraints
    global domain
    length = len(ops)
    if length == 1:
        #changed
        key = (names[0],names[1])
        if key in constraints:
            oldlambda = constraints[key]
            constraints[key] = lambda x,y: (opDict[ops[0]](x,y) == solution) and oldlambda(x,y)
        else:
            constraints[key] = lambda x,y: (opDict[0](x,y) == solution)

        #todo REMOVE THIS
        #raise RuntimeError('Not implemented correctly.  See lenght ==2')
    if length == 2:
        key = (names[0], names[1], names[2])
        if key in constraints:
            oldlambda = constraints[key]
            constraints[key] = lambda x,y,z: (opDict[ops[1]](opDict[ops[0]](x,y), z) == solution) and oldlambda(x,y,z)
        else:
            constraints[key] = lambda x,y,z: opDict[ops[1]](opDict[ops[0]](x,y), z) == solution

    if length == 3:
        key = (names[0], names[1], names[2], names[3])
        if key in constraints:
            oldlambda = constraints[key]
            constraints[key] = lambda w,x,y,z: (opDict[ops[2]](opDict[ops[1]](opDict[ops[0]](w,x),y),z) == solution) and oldlambda(w,x,y,z)
        else:
            constraints[key] = lambda w,x,y,z: opDict[ops[2]](opDict[ops[1]](opDict[ops[0]](w,x),y),z) == solution

    if length == 4:
        key = (names[0], names[1], names[2], names[3], names[4])
        if key in constraints:
            oldlambda = constraints[key]
            constraints[key] = lambda v,w,x,y,z: (opDict[ops[3]](opDict[ops[2]](opDict[ops[1]](opDict[ops[0]](v,w),x),y),z) == solution) and oldlambda(w,x,y,z)
        else:
            constraints[key] = lambda v,w,x,y,z: opDict[ops[3]](opDict[ops[2]](opDict[ops[1]](opDict[ops[0]](v,w),x),y),z) == solution

    if length > 4:
        # newVariable = str(names[0]) + str(names[1])
        # domain[newVariable] = generatedomain(size,ops,solution)
        # constraints([newVariable,names[2]]).append(lambda x,y: HandleOperation([x,y],ops[0],solution))
        # generateEquationConstraint(size,names[2:].appendleft(newVariable), ops[1:],solution)
        # #todo REMOVE THIS
        raise RuntimeError('Not an expected length as mentioned in writeup')


def generateAllDiffConstraint(puzzle_array):
    global constraints
    global domain
    keylist = sorted(list(domain.keys()))
    for i in range(len(domain)):
        for j in range(i+1, len(domain)):
            k1 = keylist[i]
            k2 = keylist[j]
            key = (k1, k2)
            if key in constraints:
                oldlambda = constraints[key]
                constraints[key] = lambda x, y: (x != y) and oldlambda(x,y)
            else:
                constraints[key] = lambda x,y: x != y


def generatedomain(size,ops,solution):
    temparray = []
    if ops[0] == '+':
        for i in range(0,((2*pow(size,2)-1))):
            temparray.append(i)
            return temparray
    if ops[0] == '-':
        for i in range(-1*size,2*size):
            temparray.append(i)
            return i
    if ops[0] == '*':
        for i in range(0, (pow(size,4))):
            temparray.append(i)
            return temparray
    if ops[0] == '/':
        for i in range(0, pow(size,2)):
            temparray.append(i)
            return temparray



def HandleOperation(values, ops, result):
    if(ops == '+'):
        return values[0] + values[1] == result
    elif(ops == '*'):
        return values[0] * values[1] == result
    elif(ops == '-'):
        return values[0] - values[1] == result
    elif(ops == '/'):
        return values[0] / values[1] == result

if __name__ == '__main__':
    puzzle =   [
        [[['+', '-' ], 8 ],
         [['*', '/' ], 2 ],
         [['*', '-' ], 5 ]],
        [[['/','-' ], 3 ],
         [['+','-' ], 7 ],
         [['+','+' ], 16 ]]
        ]
    # crossmathSetup([3,3],puzzle,0)
    puzzle2 =   [
        [[['*', '*', '*'], 22880],
         [['+', '*', '-'], 22],
         [['+', '-', '-'], -19],
         [['*', '+', '+'], 37] ] ,
        [[['*', '+', '*'], 69],
         [['+', '*', '+'], 186],
         [['*', '*', '-'], 688],
         [['*', '*', '-'], 1553]]
        ]
    crossmathSetup([4,4],puzzle2,0)
