# Benji and Noah's implementation of CSP
# Can be use either Mac inference or forward checking inference depending on initial inputs.
from copy import deepcopy
from collections import deque
import sys,os
sys.path.append( os.path.realpath('..' + os.sep + '..') + os.sep + "class-repo" + os.sep + 'projectClasses' )

import CSPclasses
from CSPtestCases import *
import collections
import AC3




class BacktrackCSP:
    def __init__(self, neighbors, domains, constraints, size, inferenceType):
        # the backtracker solver takes as a parameter a puzzle class that provides the following members:
        #	self.neighbors,, a dictionary where:
        #		the keys are variables
    	#		the values are lists of neighbors of each variable
        #	self.domain, a dictionary where:
        #               the keys are the variables
        #               the values are domain of the variables
        # 	self.constraints , a dictionary of constraints where,
        #		where the key is a single varible
    	#		and the value is a pair of (variables, constraint function)
        #   inferenceType which decides the inference used (MAC and Forward Checking are supported)
        self.neighbors = neighbors
        self.domain = domains
        # convert stupid constraints into our original idea.
        oldconstraints = {}
        for c in constraints:
            #changed
            k = constraints[c][0]
            v = constraints[c][1]
            oldconstraints[k] = v
        self.newconstraints = constraints
        self.oldconstraints = oldconstraints
        self.solved = False
        self.size = size
        self.inferenceType = inferenceType

    def solve(self):
        if self.inferenceType == CSPclasses.AlgoType.backtrackMAC:
            return self.Backtracking_Search()
        if self.inferenceType == CSPclasses.AlgoType.backtrackFC:
            return self.Backtracking_Search()
        else:
            print('Error, invalid provided inferenceType')
            raise RuntimeError

    def printSolution(self):
        ordered = collections.OrderedDict(sorted(self.sol.items()))
        print(ordered)

    # inspired by pg 215 of textbook. Artifiscal blah blah 3rd ediition
    # function Backtracking-Search(csp) returns a solution, or afailure
    def Backtracking_Search(self):
        #   return Backtrack({}, csp)
        self.sol = self.Backtrack(dict(), self.inferenceType)
        if self.sol == None:
            self.sol = []
        return self.sol
    # inspired by pg 215 of textbook. Artifiscal blah blah 3rd ediition
    #function Backtrack(assignment, csp) returns a solution or failure
    def Backtrack(self, assignment, inferenceType):
        # if assignment is complete then return assignment
        if self.isComplete(assignment):
            return assignment
        # var = Select-Unassigned-Variable(csp, assignment)
        var = self.Select_Unassigned_Variable(assignment)
        oldAssignment = deepcopy(assignment)
        # for each value in Order-Domain-Values(var, assignment, csp) do:
        for value in self.Order_Domain_Values(var, assignment):
            if DEBUG: print('Working on var-valpair:' + str((var,value)) + ' with assignment:' + str(assignment))
            #if value is consisten with assignment then
            if self.isConsistent(var, value, assignment):
                #add {var = value} to assignment
                if var in assignment.keys():
                    raise RuntimeError(' Something broke in our assignment dict:' + str(assignment) + str(var) + str(value))
                assignment[var] = [value]
                #inferences = Inference(csp,var,assignment)
                inferences = self.Inference(var, assignment, inferenceType)
                #if inference != failure then:
                if inferences != None:
                    #ads inferences to assignment
                    self.addInferencesToAssignment(inferences, assignment)
                    #result = Backtrack(assignment, csp)
                    result = self.Backtrack(assignment, inferenceType)
                    #if result != failure then
                    if result != None:
                        #return result
                        return result
            #remove {var = value} and inferences from assignment
            # todo: this might require cleanup of domain as well.
            # self.remove_var_eq_value_and_inferences(assignment, oldAssignment)
            assignment = deepcopy(oldAssignment)
        #end fore loop
        return None

    def isComplete(self, assignment):
        # if the domain is the same as the assignment then we are done.  everything is assigned a value
        # todo: check assumptions.  I assume that was will only add valid var=value to assign for valid values.  i.e no placeholders.
        # todo: check assumption is domain an associative array?
        if len(assignment.keys()) == len(self.domain.keys()):
            # Make sure that all our constraints are good with the assignment
            for constraint in self.oldconstraints:
                # constraint is [A1, A2, C3] for example., so we need to create a list of values
                values = []
                # lookup the value assigned to each variable in the constraint.
                for var in constraint:
                    values.append(assignment[var])
                #todo: I'm not sure how our constraints are defined so we might need to do something like fore val in values apply constraint to it until we get final fun which gives true or false
                # something like f = self.constraints[constraint](v1)
                #                f = f(v2)(v3)...
                try:
                    flattened_values = [item for sublist in values for item in sublist]
                #Todo: values should always be a list of lists of one element.  This error should never raise.
                except TypeError:
                    flattened_values = [values]
                if not self.oldconstraints[constraint](*flattened_values):
                    return False
            return True
        return False

    # just picks the first unassigned variable
    # todo: could be improved with minimum-remaining-values and degree heuristic.
    def Select_Unassigned_Variable(self, assignment):
        # domain contains our values.
        #todo: assumeing domain is ass. array
        domset = set(self.domain.keys())
        assignset = set(assignment.keys())
        diffset = domset - assignset
        diffset = sorted(diffset)
        if len(diffset) > 0: return diffset[0]
        raise KeyError('Passed in a full assignment or domain was corrupted: ' + 'domain:' + str(self.domain) + ' assignment:' + str(assignment))


    def isConsistent(self, var, value, assignment):
        # make sure value is in domain
        # trying to check if the domain's possible values for "var" contains "value"
        if value in self.domain[var]:
            # if this var is unassigned we're good.  or if the var is assigned & value is it's value.
            #validate all constraints.
            for c in self.oldconstraints:
                #c is our key ('A1', 'A2', 'A3') for example
                values = []
                for variable in c:
                    if variable == var:
                        val = value
                        values.append(val)
                    elif variable in assignment:
                        val = assignment[variable][0]
                        values.append(val)
                if len(values) != len(c):
                    continue
                elif not self.oldconstraints[c](*values):
                    # if we dont satisfy a constraint with this assignment, then we've failed.  This is not consistent.
                    return False
            return True
        return False

    #this just returns the domain for var.  todo: make it use least-constraining-value heuristic to order
    def Order_Domain_Values(self, var, assignment):
        return self.domain[var]

    def Inference(self, var, assignment, inferenceType):
        #If we have a complete assignment verify all constraints hold.  If any break then return NONE
        if (len(assignment.keys()) == len(self.domain.keys())) and not self.isComplete(assignment):
            return None

        if inferenceType == CSPclasses.AlgoType.backtrackFC:
            #whenever a vairable X is assigned, establishes arc consistency for it:
            # for each unassigned variable Y that is connected to X by a constraint, delete from Y's domain any value that is inconsisten with the value chosen for X
            inferredDomain = deepcopy(self.domain)
            for a in assignment:
                if isinstance(assignment[a], list):
                    inferredDomain[a] = assignment[a]
                else:
                    inferredDomain[a] = [assignment[a]]
            # get a list of all (varlist, constraint) for which this new var is a member.
            constraints = [(c,self.oldconstraints[c]) for c in self.oldconstraints if var in c]
            # now we need to test that
            for (vars, constraint) in constraints:
                # todo if len(vars) is >= 3 I have no idea how to only remove the right values.  skip for now
                if len(vars) >= 3:
                    continue
                try:
                    #2-ple of variables, one of them is the var we just assigned.
                    dom1 = inferredDomain[vars[0]]
                    dom2 = inferredDomain[vars[1]]
                    for x in dom1:
                        xSat = False
                        for y in dom2:
                            if(constraint(x,y)):
                                xSat = True
                        if(not xSat):
                            inferredDomain[vars[0]] = [a for a in inferredDomain[vars[0]] if a != x]
                    for y in dom2:
                        ySat = False
                        for x in dom1:
                            if(constraint(x,y)):
                                ySat = True
                        if not ySat:
                            inferredDomain[vars[1]] = [a for a in inferredDomain[vars[1]] if a != y]
                    #check if we have any empty lists, if so return none.
                    if inferredDomain[vars[0]] == [] or inferredDomain[vars[1]] == []:
                        return None
                except TypeError:
                    # single variable
                    # Test its domain for good values
                    newDomain = []
                    for val in inferredDomain[vars]:
                        #check if its a valid value for the constraint
                        if constraint(val):
                            newDomain.append(val)
                    if newDomain == []:
                        # Assigning "var" as we did breaks the constraints.
                        return None
                    #Update the inferred domain to the new restricted values.
                    inferredDomain[vars] = newDomain
            #Finished updating our inferredDomain
            # In doing so we haven't caused any Domain to be [] so we should just return our new inferred domain as our "inferences"
            return inferredDomain
        # BROKEN.  AC3.revise() errors with our input constraints.  Probably has something to do with neighbors indexing off A0 and we index our constraints
        # off of A1.  I have no clue where to begin to fix this.
        if inferenceType == CSPclasses.AlgoType.backtrackMAC:
            #creates an instance of AC3 to use the revise function
            MAC3 = AC3.AC3(self.neighbors, self.domain, self.newconstraints, self.size)
            #uses AC3.revise() which checks arc consistency returns true if changes are made
            if MAC3.revise(var):
                #searches through the new domains in MAC3.domains
                for dom in MAC3.domain:
                    if len(dom[1]) < 1:
                        return None

                inferredDomain = MAC3.domain
                return inferredDomain
            else:
                return None
        else:
            raise RuntimeError('Invalid inferenceType:' + inferenceType)

    def addInferencesToAssignment(self, inferences, assignment):
        #inferences is a combination of our assignment & our domain
        #So we want to add all the 1-length inferred values and add them to assignment
        #todo: maybe this function should modify our self.domain values.  We need to keep an old copy of domain then.
        for k in inferences:
            v = inferences[k]
            if len(v) == 1:
                assignment[k] = v

    def remove_var_eq_value_and_inferences(self, assignment, oldAssignment):
        pass


if __name__ == '__main__':
    DEBUG = True
    if DEBUG and False:
        print('running debug stuff')
        puzzle = [
            [[['+', '-'], 8],
             [['*', '/'], 2],
             [['*', '-'], 5]],
            [[['/', '-'], 3],
             [['+', '-'], 7],
             [['+', '+'], 16]]
        ]
        from CrossMath import *
        #changed
        neighbors, domain, constraints = crossmathSetup([3, 3], puzzle, 0)
        print(domain, constraints)
        import collections
        domain = collections.OrderedDict(sorted(domain.items()))
        constraints = collections.OrderedDict(sorted(constraints.items()))
        #todo TEST THIS SERIOUSLY IT DOESNT WORK AND ALWAYS THROWS AN ERROR
        backtracksolver = BacktrackCSP(neighbors = neighbors, domains=domain, constraints=constraints, size = 3, inferenceType= CSPclasses.AlgoType.backtrackFC)
        solution = backtracksolver.solve()
        print("SOLUTION ==== \n\n\n\n\n\n\n" + str(solution))
        # OrderedDict([('A1', [5]), ('A2', [6]), ('A3', [3]), ('B1', [1]), ('B2', [8]), ('B3', [4]), ('C1', [2]), ('C2', [7]), ('C3', [9])])


        puzzle2 = [
            [[['*', '*', '*'], 22880],
             [['+', '*', '-'], 22],
             [['+', '-', '-'], -19],
             [['*', '+', '+'], 37]],
            [[['*', '+', '*'], 69],
             [['+', '*', '+'], 186],
             [['*', '*', '-'], 688],
             [['*', '*', '-'], 1553]]
        ]
        neighbors, domain, constraints = crossmathSetup([4, 4], puzzle2, 0)
        print(domain, constraints)
        import collections

        domain = collections.OrderedDict(sorted(domain.items()))
        constraints = collections.OrderedDict(sorted(constraints.items()))
        # todo TEST THIS SERIOUSLY IT DOESNT WORK AND ALWAYS THROWS AN ERROR
        backtracksolver = BacktrackCSP(neighbors=neighbors, domains=domain, constraints=constraints,
                                       size=3, inferenceType=CSPclasses.AlgoType.backtrackFC)
        solution = backtracksolver.solve()
        print("SOLUTION ==== \n\n\n\n\n\n\n" + str(solution))
        #{'C4': [12], 'A2': [2], 'D2': [14], 'D4': [16], 'B2': [6], 'D1': [13], 'C2': [10], 'D3': [15], 'A1': [1], 'C1': [9], 'A4': [4], 'C3': [11], 'B3': [7], 'B1': [5], 'B4': [8], 'A3': [3]}
    if DEBUG:
        #test mac implementation
        print('running debug stuff')
        puzzle = [
            [[['+', '-'], 8],
             [['*', '/'], 2],
             [['*', '-'], 5]],
            [[['/', '-'], 3],
             [['+', '-'], 7],
             [['+', '+'], 16]]
        ]
        from CrossMath import *
        #changed
        neighbors, domain, constraints = crossmathSetup([3, 3], puzzle, 0)
        print(domain, constraints)
        import collections
        domain = collections.OrderedDict(sorted(domain.items()))
        constraints = collections.OrderedDict(sorted(constraints.items()))
        #todo TEST THIS SERIOUSLY IT DOESNT WORK AND ALWAYS THROWS AN ERROR
        backtracksolver = BacktrackCSP(neighbors = neighbors, domains=domain, constraints=constraints, size = 3, inferenceType= CSPclasses.AlgoType.backtrackMAC)
        solution = backtracksolver.solve()
        print("SOLUTION ==== \n\n\n\n\n\n\n" + str(solution))
        # OrderedDict([('A1', [5]), ('A2', [6]), ('A3', [3]), ('B1', [1]), ('B2', [8]), ('B3', [4]), ('C1', [2]), ('C2', [7]), ('C3', [9])])
