##     These classes are used to create instances of implementations,
##           then gather into "puzzlesImplemented" and "algosImplemented"
##     The scripts will read in 'puzzlesImplemented' and 'algosImplemented', then proceed to test each in the lists
##     Additionally, the status must NOT be set to "Incomplete" for it to be tested.

##    Nothing needs to be done to this file. See CSPsolver.py in team-staff or class-repo/CSP to use these


## THESE CLASSES SHOULD NOT BE MODIFIED ##
import enum
class PuzzleType( enum.Enum ):
  kenken = 1; futoshiki = 2; crypt = 3; crossmath = 4
  other = 5

puzzleNames = { PuzzleType.kenken: 'kenken',
                 PuzzleType.futoshiki: 'futoshiki',
                 PuzzleType.crypt: 'cryptarithmetic',
                 PuzzleType.crossmath: 'crossmath',
                 PuzzleType.other: 'other' }

class AlgoType( enum.Enum ):
  AC3 = 1; backtrackMAC = 2; backtrackFC = 3; mrv = 4; degreeHeuristic = 5
  other = 6

algoNames = { AlgoType.AC3: "AC3",
              AlgoType.backtrackMAC: 'backtracking with mac',
              AlgoType.backtrackFC: "backtracking with forward checking",
              AlgoType.mrv: 'Backtracking with Variable Ordering: MRV',
              AlgoType.degreeHeuristic: 'Backtracking with Variable Ordering: degree' }

class StatusType (enum.Enum ):
  Complete = 1
  Incomplete = 2  # will not compile
  Buggy = 3       # compiles but produces incorrect results
  NotSelected = 4

class Implementation :
  def __init__( self, impType, desc = None ) :
    self.impType = impType
    self.desc = desc
    self.authors = None
    self.status = StatusType.Complete
    self.bonus = True
    self.comments = None

class PuzzleImplementation( Implementation ):
  def __init__( self, impType, desc = None ):
    Implementation.__init__( impType, desc )
    if not impType in PuzzleType :
      self.impType = None
      self.comments = "Puzzle implementation type is unknown."
    else :
      self.impType = impType
    if self.impType :
      self.desc = puzzleNames[ self.impType ]
    else :
      self.desc = desc

class AlgoImplementation( Implementation ):
  def __init__( self, impType, desc = None ) :
    Implementation.__init__( impType, desc )
    if not impType in AlgoType :
      self.impType = None
      self.comments = "Algorithm implementation type is unknown."
    else :
      self.impType = impType
    if self.impType :
      self.desc = algoNames[ self.impType ]
    else :
      self.desc = desc

class InputPuzzleClass :
  def __init__ ( self, size, puzzle, pType, solution=None ) :
    self.size = size
    self.pType = pType
    self.puzzle = puzzle
    self.solution = solution

