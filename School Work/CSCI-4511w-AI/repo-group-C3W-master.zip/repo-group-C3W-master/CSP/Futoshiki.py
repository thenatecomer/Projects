from GridPuzzleBaseClass import GridPuzzleBaseClass
from CSPtestCases import *
import string

class Futoshiki(GridPuzzleBaseClass):
    def __init__(self, puzzle):
        self.size = puzzle.size[0]
        self.setupPuzzle(self.size, True)
        puzzle_rules = self.convertRules(puzzle.puzzle)

    def convertRules(self, oldRules):
        # This method converts the professor's futoshiki rules into the format used in GridPuzzleBaseClass
        # The incoming rules have the format
        # (constraint, var) or (op, var1, var2)

        # The internal rules format is either (var1, var2) meaning var1 < var2
        # or (var, constant)
        for rule in oldRules:
            if len(rule) == 2:
                constraint = rule[0]
                var = self.convertPair(rule[1])
                lambda_text = var + " == " + str(constraint)
                self.constraints[var].append( ( (var,), lambda a, val=constraint: a[0] == val, lambda_text) )
            elif rule[0] == '<':
                var1 = self.convertPair(rule[1])
                var2 = self.convertPair(rule[2])
                lambda1_text = var1 + " < " + var2
                lambda2_text = var2 + " > " + var1
                self.constraints[var1].append( ( (var1,var2), lambda a: a[0] < a[1] , lambda1_text) )
                self.constraints[var2].append( ( (var2,var1), lambda a: a[0] > a[1] , lambda2_text) )
            elif rule[0] == '>':
                var1 = self.convertPair(rule[1])
                var2 = self.convertPair(rule[2])
                lambda1_text = var1 + " > " + var2
                lambda2_text = var2 + " < " + var1
                self.constraints[var1].append( ( (var1,var2), lambda a: a[0] > a[1] ,lambda1_text  ) )
                self.constraints[var2].append( ( (var2,var1), lambda a: a[0] < a[1] ,lambda2_text ) )
            else:
                throw('Invalid Puzzle Format')

    def convertPair(self, pair):
        # This method takes in a [x,y] pair and returns a pair in the format  'A1'
        newPair = string.ascii_uppercase[pair[0]] + str(pair[1])
        return newPair

def futoshiki(puzzle):
    a = Futoshiki(puzzle)
    return a.puzzle()

# below is an example of the internal puzzle format, with the first entry the size,
# and the second the list of rules
#f1 = (4, [('C1','B1'), ('C1', 3), ('B2', 2), ('D3', 'D4'), ('C3', 'D3')] )
