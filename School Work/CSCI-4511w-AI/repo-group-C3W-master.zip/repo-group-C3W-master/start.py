import sys
import os
sys.path.append('algorithms')
sys.path.append('problems')
sys.path.append( os.path.realpath('..') + '/class-repo/projectClasses' )

#from algorithms.solverClass import Solver
#from GATowerSolver import *

from GAReportMaker import *
from GAMaze import *
from GAMazeSolver import *

