# a Genetic Algorithm implementation by Lee Williams, will4379
import random 
import math
from copy import deepcopy
from solverClass import Solver
from GATower import GAHanoi
from nQueens import NQueens

class BaseGA(Solver):
    # This is the base class for the GAs for NQueens, etc.
    #subclasses must self.generateInitialPopulation()
    #end_condition(), 

    def __init__(self):
        self.generation = 1
        self.num_born= 0
        self.mutation_rate = .01
        self.userid = "will4379"
        self.num_mutations = 0
        self.solution = None
        self.solve = self.full_generation_replacement

    def full_generation_replacement(self):
        self.generateInitialPopulation()
        while not self.endCondition():
            newpopulation = [self.makeBaby() for i in range(self.population_size)]
            self.population = newpopulation
            self.updateParameters()
        return self.solution

    def chooseParents(self):
        # This is a roulette wheel (weighted) selection method
        # It assumes that it should use the array in self.population
        # as the population source
        # It returns a pair of non-identical parents
         
        fitnesses = [self.getFitness(member) for member in self.population]
        parent_y = -1
        parent_x = parent_y
        while parent_x == parent_y:
            parent_y = self.rouletteSelect(fitnesses)
            if parent_x == -1:
                parent_x = parent_y
        return self.population[parent_x], self.population[parent_y]

    def endCondition(self):
        for member in self.population:
            if self.isGoal(member):
                self.solution = member
                return True
        return False

    def makeBaby(self):
        x,y = self.chooseParents()
        baby = self.onepointcrossover(x,y)
        self.num_born += 1
        return self.mutate(baby)

    def mutate(self, baby):
        baby = deepcopy(baby)   #makes sure prior copy survives, in case that is desired
                                #or class is from a partner who writes crappy code
        for i in range(len(baby)):
            if random.uniform(0,1) < self.mutation_rate:
                self.num_mutations += 1
                baby[i] = random.randint(0,self.size - 1)
                return baby
        return baby

    def onepointcrossover(self, x, y):
        length = len(x)
        # the following is for problems with variable length chromosomes
        if len(y) < len(x):
            length = len(y)
        cut = random.randint(0, length)
        return x[0:cut] + y[cut:]

    def print_state(self, state):
#       print("*** Solution Found ***")
        print("Generation :", self.generation)
        print("Number of Children:", self.num_born)
        print("Number of Mutations:", self.num_mutations)
        self.problem_instance.print_state(state)

    def rouletteSelect(self, fitnesses):
        # This function implements a weighted random selection 
        # it takes from a list of weights, which it does not alter
        # It returns the index of the chosen weight

        fitness_total = sum(fitnesses)
        index = -1
        running_total = 0
        num = random.randrange(1,fitness_total)
        while num > running_total:
            index += 1
            running_total += fitnesses[index]
        return index

    def updateParameters(self):
        # A place to put all changes that one might want to do at the end of a generation
        self.generation += 1

class GAQueens(BaseGA):
    #This class is specific to solve NQueens problems
    #It takes as parameter size=Number of Queens
    def __init__(self,size):
        super().__init__()
        self.problem_instance = NQueens(size)
        self.evaluation = self.problem_instance.evaluation
        self.isGoal = self.problem_instance.isGoal
        self.size = size
        self.population = []
        self.population_size = 2 * self.size


    def getFitness(self,state):
        #calculates and returns  fitness of the given state
        maxcollisions = self.size * (self.size -1) /2
        return int(math.pow(maxcollisions -self.evaluation(state), 2))

    def generateInitialPopulation(self):
        while len(self.population) < self.population_size:
            self.population.append(self.generateRandomSolution())

    def generateRandomSolution(self):
        solution = list(range(self.size))
        random.shuffle(solution)
        return solution

class GATower(BaseGA):
    #This class is to help with striving for an A
    #It existence is meant for to solving Towers of Hanoi,
    #but contains methods general to any problem with a variable
    # -length chromosone
    #It's constructor takes as a parameter size = number of disks
    #Each chromosone is a list representing a path
    #These chromosones must be processed into a puzzle state
    #before they can be evaluated as a state

    def __init__(self, size):
        super().__init__()
        self.problem_instance = GAHanoi(size)
        self.isGoal = self.problem_instance.isGoal
        self.size = size
        self.population_size =  5 * self.size ** 2
        self.population = []
        self.strictness = "partial"
#       self.strictness = "strict"
        self.factor = 1
        self.fitness_evaluation = self.fitnessMethod7
        self.generateInitialPopulation()
        
        # The following are to set up for adaptive operator fitness
        # I learned of this method in Handbook of Genetic Algotithms, L. Davis, 1991
        # The implementation is thoroughly independent
        self.operator_fitness = {}
        self.mutator_methods = [self.mutate, self.snip, self.truncate, self.extend, self.multiextend, self.innermutate]
        self.crossover_methods = [self.uniform_crossover, self.onepointcrossover]
        for i in self.mutator_methods + self.crossover_methods:
            self.operator_fitness[i] = 10
        self.operator_fitness[self.generateRandomChromosome] = 10
        self.solve = self.evolving_operator_fitness

    def general_solve(self):
        while not self.end_condition():
            self.fillpopulation()

    def evolving_operator_fitness(self):
        # First we will sort the population by fitness,
        # Then trim off the worst members
        
        while not self.end_condition():
            self.population.sort(key = lambda member : self.getFitness(member))
            self.population.reverse()
            fitnesses = [self.getFitness(member) for member in self.population]
            mean_fitness = sum(fitnesses) // len(fitnesses)
            while ((fitnesses[-1] < mean_fitness // self.factor)
                    or (len(self.population) + 4 > self.population_size)):
                self.population.pop()
                fitnesses.pop()
    #           print("Trimmimng population")

            # Next we refill the population with new members, but only if they are
            # at least as good as the previous average member

            # new members are created by applying an operator, which is chosen
            # by rouletteSelect

            new_members = []
            while len(self.population) + len(new_members) < self.population_size:
                method = self.chooseMethod()
                candidate = None
                self.num_born +=1
                if method in self.crossover_methods:
                    x,y = self.chooseParents()
                    candidate = method(x,y)
                elif method in self.mutator_methods:
                    candidate = method(self.population[self.rouletteSelect(fitnesses)])
                else:
                    candidate = self.generateRandomChromosome()

                if len(candidate) == 0:
                    break

                if self.getFitness(candidate) >= mean_fitness:
                    new_members.append(candidate)
                    if self.getFitness(candidate) >= fitnesses[0]:
                        self.maxRewardMethod(method)
                    else:
                        self.rewardMethod(method)
                else:
                    self.punishMethod(method)
            self.population = self.population + new_members
            self.updateParameters()
        return self.solution

    def chooseMethod(self):
        index =  self.rouletteSelect(list(self.operator_fitness.values()))
        return list(self.operator_fitness.keys())[index]
    
    def end_condition(self):
        if self.generation >0 and self.generation % 10000 == 0:
            return True
        for member in self.population:
            if self.isGoal(self.problem_instance.path_to_state(member,self.strictness)):
                self.solution = member
                return True
        return False

    def maxRewardMethod(self, method):
        self.operator_fitness[method] = self.operator_fitness[method] + 5

    def rewardMethod(self, method):
        self.operator_fitness[method] += 2

    def punishMethod(self, method):
        self.operator_fitness[method] = self.operator_fitness[method] - 1
        if self.operator_fitness[method] < 5:
            self.operator_fitness[method] = 5

    def getFitness(self, path):
        min_fitness = 2
        if len(self.problem_instance.path_to_state(path, self.strictness)) == 0:
            return min_fitness
        fitness = self.fitness_evaluation(path)

        if fitness < min_fitness:
            return min_fitness
        else:
            return fitness

    def fitnessMethod1(self, path):
        state = self.problem_instance.path_to_state(path, self.strictness)
        fitness = (len(state[self.problem_instance.rod3]) * self.size ** 2 +
                len(state[self.problem_instance.rod2]) * self.size -
                len(state[self.problem_instance.rod1]) -
                len(path))//2
        return fitness

    def fitnessMethod2(self, path):
        # This fitness measurement rewards the largest disk on the goal peg,
        # and penalizes for every (size) nodes on the length of the path
        state = self.problem_instance.path_to_state(path, self.strictness)
        fitness = 0
        if len(state[self.problem_instance.rod3]) > 0:
            fitness += (max(state[self.problem_instance.rod3]) * self.size) 
        fitness -= len(path) // self.size
        return fitness

    def fitnessMethod3(self,path):
        state = self.problem_instance.path_to_state(path, self.strictness)
        fitness = 0
        for i in range(len(state[self.problem_instance.rod3])):
            fitness += (state[self.problem_instance.rod3][i]) * self.size 
        fitness -= len(path) // self.size
        return fitness

    def fitnessMethod4(self,path):
        state = self.problem_instance.path_to_state(path, self.strictness)
        fitness = 0
        for i in range(len(state[self.problem_instance.rod3])):
            fitness += (state[self.problem_instance.rod3][i]) * self.size 
        if len(state[self.problem_instance.rod1]) == 0:
            fitness += 3 * self.size
        else:
            if len(state[self.problem_instance.rod3]) > 0 and max(state[self.problem_instance.rod3]) > max(state[self.problem_instance.rod1]):
                fitness += 2 * self.size
            if len(state[self.problem_instance.rod2])  > 0 and max(state[self.problem_instance.rod2]) > max(state[self.problem_instance.rod1]):
                fitness += self.size
        fitness -= len(path) // self.size
        return fitness

    def fitnessMethod5(self,path):
        # This version rewards for the largest disk pulled off rod 1, and 
        # for the sequence of large discs on rod 3
        state = self.problem_instance.path_to_state(path, self.strictness)
        fitness = 0
        for i in range(self.size,0,-1):
            if i not in (state[self.problem_instance.rod1]):
                fitness += i
                break
        for i in range(self.size,0,-1):
            if i in (state[self.problem_instance.rod1]):
                fitness += i
            else:
                break
        return fitness

    def fitnessMethod6(self,path):
        # This version rewards for the largest disk pulled off rod 1, and 
        # for the sequence of large discs on rod 3, and for the largest disk
        # on rods 2 and 3
        state = self.problem_instance.path_to_state(path, self.strictness)
        fitness = 0
        if len(state[self.problem_instance.rod2]) >0:
            fitness += max(state[self.problem_instance.rod2]) * len(state[self.problem_instance.rod2]) 
        if len(state[self.problem_instance.rod3]) >0:
            fitness += max(state[self.problem_instance.rod3]) * len(state[self.problem_instance.rod3]) 
        for i in range(self.size,0,-1):
            if i not in (state[self.problem_instance.rod1]):
                fitness += i
                break
        for i in range(self.size,0,-1):
            if i in (state[self.problem_instance.rod1]):
                fitness += i
            else:
                break
        return fitness

    def fitnessMethod7(self, path):
        fitness = self.problem_instance.valid_pathlength(path)
        return fitness

    def generateRandomChromosome(self):
#        size = random.randrange(self.size, self.size ** 2) 
        size = random.randrange(1, self.size)
        new_chromosone = []
        while len(new_chromosone) < size:
            new_chromosone.append(self.problem_instance.getRandomAction([],False))
        return new_chromosone

    def generateInitialPopulation(self):
        self.population = []
        while len(self.population) < self.population_size:
            self.population.append(self.generateRandomChromosome())
            self.num_born +=1

    def mutate(self, victim):
        # replaces a randomly selected moves in the path
        # with a randomly selected move. 
        victim = deepcopy(victim)
        index = random.randrange(0,len(victim))
        victim[index] = self.problem_instance.getRandomAction([],False)
        return victim

    def innermutate(self, victim):
        # alters one of the moves in the path so that it instead of moving
        # (a->b) it moves (a->c)
        victim = deepcopy(victim)
        index = random.randrange(0,len(victim))
        all_moves = self.problem_instance.getActions(None,False)
        possible_moves = []
        for move in all_moves:
            if move[0] == victim[index][0]:
                possible_moves.append(move)
        if possible_moves[0] == victim[index]:
            victim[index] == possible_moves[1]
        else: 
            victim[index] == possible_moves[0]
        return victim


    def truncate(self, victim):
        # chops the last move off of the chromosome. Who knows, it might help.
        return deepcopy(victim)[:-1]

    def extend(self, victim):
        # add another move onto the end of the path
        victim = deepcopy(victim)
        victim.append(self.problem_instance.getRandomAction([],False))
        return victim

    def multiextend(self, victim):
        victim = victim
        for i in range(1, random.randrange(1, 4)):
            victim = self.extend(victim)
        return victim

    def snip(self, victim):
        # This mutator slices one step out of the path
        victim = deepcopy(victim)
        if len(victim) < 5:
            return victim
        step = random.randrange(1, len(victim)-1)
        victim.pop(step)
        return victim

    def uniform_crossover(self, x, y):
        # instead of one-point crossover, it is essentially 
        # n-point crossover.
        # Got the idea from L Davis: Handbook of Genetic Algorithms
        new_chromosome = deepcopy(x)
        if len(y) > len(x):
            new_chromosome = deepcopy(y)
        for i in range(min(len(x), len(y))):
            if random.randint(0,1) == 1:
                new_chromosome[i] = y[i]
            else:
                new_chromosome[i] = x[i]
        return new_chromosome

    def printBestMembers(self):
        num_members = 4

        for i in range(num_members):
            self.problem_instance.print_state(self.problem_instance.path_to_state(self.population[i], self.strictness))
            print('')

    def printOperatorFitness(self):
        for key in self.operator_fitness:
            print(key.__name__, " : ", str(self.operator_fitness[key]))

    def updateParameters(self):
        self.generation += 1
        if self.generation % 750 == 0:
            self.printBestMembers()
            self.printOperatorFitness()
