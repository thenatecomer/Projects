# Benjamen Weber's Backtrack DFS Implementation
# webe0491
# 4593981


class Node(object):
    nodeCount = 0
    recordPath = False

    def __init__(self, state, parent=None, action=None):
        self.state = state

        # makeChild always passes self as parent, thus a static class flag
        # is being used to indicate whether it needs to be kept or not.
        # Set flag in AIproblemClass with Node.recordPath = True
        if (Node.recordPath):
            self.parent = parent
        else:
            parent = None
        self.depth = 0
        Node.nodeCount += 1
        if parent:
            self.depth = parent.depth + 1

    def expand(self, problem):
        return [self.makeChild(problem, action) for action in problem.getActions(self.state)]

    # For use by BacktrackDFS, returns a generator which produces actions for the given problem.
    def expandGenerator(self, problem):
        return problem.getActionGenerator(self.state)

    # For use by BacktrackDFS, returns a new Node made by applying the action produced from the problem's generator.
    def makeChildGenerator(self, problem, action):
        childState = problem.applyActionGenerator(self.state, action)
        return Node(childState, self)

    # Added the passing of self for parent information, including depth
    def makeChild(self, problem, action):
        childState = problem.applyAction(self.state, action)
        return Node(childState, self)

    def getState(self):
        return self.state


def recursiveBacktrackDFS(problem):
    # Generate the initial (root) node
    node = Node(problem.initial)
    # For efficiency, we check if the node is a goal state BEFORE putting on the Q
    if problem.isGoal(node.getState()):
        return node
    # Recursively find the solution, making sure to never expand all the nodes for a given level by using a generator.
    return _recursiveDFS(problem, node)

def _recursiveDFS(problem, node):
    #get the generator for the given problem.
    generator = node.expandGenerator(problem)
    for nextAction in generator:
        nextNode = node.makeChildGenerator(problem, nextAction)
        # If the action was illegal, the returned state is None, so we try the next action from the generator.
        if nextNode.getState() == None:
            continue
        # print('Next action :' + str(nextAction) + ' Next State :' + str(nextNode.getState()))
        if(problem.isGoal(nextNode.getState())):
            # print('Goal reached!')
            # print(nextNode.getState())
            return nextNode.getState()
        else:
            # Make a recursive call to explore one level deeper of the tree.
            possibleSolution = _recursiveDFS(problem, nextNode)
            if(possibleSolution != None):
                return possibleSolution
    # if none of the possible options from the generator worked, return None to the caller so they know to try a different
    # action
    return None
