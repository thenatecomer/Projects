from Towers import Tower
from IDDFS import *

def Solver(discs):


    tower1 = Tower(discs,False)
    solution = IDDFS(tower1,discs,0)
    return solution



Solution = Solver(2)
print("The solution is ", Solution.getState())
