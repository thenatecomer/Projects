from GABaseClass import BaseGA
from GATower import GAHanoi
import random
import os

class GATower(BaseGA):
    #ThiS class is to help with striving for an A
    #It existence is meant for to solving Towers of Hanoi,
    #but contains methods general to any problem with a variable
    # -length chromosone
    #It's constructor takes as a parameter size = number of disks
    #Each chromosone is a list representing a path
    #These chromosones must be processed into a puzzle state
    #before they can be evaluated as a state

    def __init__(self, size):
        super().__init__(GAHanoi(size)) #sets problem instance to GAHanoi
        self.size = size
        self.population_size =  5 * self.size ** 2
        self.strictness = "partial" # other options are "strict"
        self.fitness_evaluation = self.fitnessMethod7
        self.useAdaptiveOperatorSelection()
        self.newgenerationMethod = self.weakest_member_replacement
        
    def end_condition(self):
        for member in self.population:
            if self.isGoal(self.problem_instance.path_to_state(member,self.strictness)):
                self.solution = member

        return (self.generation == 1) or (self.generation > 0 and self.generation % 250 == 0) or (self.solution != None)

    def getFitness(self, path):
        if len(path) == 0:
            return self.min_fitness
        if len(self.problem_instance.path_to_state(path, self.strictness)) == 0:
            return self.min_fitness
        fitness = self.fitness_evaluation(path)

        if fitness < self.min_fitness:
            return self.min_fitness
        else:
            return fitness

    def fitnessMethod1(self, path):
        state = self.problem_instance.path_to_state(path, self.strictness)
        fitness = (len(state[self.problem_instance.rod3]) * self.size ** 2 +
                len(state[self.problem_instance.rod2]) * self.size -
                len(state[self.problem_instance.rod1]) -
                len(path))//2
        return fitness

    def fitnessMethod2(self, path):
        # This fitness measurement rewards the largest disk on the goal peg,
        # and penalizes for every (size) nodes on the length of the path
        state = self.problem_instance.path_to_state(path, self.strictness)
        fitness = 0
        if len(state[self.problem_instance.rod3]) > 0:
            fitness += (max(state[self.problem_instance.rod3]) * self.size) 
        fitness -= len(path) // self.size
        return fitness

    def fitnessMethod3(self,path):
        state = self.problem_instance.path_to_state(path, self.strictness)
        fitness = 0
        for i in range(len(state[self.problem_instance.rod3])):
            fitness += (state[self.problem_instance.rod3][i]) * self.size 
        fitness -= len(path) // self.size
        return fitness

    def fitnessMethod4(self,path):
        state = self.problem_instance.path_to_state(path, self.strictness)
        fitness = 0
        for i in range(len(state[self.problem_instance.rod3])):
            fitness += (state[self.problem_instance.rod3][i]) * self.size 
        if len(state[self.problem_instance.rod1]) == 0:
            fitness += 3 * self.size
        else:
            if len(state[self.problem_instance.rod3]) > 0 and max(state[self.problem_instance.rod3]) > max(state[self.problem_instance.rod1]):
                fitness += 2 * self.size
            if len(state[self.problem_instance.rod2])  > 0 and max(state[self.problem_instance.rod2]) > max(state[self.problem_instance.rod1]):
                fitness += self.size
        fitness -= len(path) // self.size
        return fitness

    def fitnessMethod5(self,path):
        # This version rewards for the largest disk pulled off rod 1, and 
        # for the sequence of large discs on rod 3
        state = self.problem_instance.path_to_state(path, self.strictness)
        fitness = 0
        for i in range(self.size,0,-1):
            if i not in (state[self.problem_instance.rod1]):
                fitness += i
                break
        for i in range(self.size,0,-1):
            if i in (state[self.problem_instance.rod1]):
                fitness += i
            else:
                break
        return fitness

    def fitnessMethod6(self,path):
        # This version rewards for the largest disk pulled off rod 1, and 
        # for the sequence of large discs on rod 3, and for the largest disk
        # on rods 2 and 3
        state = self.problem_instance.path_to_state(path, self.strictness)
        fitness = 0
        if len(state[self.problem_instance.rod2]) >0:
            fitness += max(state[self.problem_instance.rod2]) * len(state[self.problem_instance.rod2]) 
        if len(state[self.problem_instance.rod3]) >0:
            fitness += max(state[self.problem_instance.rod3]) * len(state[self.problem_instance.rod3]) 
        for i in range(self.size,0,-1):
            if i not in (state[self.problem_instance.rod1]):
                fitness += i
                break
        for i in range(self.size,0,-1):
            if i in (state[self.problem_instance.rod1]):
                fitness += i
            else:
                break
        return fitness

    def fitnessMethod7(self, path):
        fitness = self.problem_instance.valid_pathlength(path)
        return fitness

    def fitnessMethod8(self, path):
        state = self.problem_instance.path_to_state(path, self.strictness)
        fitness = self.problem_instance.valid_pathlength(path)
        for i in range(self.size,0,-1):
            if i not in (state[self.problem_instance.rod1]):
                fitness += i
                break
        return fitness

    def generateRandomChromosome(self):
        size = random.randrange(self.size, self.size ** 2)
        new_chromosone = []
        while len(new_chromosone) < size:
            new_chromosone.append(self.problem_instance.getRandomAction([],False))
        return new_chromosone

    def generateInitialPopulation(self):
        self.population = []
        while len(self.population) < self.population_size:
            self.population.append(self.generateRandomChromosome())
            self.num_born +=1

    def printBestMembers(self):
        num_members = 4

        for i in range(num_members):
            self.problem_instance.print_state(self.problem_instance.path_to_state(self.population[i], self.strictness))
            print('')

    def printOperatorFitness(self):
        for key in self.operator_fitness:
            print(key.__name__, " : ", str(self.operator_fitness[key]))

    def updateParameters(self):
        pass
 
