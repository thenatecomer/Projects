from collections import deque
from problems.AIproblem import AIproblem
from problems.node import Node


def Bidirectional(initialproblem,goalproblem):
    #Creates two initial states from our two problems
    initialState = Node(initialproblem.getState())
    goalState = Node(goalproblem.getState())

    #backtier is the frontier of the search starting at the goal state
    frontier = deque()
    backtier = deque()

    #adds the initial states to the two frontiers
    frontier.append(initialState)
    backtier.append(goalState)

    #will continue search as long states still exist to be explored
    while len(frontier) > 0 or len(backtier) > 0:
        #We use popleft so our method is 2 BFS searches
        frontNode = frontier.popleft()

        #Expands our frontNode and explores all possible moves
        for frontchild in frontNode.expand(initialproblem):
            #Loops through all nodes on the other searches frontier
            for node in backtier:
                #compares node to see if we have a match
                if frontchild.getState()==node.getState():
                    return frontchild
            #since our search was unsuccessful we add node to the back be explored later
            frontier.append(frontchild)

        #Now we carry out the same procedure from the other search
        backNode = backtier.popleft()

        for backchild in backNode.expand(goalproblem):
            for node in frontier:
                if backchild.getState()==node.getState():
                    return backchild
            backtier.append(backchild)

    #We haven't found a solution so (None) is returned
    return None
