#solver class
import sys,os
sys.path.append('algorithms')
sys.path.append('problems')
sys.path.append( os.path.realpath('..') + '/class-repo/projectClasses' )


from algorithms import Towers
from problems import Node
from collections import deque
from algorithms import Bidirectional
from algorithms import IDDFS


def Solver(discs):


    tower1 = Tower(discs,False)
    tower2 = Tower(discs,True)
    tower1.Tower_print(tower1.getState(),discs)
    tower2.Tower_print(tower2.getState(),discs)
    solution = Bidirectional(tower1,tower2)
    return solution






Solution = Solver(3)
print("The solution is ", Solution.getState())
