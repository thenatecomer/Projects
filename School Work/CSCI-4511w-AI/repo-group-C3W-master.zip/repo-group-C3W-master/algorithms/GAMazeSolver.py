import random
from GABaseClass import BaseGA

class GAMazeSolver(BaseGA):
    def __init__(self, problem = None):
        super().__init__(problem)
        self.strictness = "partial" # other options are "strict"
        self.fitness_evaluation = self.fitnessMethod5
        self.useAdaptiveOperatorSelection()
#        self.newgenerationMethod = self.weakest_member_replacement
        self.size = len(self.problem_instance.maze) - 2
        self.population_size = self.size * 3
        self.operator_fitness.pop(self.innermutate) # removes this method, which does nothing in this problem
        self.makeBaby = self.adaptiveOperatorReproduction2

    def end_condition(self):
        for member in self.population:
            if self.isGoal(self.problem_instance.path_to_state(member,self.strictness)):
                self.solution = member

        return (self.generation == 1) or (self.generation > 0 and self.generation % 10000 == 0) or (self.solution != None)
    
    def fitnessMethod1(self, path):
        state = self.problem_instance.path_to_state(path)
        goal = self.problem_instance.goal
#       fitness = self.size **2 - self.problem_instance.manhattanDistance(state, goal)
        fitness = abs(self.problem_instance.manhattan_distance( (1,1) , goal) - self.problem_instance.manhattan_distance(state, goal))
        fitness += self.min_fitness
        return fitness

    def fitnessMethod2(self, path):
        fitness = self.fitnessMethod(path)
        fitness += self.problem_instance.valid_path_length(path)
        return fitness

    def fitnessMethod3(self, path):
        fitness = self.fitnessMethod2(path)
        fitness -= len(path) // 15
        return fitness

    def fitnessMethod4(self, path):
        fitness = self.fitnessMethod(path)
        fitness += 2 * self.problem_instance.valid_path_length(path)
        fitness -= len(path) // self.size
        return fitness

    def fitnessMethod5(self, path):
        fitness = self.problem_instance.valid_path_length(path) + self.min_fitness
        return fitness

    def generateInitialPopulation(self):
        self.population = []
        while len(self.population) < self.population_size:
            self.population.append(self.generateRandomChromosome())
            self.num_born +=1

    def generateRandomChromosome(self):
#       size = random.randrange(self.size)
        size = 3
        new_chromosone = ''
        while len(new_chromosone) < size:
            new_chromosone += (self.problem_instance.getRandomAction())
        return new_chromosone

    def getFitness(self, path):
        if len(path) == 0:
            return self.min_fitness
        if len(self.problem_instance.path_to_state(path, self.strictness)) == 0:
            return self.min_fitness
        fitness = self.fitness_evaluation(path)

        if fitness < self.min_fitness:
            return self.min_fitness
        else:
            return fitness
        
    def updateParameters(self):
        self.avg_fitness = sum(self.fitnesses) // len(self.fitnesses)
