import time
from GAMazeSolver import GAMazeSolver

class ReportMaker():
    def __init__(self):
        self.output = ""
        self.fname = "GAMazeOutput.txt"
        self.starttime = None
        self.endtime = None
        self.solverClass = None
        self.solverInstance = None

    def run(self):
        self.solverClass = GAMazeSolver
        for i in range(3):
            for j in range(5):
                self.solverInstance = self.solverClass('problems/maze10.txt')
                if i == 0:
                    self.solverInstance.fitness_evaluation = self.solverInstance.fitnessMethod1
                elif i == 1:
                    self.solverInstance.fitness_evaluation = self.solverInstance.fitnessMethod3
                self.startRun()

    def startRun(self):
        self.output = ""
        self.starttime = time.time()
        self.startRunReport()

        while self.solverInstance.solution == None and self.solverInstance.generation < 100000 * self.solverInstance.size:
            self.solverInstance.solve()
            self.runPointReport()

        self.endtime = time.time()
        self.output += '<{0}> {1:.2f} </{0}>\n'.format("endtime", self.endtime)
        self.output += '<{0}> {1:.2f} </{0}>\n'.format("runtime", self.endtime - self.starttime )
        self.output += '<solution>\n'
        if self.solverInstance.solution == None:
            self.output += 'None'
        else:
            self.chromosomeReport(self.solverInstance.population.index(self.solverInstance.solution))
        self.output += '</solution>\n'
        self.output += "</run>\n"
        f = open(self.fname, 'a')
        f.write(self.output)
        f.close()

    def startRunReport(self):
        self.output += "<run>\n"
        self.output += '{}{}{}\n'.format("<problem>", self.solverClass.__name__,"</problem>")
        self.output += '{}{:d}{}\n'.format("<size>", self.solverInstance.size,"</size>")
        self.output += '{}{}{}\n'.format("<fitnessmethod>", self.solverInstance.fitness_evaluation.__name__,"</fitnessmethod>")
        self.output += '{}{:.2f}{}\n'.format("<begintime>", self.starttime,"</begintime>")

    def runPointReport(self): 
        self.output += "<runpoint>\n"
        self.output += '{} {:d} {}\n'.format("<generation>", self.solverInstance.generation,"</generation>")
        self.output += '<{0}>{1:d}</{0}>\n'.format('numchildren',self.solverInstance.num_born)
        self.output += '<{0}>{1:d}</{0}>\n'.format('num_children_kept',self.solverInstance.successfull_offspring)
        self.output += '{}{}{}\n'.format("<solved>", str(self.solverInstance.solution != None), "</solved>")

#       for i in range(self.solverInstance.size):
#           self.chromosomeReport(i)
        self.output += '<{0}> {1} </{0}>\n'.format("population", str(self.solverInstanance.population))
        self.output += '{}{:d}{}\n'.format("<avgfitness>", self.solverInstance.avg_fitnesse ,"</avgfitness>")
        self.output += '<operator fitnesses>\n'
        for k,v in self.solverInstance.operator_fitness.items():
            self.output += '<{0}> {1:d} </{0}>\n'.format(k.__name__,v)
        self.output += "</runpoint>\n"

    def chromosomeReport(self, i):
        self.output += "<chromosone>\n"
        self.output += '<{0}> {1:d} </{0}>\n'.format("fitness" , self.solverInstance.fitnesses[i])
        self.output += '<{0}> {1} </{0}>\n'.format("path" , self.solverInstance.problem_instance.path_to_str(self.solverInstance.population[i]))
        self.output += '<{0}> {1} </{0}>\n'.format("state" , self.solverInstance.problem_instance.path_to_state(self.solverInstance.population[i], self.solverInstance.strictness)[1:])
        self.output += "</chromosone>\n"

