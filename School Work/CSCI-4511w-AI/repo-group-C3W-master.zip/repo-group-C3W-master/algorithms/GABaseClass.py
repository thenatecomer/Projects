# a Genetic Algorithm implementation by Lee Williams, will4379
import random 
import math
from copy import deepcopy
from GAReproductionMethods import BaseReproductionMethods
from GATower import GAHanoi
from nQueens import NQueens

class BaseGA(BaseReproductionMethods):
    # This is the base class for the GAs for NQueens, etc.
    #subclasses must self.generateInitialPopulation()
    #end_condition(), 

    def __init__(self, problem_instance = None):
        self.generation = 0
        self.num_born= 0
        self.successfull_offspring = 0 # keeps record of how many children were not rejected
        self.mutation_rate = .01
        self.userid = "will4379"
        self.num_mutations = 0
        self.problem_instance = problem_instance
        self.isGoal = self.problem_instance.isGoal
        self.population = []
        self.fitnesses  = []
        self.solution = None
        self.makeBaby = self.onepointcrossover_and_mutate # sets default reproduction method
        self.avg_fitness = None # some methods use this, some don't
        self.newgenerationMethod = self.full_generation_replacement
        self.factor = 1         # determines how much to divide mean fitness by for partial_generation_replacement
        self.min_fitness = 2    # This parameter sets a base in case a fitness measurement may be so low that a 
                                # chromosone may be inconsequential of may mess up roulette search

    def solve(self):
        keep_going = True
        while keep_going:
            self.generation += 1
            self.newgenerationMethod()
            self.population.sort(key = lambda member : self.getFitness(member))
            self.population.reverse()
            self.fitnesses = [self.getFitness(member) for member in self.population]
            self.updateParameters()
            keep_going = not self.end_condition()

    def full_generation_replacement(self):
        if self.generation == 1:
            self.generateInitialPopulation()
        else:
            newpopulation = [self.makeBaby() for i in range(self.population_size)]
            self.population = newpopulation

    def end_condition(self):
        for member in self.population:
            if self.isGoal(member):
                self.solution = member
                return True
        return False

    def onepointcrossover_and_mutate(self):
        x,y = self.chooseParents()
        baby = self.onepointcrossover(x,y)
        self.num_born += 1
        return self.mutate(baby)

    def useAdaptiveOperatorSelection(self):
        #includes members and methods to enable adaptive operator selection
        # a method which gives a fitness score to various reproduction methods
        # and then chooses the operator by roulette selection
        # Inspired by an idea in Handbook of Genetic Algotithms, L. Davis, 1991
        # The implementation is thoroughly independent
        self.operator_fitness = {}
        self.mutator_methods = [self.path_mutate, self.snip, self.truncate, self.extend, self.multiextend, self.innermutate]
        self.crossover_methods = [self.uniform_crossover, self.onepointcrossover]
        for i in self.mutator_methods + self.crossover_methods:
            self.operator_fitness[i] = 10
        self.operator_fitness[self.generateRandomChromosome] = 10

        self.makeBaby = self.adaptiveOperatorReproduction

    def statetostr(self, state):
#       print("*** Solution Found ***")
        print("Generation :", self.generation)
        print("Number of Children:", self.num_born)
        print("Number of Mutations:", self.num_mutations)
        self.problem_instance.print_state(state)

    def updateParameters(self):
        # A place to put all changes that one might want to do at the end of a generation
        pass

    def weakest_member_replacement(self):
        # An alternative to full_generation_replacement
        # First trim off the worst members
        if self.generation == 1:
            self.generateInitialPopulation()
            return None

        mean_fitness = sum(self.fitnesses) // len(self.fitnesses)
        while ((self.fitnesses[-1] < mean_fitness // self.factor)
                or (len(self.population) + 4 > self.population_size)):
            self.population.pop()
            self.fitnesses.pop()

        # Next we refill the population with new members
        new_members = [self.makeBaby() for i in range(self.population_size - len(self.population))]
        self.population = self.population + new_members

    def adaptiveOperatorReproduction(self):
        # This version assumes use of weakest_member_replacement

        candidate = None
        while candidate == None:
            index =  self.rouletteSelect(list(self.operator_fitness.values()))
            method = list(self.operator_fitness.keys())[index]
            self.num_born +=1
            if method in self.crossover_methods:
                x,y = self.chooseParents()
                candidate = method(x,y)
            elif method in self.mutator_methods:
                x,y = self.chooseParents()
                candidate = method(x)
            else:
                candidate = self.generateRandomChromosome()

            if len(candidate) == 0:
                candidate = None
                continue

            mean_fitness = sum(self.fitnesses) // len(self.fitnesses)
            if self.getFitness(candidate) >= mean_fitness:
                if self.getFitness(candidate) >= self.fitnesses[0]: # if candidate is at least as fit as fittest member of last generation
                    self.operator_fitness[method] = self.operator_fitness[method] + 5 # give an extra boost to the fitness method
                else:
                    self.operator_fitness[method] = self.operator_fitness[method] + 2
                self.successfull_offspring +=1
            else:
                self.operator_fitness[method] = self.operator_fitness[method] - 1
                if self.operator_fitness[method] < 5:
                    self.operator_fitness[method] = 5
                candidate = None
            return candidate

    def adaptiveOperatorReproduction2(self):
        # This version works better with full_generation_replacement
        # it expects that updateParameters sets self.avg_fitness

        candidate = None
        index =  self.rouletteSelect(list(self.operator_fitness.values()))
        method = list(self.operator_fitness.keys())[index]
        self.num_born +=1
        if method in self.crossover_methods:
            x,y = self.chooseParents()
            candidate = method(x,y)
        elif method in self.mutator_methods:
            x,y = self.chooseParents()
            candidate = method(x)
        else:
                candidate = self.generateRandomChromosome()

        if len(candidate) == 0:
                candidate = self.generateRandomChromosome()
                method = self.generateRandomChromosome

        mean_fitness = self.avg_fitness
        if self.getFitness(candidate) > mean_fitness:
            self.operator_fitness[method] = self.operator_fitness[method] + 3
        elif self.getFitness(candidate) < self.min_fitness:
            self.operator_fitness[method] = self.operator_fitness[method] - 1
            if self.operator_fitness[method] < 5:
                self.operator_fitness[method] = 5
        return candidate
