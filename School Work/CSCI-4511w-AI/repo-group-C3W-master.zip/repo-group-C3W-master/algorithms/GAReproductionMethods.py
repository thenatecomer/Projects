# a Genetic Algorithm implementation by Lee Williams, will4379
import random 
import math
from copy import deepcopy

class BaseReproductionMethods:
    # This is the class contains all the reproduction methods
    # (i.e mutators and crossovers) used by genetic algorithms

    def chooseParents(self):
        # This is a roulette wheel (weighted) selection method
        # It assumes that it should use the array in self.population
        # as the population source
        # It returns a pair of non-identical parents
         
#       fitnesses = [self.getFitness(member) for member in self.population]
        parent_y = -1
        parent_x = parent_y
        while parent_x == parent_y:
            parent_y = self.rouletteSelect(self.fitnesses)
            if parent_x == -1:
                parent_x = parent_y
        return self.population[parent_x], self.population[parent_y]

    def mutate(self, baby):
        baby = deepcopy(baby)   #makes sure prior copy survives
        for i in range(len(baby)):
            if random.uniform(0,1) < self.mutation_rate:
                self.num_mutations += 1
                baby[i] = random.randint(0,self.size - 1)
                return baby
        return baby

    def onepointcrossover(self, x, y):
        length = len(x)
        # the following is for problems with variable length chromosomes
        if len(y) < len(x):
            length = len(y)
        cut = random.randint(0, length)
        return x[0:cut] + y[cut:]

    def rouletteSelect(self, fitnesses):
        # This function implements a weighted random selection 
        # it takes from a list of weights, which it does not alter
        # It returns the index of the chosen weight

        fitness_total = sum(fitnesses)
        index = -1
        running_total = 0
        num = random.randrange(1,fitness_total)
        while num > running_total:
            index += 1
            running_total += fitnesses[index]
        return index

    def path_mutate(self, victim):
        # This is a version of mutate more appropriate for 
        # pathfinding
        # replaces a randomly selected moves in the path
        # with a randomly selected move. 
        victim = deepcopy(victim)
        if len(victim) < 3:
            return victim
        index = random.randrange(0,len(victim)-1)
        gene = victim[index]
        while gene == victim[index]:
            gene = self.problem_instance.getRandomAction([],False) 
        victim = victim[:index] + gene + victim[index+1:]
#       victim[index] = self.problem_instance.getRandomAction([],False)
        return victim

    def innermutate(self, victim):
        # alters one of the moves in the path so that it instead of moving
        # (a->b) it moves (a->c)
        # a smaller change then path_mutate
        victim = deepcopy(victim)
        index = random.randrange(0,len(victim))
        all_moves = self.problem_instance.getActions(None,False)
        possible_moves = []
        for move in all_moves:
            if move[0] == victim[index][0]:
                possible_moves.append(move)
        if possible_moves[0] == victim[index]:
            victim[index] == possible_moves[1]
        else: 
            victim[index] == possible_moves[0]
        return victim

    def truncate(self, victim):
        # chops the last move off of the chromosome. Who knows, it might help.
        return deepcopy(victim)[:-1]

    def extend(self, victim):
        # add another move onto the end of the path
        victim = deepcopy(victim)
        if type(victim) == list:
            victim.append(self.problem_instance.getRandomAction([],False))
        elif type(victim) == str:
            victim = victim + self.problem_instance.getRandomAction([],False)
        return victim

    def multiextend(self, victim):
        victim = victim
        for i in range(1, random.randrange(1, 4)):
            victim = self.extend(victim)
        return victim

    def snip(self, victim):
        # This mutator slices one step out of the path
        victim = deepcopy(victim)
        if len(victim) < 5:
            return victim
        step = random.randrange(1, len(victim)-1)
        victim = victim[:-1]
        return victim

    def uniform_crossover(self, x, y):
        # instead of one-point crossover, it is essentially 
        # n-point crossover.
        # Got the idea from L Davis: Handbook of Genetic Algorithms
        if type(x) == str:
            new_chromosome = ''
        elif type(x) == list:
            new_chromosome = []
        for i in range(min(len(x), len(y))):
            if random.randint(0,1) == 1:
                if type(x) == str:
                    new_chromosome = new_chromosome + x[i]
                elif type(x) == list:
                    new_chromosome.append(x[i])
            else:
                if type(x) == str:
                    new_chromosome = new_chromosome + y[i]
                elif type(x) == list:
                    new_chromosome.append(y[i])
        return new_chromosome
