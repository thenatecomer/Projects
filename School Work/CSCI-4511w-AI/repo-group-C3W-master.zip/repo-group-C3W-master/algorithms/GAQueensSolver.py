from GABaseClass import BaseGA

class GAQueens(BaseGA):
    #This class is specific to solve NQueens problems
    #It takes as parameter size=Number of Queens
    def __init__(self,size):
        super().__init__()
        self.problem_instance = NQueens(size)
        self.evaluation = self.problem_instance.evaluation
        self.isGoal = self.problem_instance.isGoal
        self.size = size
        self.population = []
        self.population_size = 2 * self.size


    def getFitness(self,state):
        #calculates and returns  fitness of the given state
        maxcollisions = self.size * (self.size -1) /2
        return int(math.pow(maxcollisions -self.evaluation(state), 2))

    def generateInitialPopulation(self):
        while len(self.population) < self.population_size:
            self.population.append(self.generateRandomSolution())

    def generateRandomSolution(self):
        solution = list(range(self.size))
        random.shuffle(solution)
        return solution


