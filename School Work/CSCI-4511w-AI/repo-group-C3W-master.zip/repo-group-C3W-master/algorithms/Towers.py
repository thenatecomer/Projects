from collections import deque
#sfrom AIproblem import AIproblem
from copy import deepcopy

class Tower:


    discs = 0

    def __init__(self, discs,goal,state = None):
        self.discs = discs
        self.Explored = []
        self.path = []

        #Initializes all of the rods or pegs
        rod1 = []
        rod2 = []
        rod3 = []

        #Since we have Bidirectional search we will need to initialize a goal state
        #goal is a boolean that specifies whether we want the goal or initial state
        for n in range(discs,0,-1):
            if goal:
                rod3.append(n)
            else:
                rod1.append(n)

        self.state=[rod1,rod2,rod3]
        if state != None:
            self.state = state

        #We need to have a list of already visited nodes to avoid looping
        self.Explored.append(self.state)


    def getActions(self, state):
        Poss_Moves = []
        temp = []

        #i is the rod we are moving from
        #j is the rod we are moving to
        for i in range(0,3):
            for j in range(0,3):
                if(i!=j and len(state[i])!= 0): #we don't want i==j since the move is trivial
                                                #Also if i has no elements we can't move from i
                    if(len(state[j])==0): #if j has no discs any more to it is possible
                        temp.append(3*i+j) #Encodes the move into one number
                        Poss_Moves = Poss_Moves + temp
                        temp = []

                    #checks to see if the top of rod i is less than the top of rod j
                    elif(state[i][-1]<state[j][-1]):
                        temp.append(3*i+j)
                        Poss_Moves = Poss_Moves + temp
                        temp = []

        #Now I will check if moves are in the Explored list
        for i in Poss_Moves:
            #creates a state where the move has been made
            temporary_state= self.applyAction(state, i)

            #compares that state to states in Explored list
            if(temporary_state in self.Explored):
                Poss_Moves.remove(i)

            #if not the move needs to be added to explored list
            else:
                self.Explored.append(temporary_state)

        #returns the list of moves decoded as integers
        return Poss_Moves


    def getState(self):
        return self.state

    def isGoal(self,state):
        #checks if all discs are in rod3

        for n in range(1,self.discs+1):
            if n not in state[2]:
                return False

        return True

    def applyAction(self,state,move):
        newState = deepcopy(state)

        tower1 = 0
        tower2 = 0

        #next two lines decodes single integer back into rod moving from and rod moving to
        tower1 = move//3
        tower2 = move%3

        #Grabs the disc from the rod stores it in temporary
        temporary = newState[tower1][-1]
        newState[tower1].remove(temporary)
        newState[tower2].append(temporary)
        self.Tower_print(newState,self.discs)

        return newState



    def Tower_print(self, state, discs):
        for n in range(discs,-1,-1):
            if n in state[0]:
                print(n, end="")

        print("\n")

        for n in range(discs,-1,-1):
            if n in state[1]:
                print(n, end="")

        print("\n")

        for n in range(discs,-1,-1):
            if n in state[2]:
                print(n, end="")

        print("\n")



examplestate = [[],[],[5,4,3,2,1]]
for n in range(5,1,-1):
    if n not in examplestate[2]:
        print("false")

#print("true")
#Example1 = Tower(5,2)
#Example1.Tower_print(Example1.getState(),5)
#print(Example1.getActions(Example1.getState()))

#Example2 = Tower (7,3)
#Example2.Tower_print(Example2.getState(),7)
