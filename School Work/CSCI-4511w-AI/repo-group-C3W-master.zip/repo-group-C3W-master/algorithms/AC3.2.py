# a self=created version of AC3
# This version implements neighbors
# buy not assigning neighbors to constraints, but to the variables
# when a variable or arc is pulled of the stack
# the constraint dictionary has a list of lambdas that is iterated over
#
# I also implemented Logic Puzzle 1

from copy import deepcopy
from collections import deque

class AC32:
    def __init__(self, puzzle, include_arcs = True):
        # the AC3 solver takes as a parameter a puzzle class that provides the following members:
	#	self.neighbors, a dictionary where:
	#		the keys are variables
	#		the values are lists of neighbors of each variable
	#	self.domain, the domain of the variable
        # 	self.constraints , a dictionary of constraints, 
	#		where the key is either a single varible or a pair of variables, 
	#		and the value is a function
        # that is applied members of the domain of the variable/ pair of variables
        #
        # The second parameter determines whether the queue should be preloaded
        # with all the arcs (variable, neighbors pairs) that exist
        self.neighbors, self.domain_values, self.constraints = puzzle.puzzle()

        self.domain = dict()
        for var in list(self.neighbors.keys()):
            self.domain[var] = deepcopy(self.domain_values)
#       print("Starting domain is : ", self.domain)

        queue = deque()
        for var in list(self.neighbors.keys()):
            queue.append(var)
            if include_arcs:
                for neighbor in list(self.neighbors[var]):
                    queue.append( (var, neighbor) )

        while len(queue) > 0 :
            item = queue.popleft()
            if self.revise(item):
                if type(item) == tuple:
                    item = item[0]
#               print("\t",item, " domain is now ", self.domain[item])
                if len(self.domain[item]) == 0:
                    break
                for neighbor in self.neighbors[item]:
                    queue.append((item, neighbor))
                    queue.append((neighbor, item))

        self.success = True
        for var in list(self.neighbors.keys()):
            if len(self.domain[var]) != 1:
                self.success =  False


    def revise(self, item):
        # revise takes as a parameter either a variable or a pair of variables
        # it traverses over every constraint for the var/pair passed as 'item'
        # if it can eliminate an entry from the domain of item/item[0]
        # it does so, and sets revised to True
        # at the end it returns the flag revised

        revised = False
#       print("revising ", item)

        if type(item) == tuple:
            for constraint in self.constraints[item]:
                failures = [] # a list for entries in the domain that don't fly 
                for x in self.domain[item[0]]:
                    x_works = False
                    for y in self.domain[item[1]]:
                        if constraint(x,y):
                            x_works = True
                    if not x_works:
                        failures.append(x)
                if len(failures) > 0:
                    revised = True
                    for flop in failures:
                        self.domain[item[0]].remove(flop)
#                       print("removing ", flop, "from ", item[0])
        else:
            for constraint in self.constraints[item]:
                failures = [] # a list for entries in the domain that don't fly 
                for x in self.domain[item]:
                    if not constraint(x):
                        failures.append(x)
                if len(failures) > 0:
                    revised = True
                    for flop in failures:
                        self.domain[item].remove(flop)
#                       print("removing ", flop, " from domain of ", item)

        return revised

def setupKenKen():
    variables = AC3.createTable(3)
    neighbors = AC3.createTableNeighbors(3)
    constraints = AC3.setupConstraintsDictionary(neighbors)

    constraints['A3'].append( lambda x: x == 2)
    constraints[('A1','A2')].append( lambda x,y: abs(x-y) == 2)
    constraints[('A2','A1')].append( lambda x,y: abs(x-y) == 2)
    constraints[('B1','C1')].append( lambda x,y: x//y == 2 or y//x == 2)
    constraints[('C1','B1')].append( lambda x,y: x//y == 2 or y//x == 2)
    constraints[('B2','B3')].append( lambda x,y: x//y == 3 or y//x == 3)
    constraints[('B3','B2')].append( lambda x,y: x//y == 3 or y//x == 3)
    constraints[('C3','C2')].append( lambda x,y: abs(x-y) == 1)
    constraints[('C2','C3')].append( lambda x,y: abs(x-y) == 1)

    AC3.generateAllDiff(constraints, neighbors)

    return (neighbors, list(range(1,4)),constraints)

def tryAC3():
    a = AC3(setupKenKen())
    variables = AC3.createTable(3)
    rows = []
    row = []
    for i in range(9):
        row.append(a.domain[variables[i]][0])
        if (i + 1)%3 == 0:
            rows.append(row)
            row = []


    return rows

def tryLogicPuzzle():
    friends = ['Adam', 'Jessica', 'Ryan', 'Sophie']
    neighbors = dict()
    for f in friends:
        neighbors[f] = []
        for g in friends:
            if f != g:
                neighbors[f].append(g)

    constraints = AC3.setupConstraintsDictionary(neighbors)
    constraints['Jessica'].append(lambda x: x!= 'Baseball')
    constraints['Jessica'].append(lambda x: x!= 'Soccer')
    constraints['Ryan'].append(lambda x: x!= 'Baseball')
    constraints['Ryan'].append(lambda x: x!= 'Basketball')
    constraints['Ryan'].append(lambda x: x!= 'Soccer')
    constraints['Adam'].append(lambda x: x!= 'Soccer')
    AC3.generateAllDiff(constraints, neighbors)
    a = AC3((neighbors,['Baseball','Basketball','Soccer','Tennis'],constraints))

    return a.domain
