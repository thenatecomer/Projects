#IDDFS
#Iterative Deepening Depth First search
from collections import deque
from node import Node
from Towers import *



def runIDDFS(problem):
	solution = None
	limit = 1

	while solution == None:
		solution = IDDFS(problem, limit)
		limit = limit + 1

	return solution


def IDDFS(problem, limit):
	#sets up our explored list that remembers all visited nodes
	explored = deque()
	stack = deque()
	node = Node(problem.initial)

	stack.append(node)
	stack.append(0)

	while len(stack) > 0:
		length = stack.pop()
		node = stack.pop()
		#print('!', end = "")
		if problem.isGoal(node.getState()):
			return node
		else:
			explored.append(node)
		if length > limit:
			continue
		for child in node.expand(problem):
				if child not in explored:
					stack.append(child)
					stack.append(length + 1)
	return None
