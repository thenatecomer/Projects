import os
import random

class Maze:
    def __init__(self):
        rows, columns = os.popen('stty size', 'r').read().split() # Thanks, stack exchange !!
        rows = int(rows)
        if (rows % 2) == 0:
            rows -= 1
        columns = int(columns)
        if columns % 2 == 0:
            columns -= 1
        rows -= 6
        columns -= 6

        self.maze = []
        self.wall_character = '@'
        self.passage_character = ' '

        self.binaryMaze(rows, columns)
        print(self)

    def __str__(self):
        s = ""
        for row in self.maze:
            for col in row:
#               s+= self.maze[row][col]
                s+= col
            s+="\n"
        return s

    def binaryMaze(self, rows, columns):
        for i in range(rows):
            newrow = []
            for j in range(columns):
                if i % 2 ==0 or j % 2 == 0:
                    newrow.append(self.wall_character)
                else:
                    newrow.append(self.passage_character)

            self.maze.append(newrow)

        for i in range(1,rows -1, 2):
            for j in range(1,columns -2, 2):
                val = random.randint(0,1)
                if i == rows - 2 and val == 0:
                    self.maze[i][j+1] = self.passage_character
                elif i == rows  - 2 and val == 1:
                    self.maze[i][j+1] = self.passage_character
                    self.maze[i-1][j] = self.passage_character
                elif val == 1 or i == 1:
                    self.maze[i][j+1] = self.passage_character
                else:
                    self.maze[i-1][j] = self.passage_character

