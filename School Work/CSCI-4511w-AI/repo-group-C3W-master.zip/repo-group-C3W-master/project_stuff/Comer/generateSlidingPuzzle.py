import random

class generateSliding(object):
    def __init__(self, size, moves):
        self.size = size
        self.moves = moves
        self.puzzle = []
        self.currentZero = [self.size-1,self.size-1]
        self.last = [0,0]
        self.initial()
        
    def initial(self):
        count = 1
        for i in range (0,self.size):
            row = []
            for j in range(0, self.size):
                row.append(count)
                count+=1
            self.puzzle.append(row)
        self.puzzle[self.size-1][self.size-1] = 0
        
    def scramble(self):
        random.seed()
        for n in range(0,self.moves):
            actionssaved = self.getActions()
            val = random.randint(0, len(actionssaved) - 1)
            actions = actionssaved[val]
            while actions[0]==self.last[0] and actions[1]==self.last[1]:
                val = random.randint(0,len(actionssaved)-1)
                actions = actionssaved[val]
            self.puzzle[self.currentZero[0]][self.currentZero[1]] = self.puzzle[actions[0]][actions[1]]
            self.puzzle[actions[0]][actions[1]] = 0
            self.last[0] = self.currentZero[0]
            self.last[1] = self.currentZero[1]
            self.currentZero[0] = actions[0]
            self.currentZero[1] = actions[1]
        return self.puzzle
            
    def getActions(self):
        actions = []
        if self.currentZero[0] > 0:
            actions.append([self.currentZero[0] - 1, self.currentZero[1]])
        if self.currentZero[1] > 0:
            actions.append([self.currentZero[0], self.currentZero[1] - 1])
        if self.currentZero[0] < self.size - 1:
            actions.append([self.currentZero[0] + 1,self.currentZero[1]])
        if self.currentZero[1] < self.size - 1:
            actions.append([self.currentZero[0], self.currentZero[1] + 1])

        return actions

#test = generateSliding(10, 100)
#test.scramble()
