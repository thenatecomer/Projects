from AIproblem import AIproblem
import queue

# By: Nathan Comer

class Node(object):

	nodeCount = 0

	def __init__( self, state, parent=None, action=None ) :
		self.state = state
		Node.nodeCount += 1
		if parent:
			self.depth = parent.depth + 1

	def expand( self, problem, opposite_coordinate ) :
		return [ self.makeChild( problem, action, opposite_coordinate) for action in problem.getActions( self.state ) ]

	def makeChild( self, problem, action, opposite_coordinate ) :
		childState = problem.applyAction( self.state, action, opposite_coordinate )
		return Node( childState )

	def getState( self ) :
		return self.state

class BdAstarSearch(AIproblem):

    def __init__(self, initialState, width, height, goal = None ):
        self.initialState = initialState
        self.width = width
        self.height = height
        self.size = width*height
        self.goal = goal
        self.nodes = 0
        self.analysisCounter = 0
        AIproblem.__init__(self, self.initialState, self.size)


    def BdAstar(self, problem):
        nodeFront = Node(problem.newState(self.initialState, self.width, self.height))
        nodeFront.depth = 0

        # Change the 3rd argument in this function call if not use MazePuzzle
        nodeBack = Node(problem.newState(self.initialState, self.width, self.height, problem.getGoal()))
        nodeBack.depth = 0

        frontier = queue.PriorityQueue()
        frontier.put(tuple([0, 0, nodeFront]))
        
        backtier = queue.PriorityQueue()
        backtier.put(tuple([0, 0, nodeBack]))

        if problem.isGoal(nodeFront.getState()):
            print("The puzzle is already solved!")
            return nodeFront

        already_visited_front = {}
        previous_state_front = {}
        previous_state_front[str(nodeFront.getState().ID)] = str([])
        already_visited_front[str(nodeFront.getState().ID)] = 0

        already_visited_back = {}
        previous_state_back = {}
        previous_state_back[str(nodeBack.getState().ID)] = str([])
        already_visited_back[str(nodeBack.getState().ID)] = 0

        while not frontier.empty() or not backtier.empty():
            curNode_front = frontier.get()[2]
            curNode_back = backtier.get()[2]
            self.analysisCounter += 1
            if self.analysisCounter%100000 == 0:
                print("")
                print("Progress Analysis: ")
                print("Current Node:")
                #print("depth: ", curNode.depth)
                #print("state: ", curNode.getState().state)
                #print("value: ", curNode.getState().value)
                #print("")

            # Checks to see if the front and back searches have met yet
            if str(curNode_front.getState().ID) == str(curNode_back.getState().ID):
                #print("Found the Goal! The two directions met at:", curNode_back.getState().coordinate)
                return [curNode_front.nodeCount,curNode_front.getState().endBehavior()+curNode_back.getState().endBehavior()]

            # Checks to see if the front found the solution without ever meeting the back
            if problem.isGoal(curNode_front.getState()):
                #print("Found the Goal! The forward direction reached the end without ever meeting the backward direction.")
                return [curNode_front.nodeCount,curNode_front.getState().endBehavior()]

            # Checks to see if the back found the solution without ever meeting the front
            if curNode_back.getState().coordinate == [1,1]:
                #print("Found the Goal! The backward direction reached the beginning without ever meeting the forward direction.")
                return [curNode_back.nodeCount,curNode_back.getState().depth]

            # Expands one node from the front
            for child in curNode_front.expand(problem, [curNode_back.getState().coordinate,[self.width-2,self.height-2]]): # Added second argument for bidirectional
                new_cost = already_visited_front[str(curNode_front.getState().ID)] + child.getState().value
                if str(child.getState().ID) not in already_visited_front or new_cost < already_visited_front[str(child.getState().ID)]:
                    already_visited_front[str(child.getState().ID)] = new_cost
                    child.depth = curNode_front.depth + 1
                    self.nodes += 1
                    frontier.put(tuple([child.getState().value, self.nodes, child]))
                    previous_state_front[str(child.getState().ID)] = str(curNode_front.getState().ID)

            # Checks again to see if the front and back searches have met
            if problem.isGoal(curNode_front.getState()):
                #print("Found the Goal! The two directions met at:", curNode_back.getState().coordinate)
                return [curNode_front.nodeCount] + curNode_front.getState().endBehavior()

            # Expands one node from the back
            for child in curNode_back.expand(problem, [curNode_front.getState().coordinate,[1,1]]): # Added second argument for bidirectional
                new_cost = already_visited_back[str(curNode_back.getState().ID)] + child.getState().value
                if str(child.getState().ID) not in already_visited_back or new_cost < already_visited_back[str(child.getState().ID)]:
                    already_visited_back[str(child.getState().ID)] = new_cost
                    child.depth = curNode_back.depth + 1
                    self.nodes += 1
                    backtier.put(tuple([child.getState().value, self.nodes, child]))
                    previous_state_back[str(child.getState().ID)] = str(curNode_back.getState().ID)
        print("The puzzle you entered is not solvable")
        return
