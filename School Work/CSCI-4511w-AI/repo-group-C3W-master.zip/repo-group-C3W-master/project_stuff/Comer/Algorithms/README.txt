Contains Algorithms used in the data collection process
