Contains problems used in data collection process
