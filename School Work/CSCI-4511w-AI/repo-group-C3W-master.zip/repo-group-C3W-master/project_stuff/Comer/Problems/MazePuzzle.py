
import node
from AIproblem import AIproblem
import math
from copy import deepcopy


# Nathan Comer
# comer028
# Striving for an A work

class MazePuzzle(AIproblem):
    def __init__(self, initialState, totalSize):
        # print("Maze puzzle init")

        self.puzzle = initialState # Changed
        self.size = totalSize
        self.state = MazeState(self.puzzle, self.size, [1,1])
        #self.printState(self.state)

        AIproblem.__init__(self, self.state, self.size, self.evalFunction)

    def loadMaze(self, file, size):
        maze = []
        with open(file) as f:
            for r in f.readlines():
                maze.append(r)
        return maze

    def evalFunction(self, state, size, coordinate):
        value = abs(coordinate[0]- size - 1) + abs(coordinate[1] - size - 1)
        return value

    def manhattenDistance(self, x1, y1, x2, y2):
        return math.sqrt((abs(x1-x2)**2) + (abs(y1-y2)**2))

    def getActions(self, passedstate):
        state = passedstate.state
        actions = []
        coordinate = passedstate.coordinate

        if state[coordinate[0]-1][coordinate[1]] == ".":
            actions.append([coordinate[0] - 1, coordinate[1]])
        if state[coordinate[0]][coordinate[1]-1] == ".":
            actions.append([coordinate[0], coordinate[1]-1])
        if state[coordinate[0]+1][coordinate[1]] == ".":
            actions.append([coordinate[0]+1, coordinate[1]])
        if state[coordinate[0]][coordinate[1]+1] == ".":
            actions.append([coordinate[0], coordinate[1]+1])

        return actions

    def newState(self, state, size):
        return MazeState(state,size)

    def applyAction(self, passedstate, action):

        state = passedstate.state
        if not action:
            return []
        else:
            newState = MazeState(deepcopy(state),self.size, action, passedstate.depth + 1)
            newState.state[passedstate.coordinate[0]] = state[passedstate.coordinate[0]][0:(passedstate.coordinate[1])] + str(passedstate.depth%10) + state[passedstate.coordinate[0]][(passedstate.coordinate[1])+1:]
            newState.state[action[0]] = newState.state[action[0]][0:action[1]] + "X" + newState.state[action[0]][action[1]+1:]
            newState.evaluate(self.evalFunction)
        return newState

    def evaluation(self, passedstate):
        if not self.evalFn:
            return 0
        else:
            passedstate.evaluate(self.evalFunction)

    def isGoal(self, passedstate):
        if passedstate.coordinate[0] == (passedstate.size - 2) and passedstate.coordinate[1] == (passedstate.size - 2):
            return True
        return False

    def printState(self, passedstate):
        state = passedstate.state
        for row in state:
            printrow = ""
            for x in row:
                if x == '.' or x == '@' or (x <= '9' and x >= '0') or x == 'X':
                    printrow+=str(x)
            print(printrow)

class MazeState(object):
    def __init__(self, state, size, coordinate = [1,1], depth = 0, value = 0):
        self.state = state
        self.coordinate = coordinate
        self.value = value
        self.depth = depth
        self.size = size
        self.ID = coordinate

    def endBehavior(self):
        self.printState(self)
        return self.depth
    def storeCoordinate(self, x):
        self.coordinate = x

    def evaluate( self, evalFn ):
        self.value = self.depth + evalFn( self.state, self.size, self.coordinate )

    def isGoal( self ) :
        if self.coordinate[0] == (self.size - 2) and self.coordinate[1] == (self.size - 2):
            return True
        return False

    def printState(self, passedstate):
        state = passedstate.state
        for row in state:
            printrow = ""
            for x in row:
                if x == '.' or x == '@' or (x <= '9' and x >= '0') or x == 'X':
                    printrow+=str(x)
            print(printrow)

    def __str__( self ) :
                # Converts the state representation to a string (nice for printing)
                return str( self.state )
