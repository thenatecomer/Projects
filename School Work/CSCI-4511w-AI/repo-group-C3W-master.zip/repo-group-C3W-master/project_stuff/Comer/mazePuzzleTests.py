
import time
from Astar import AstarSearch
from SlidingPuzzle import slidingPuzzle
from SlidingPuzzle import ProblemState
from MazePuzzle import MazePuzzle

class MazeTest(object):
    def __init__(self, board, goal=None):
        #if not len(board) == len(board[0]):
        #    print('Puzzle must be square')
        #    return None

        # The board is a list of rows. Numbers are 1..n. The blank space is represented by 0
        self.board = board
        #self.size = len(self.board) * len(self.board)
        #self.rowLength = len(self.board)
        self.solution = []

        if not goal:
            # If not specified the goal state will be tiles ordered by rows with the blank space in the lower right.
            self.goal = []
            for tile in range(1, self.size, self.rowLength):
                self.goal.append(list(range(tile, tile + self.rowLength)))
            self.goal[self.rowLength - 1][self.rowLength - 1] = 0
        else:
            self.goal = goal

#MazePuzzleTests = []
#MazePuzzleTests.append("maze20.txt")
#puzzle = MazePuzzle(MazePuzzleTests[0], 20)
#tic = time.clock()
#algorithm = AstarSearch(puzzle.puzzle, 20)
#print(algorithm.Astar(puzzle))
#toc = time.clock()
#print(toc-tic)