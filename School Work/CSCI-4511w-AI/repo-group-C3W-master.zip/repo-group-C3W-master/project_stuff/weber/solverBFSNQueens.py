import sys,os

import itertools

import math

sys.path.append('algorithms')
sys.path.append('problems')
sys.path.append( os.path.realpath('..') + '/class-repo/projectClasses' )

#### Benjamen Weber SolverClass ###########################################################
import project.algorithms.bfs as BFS
import project.problems.nQueens as nQueens
import time

class SolverBFSNQueens(object):
    # The input parameters must be as is here
    def __init__(self, size, goal=None):
        self.size = size
        self.solution = None
        self.userid = 'webe0491'  ### PUT THE PERSON WHO WROTE THE ALGORITHM HERE!!
        # This is a good place to create a problem instance.

    # return a solution in the specified format
    # An instance of a solver will be specific to the testCase, thus
    # the details of how to handle it will be hidden inside this method.
    def solve(self):
        problem = nQueens.nQueensProblem(self.size)
        self.solution = BFS.BFS(problem)
        return self.solution

    # print the solution in a user-friendly way
    def printSolution(self):
        if self.solution:
            print('Solution: ' + str(self.solution))
        else:
            print('No solution for input problem.')


if __name__ == '__main__':
    # solver = SolverBFS(puzzle)
    # solver = SolverBacktrackingNQueens(8)
    # solver.solve()
    # solver.printSolution()

    for i in range(10,20):
        size = i
        solver = SolverBFSNQueens(size)

        from pympler import asizeof
        from pympler.classtracker import ClassTracker
        import resource


        print('Size pre solving')
        print ('Memory usage: '+ str(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss) + '(kb)' )

        print('Problem size: '+str(size))
        time1 = time.time()
        solver.solve()
        time2 = time.time()
        print('Size after solving')
        print ('Memory usage: '+ str(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss) + '(kb)' )

        print('Time required = ' + str(time2 - time1) + ' seconds')
