import sys,os

import itertools

import math

sys.path.append('algorithms')
sys.path.append('problems')
sys.path.append( os.path.realpath('..') + '/class-repo/projectClasses' )

#### Benjamen Weber SolverClass ###########################################################
import project.algorithms.Backtracking as Backtracking
import CrossMath
import tests.crossMathTests
from tests.createCrossMath import *
import time

class SolverBacktracking(object):
    # The input parameters must be as is here
    def __init__(self, testCase, goal=None):
        self.testCase = testCase
        self.goal = testCase.solution
        self.solution = None
        self.userid = 'webe0491'  ### PUT THE PERSON WHO WROTE THE ALGORITHM HERE!!
        # This is a good place to create a problem instance.

    # return a solution in the specified format
    # An instance of a solver will be specific to the testCase, thus
    # the details of how to handle it will be hidden inside this method.
    def solve(self):
        problem = CrossMath.CrossMathProblem(self.testCase)
        self.solution = Backtracking.recursiveBacktrackDFS(problem)
        return self.solution

    # print the solution in a user-friendly way
    def printSolution(self):
        if self.solution:
            for row in self.solution:
                print(row)
        else:
            print('No solution for input problem.')


if __name__ == '__main__':
    puzzle = tests.crossMathTests.CrossMathPuzzle(
        [[['+', '+'], 15], [['+', '*'], 24], [['+', '-'], 14]],
        [[['+', '-'], 3], [['*', '-'], 12], [['/', '/'], 4]],
        [[4, 3, 8], [5, 7, 2], [6, 9, 1]])
    # solver = SolverBFS(puzzle)
    solver = SolverBacktracking(puzzle)
    solver.solve()
    solver.printSolution()
    print(solver.goal == solver.solution)

    for i in range(1):
        size = 16
        cmpuzz = createCrossMathPuzzle(size)
        puzzle = tests.crossMathTests.CrossMathPuzzle(cmpuzz[0], cmpuzz[1], cmpuzz[2])
        totalActions = [list(perm) for perm in itertools.permutations(range(1, size + 1), int(math.sqrt(size)))]
        import project.problems.CrossMath as CrossMath

        # [[['*', '*', '-'], 1556], [['*', '*', '-'], 196], [['+', '*', '-'], 159], [['*', '*', '*'], 220]]
        # [[['*', '+', '-'], 80], [['-', '+', '-'], 1], [['+', '*', '-'], 133], [['+', '*', '-'], 206]]
        # [[13, 15, 8, 4], [5, 6, 7, 14], [16, 3, 9, 12], [1, 11, 2, 10]]

        print('total Actions = 281788416ish is a goodish cutoff')
        print('total Actions = ' + str(CrossMath.calculateComplexity(totalActions, cmpuzz[0])))
        time.sleep(5)
        solver = SolverBacktracking(puzzle)
        time1 = time.time()
        print()
        print(cmpuzz[0])
        print(cmpuzz[1])
        print(cmpuzz[2])
        solver.solve()
        print('Found solution:')
        print(solver.solution)
        time2 = time.time()
        print('Time required = ' + str(time2 - time1) + ' seconds')
        if(solver.goal != solver.solution):
            print("DIFFERING SOLUTIONS, MAKE SURE MINE IS VALID")
    # cmpuzz = createCrossMathPuzzle(4)
    # puzzle = tests.crossMathTests.CrossMathPuzzle(cmpuzz[0], cmpuzz[1], cmpuzz[2])
    # solver = SolverBacktracking(puzzle)
    # solver.solve()
    # print()
    # print(cmpuzz[0])
    # print(cmpuzz[1])
    # print(cmpuzz[2])
    # solver.printSolution()

    # puzzle = Cryptarithmetic.CryptarithmeticPuzzle(
    #     [[None, 'S','E','N','D'], [None, 'M','O','R','E']], ['M','O','N','E','Y'],[])
    # solver = SolverBacktracking(puzzle)
    # solver.solve()
    # solver.printSolution()


    # tc2 = Cryptarithmetic.CryptarithmeticPuzzle([['F','O','O'], ['B','A','R']], ['B','A','Z'],[])
    # solver = SolverBacktracking(tc2)
    # solver.solve()
    # solver.printSolution()
    # print(solver.solution == None)
    #
    #
    # tc2 = Cryptarithmetic.CryptarithmeticPuzzle([['A'], ['B']], ['C'], [])
    # solver = SolverBacktracking(tc2)
    # solver.solve()
    # solver.printSolution()
    # pass