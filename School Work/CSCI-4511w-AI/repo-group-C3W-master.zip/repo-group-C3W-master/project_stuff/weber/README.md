Benjamen Weber stuff used to collect project data
