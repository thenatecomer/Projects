import sys,os

import itertools

import math

sys.path.append('algorithms')
sys.path.append('problems')
sys.path.append( os.path.realpath('..') + '/class-repo/projectClasses' )

#### Benjamen Weber SolverClass ###########################################################
import project.algorithms.bfs as bfs
import project.problems.CrossMath as CrossMath
import project.tests.crossMathTests as crossMathTests
from project.tests.createCrossMath import *
import time

class SolverBFS(object):
    # The input parameters must be as is here
    def __init__(self, testCase, goal=None):
        self.testCase = testCase
        self.goal = testCase.solution
        self.solution = None
        self.userid = 'webe0491'  ### PUT THE PERSON WHO WROTE THE ALGORITHM HERE!!
        # This is a good place to create a problem instance.

    # return a solution in the specified format
    # An instance of a solver will be specific to the testCase, thus
    # the details of how to handle it will be hidden inside this method.
    def solve(self):
        problem = CrossMath.CrossMathProblem(self.testCase)
        self.solution = bfs.BFS(problem)
        return self.solution

    # print the solution in a user-friendly way
    def printSolution(self):
        if self.solution:
            for row in self.solution:
                print(row)
        else:
            print('No solution for input problem.')


if __name__ == '__main__':
    puzzle = crossMathTests.CrossMathPuzzle(
        [[['+', '+'], 15], [['+', '*'], 24], [['+', '-'], 14]],
        [[['+', '-'], 3], [['*', '-'], 12], [['/', '/'], 4]],
        [[4, 3, 8], [5, 7, 2], [6, 9, 1]])
    # solver = SolverBFS(puzzle)
    solver = SolverBFS(puzzle)
    solver.solve()
    solver.printSolution()
    print(solver.goal == solver.solution)


    for i in range(30):
        size = 16
        cmpuzz = createCrossMathPuzzle(size)
        puzzle = crossMathTests.CrossMathPuzzle(cmpuzz[0], cmpuzz[1], cmpuzz[2])
        solver = SolverBFS(puzzle)
        totalActions = [list(perm) for perm in itertools.permutations(range(1, size + 1), int(math.sqrt(size)))]
        print('total Actions = 281788416ish is a goodish cutoff')
        actionsCount = CrossMath.calculateComplexity(totalActions, cmpuzz[0])
        print('total Actions = ' + str(actionsCount))
        if(actionsCount > 581788416):
            print('Too large total actions, skipping')
            continue
        time.sleep(3)
        print()
        print(cmpuzz[0])
        print(cmpuzz[1])
        print(cmpuzz[2])
        time1 = time.time()
        solver.solve()
        time2 = time.time()
        print('Found solution:')
        print(solver.solution)
        print('Time required = ' + str(time2 - time1) + ' seconds')
        print('total Actions = 281788416ish is a goodish cutoff')
        print('total Actions = ' + str(CrossMath.calculateComplexity(totalActions, cmpuzz[0])))
        if(solver.goal != solver.solution):
            print("DIFFERING SOLUTIONS, MAKE SURE MINE IS VALID")
    # cmpuzz = createCrossMathPuzzle(4)
    # puzzle = tests.crossMathTests.CrossMathPuzzle(cmpuzz[0], cmpuzz[1], cmpuzz[2])
    # solver = SolverBacktracking(puzzle)
    # solver.solve()
    # print()
    # print(cmpuzz[0])
    # print(cmpuzz[1])
    # print(cmpuzz[2])
    # solver.printSolution()

    # puzzle = Cryptarithmetic.CryptarithmeticPuzzle(
    #     [[None, 'S','E','N','D'], [None, 'M','O','R','E']], ['M','O','N','E','Y'],[])
    # solver = SolverBacktracking(puzzle)
    # solver.solve()
    # solver.printSolution()


    # tc2 = Cryptarithmetic.CryptarithmeticPuzzle([['F','O','O'], ['B','A','R']], ['B','A','Z'],[])
    # solver = SolverBacktracking(tc2)
    # solver.solve()
    # solver.printSolution()
    # print(solver.solution == None)
    #
    #
    # tc2 = Cryptarithmetic.CryptarithmeticPuzzle([['A'], ['B']], ['C'], [])
    # solver = SolverBacktracking(tc2)
    # solver.solve()
    # solver.printSolution()
    # pass