#Nqueens for benji.

from copy import deepcopy,copy
import random
import itertools
import math


def invalidRows(state):
    # returns true if there are duplicates in the state.
    return (len(set(state)) != len(state))
    pass


def invalidDiagonals(state):
    for i in range(len(state)):
        testvalue = state[i]
        for j in range(len(state)):
            #based on the distance from 0 of i, the offset we check for diagonals change.
            offset = abs(i-j)
            if j == i:
                continue
            if state[j] + offset == testvalue or state[j] - offset == testvalue:
                return True
    return False


class nQueensProblem(object):
    def __init__(self, n, evalFn=None, goal=None  ):
        # Initial state is an object of type CrossMathPuzzle
        self.size = n

        self._actions = [i for i in range(self.size)]

        self._backtrackactions = iter(range(self.size))

        self.initial = []
        self.size = self.size
        self.goal = goal
        self.evalFn = evalFn

    # Potential additional method of getNeighbors, but essentially this is the same as expanding a node
    # so really not necessary.
    # return [ applyAction( state, a) for a in getActions( state ) ]

    # returns a unique action generator.
    def _permgen(self):
        return copy(self._backtrackactions)


    def getActions( self, state ) :
        # produce a list of actions to be applied to the current state
        # Pruning could happen here (i.e. only generate legal actions that result in legal states)
        # Completed state
        if(len(state) == self.size):
            return []
        else:
            validActions = []
            for action in self._actions:
                newState = deepcopy(state)
                newState.append(action)
                if invalidRows(newState):
                    continue

                if invalidDiagonals(newState):
                    continue

                validActions.append(action)
            return validActions

    #returns an iterable used by the DFS algorithm.
    def getActionGenerator(self, state):
        #verify the state works is legal.  If it is not legal then return empty list representing no possible further actions.
        if(len(state) < self.size):
            return self._permgen()
        else:
            return []

    def applyActionGenerator(self, state, action):
        if action == None:
            return None
        else :

            newState = deepcopy(state)
            newState.append(action)

            if invalidRows(state):
                return None

            if invalidDiagonals(state):
                return None
            return newState

    def applyAction ( self, state, action ) :
        if action == None:
            return []
        else :
            newState = deepcopy(state)
            newState.append(action)
            return newState

    def isGoal ( self, state ):
        # Determine if current state is goal
        # Do we have a completely filled in state.
        # print(state)
        if(state == None):
            return False
        if(len(state) != self.size):
            return False

        if invalidRows(state):
            return False

        if invalidDiagonals(state):
            return False
        return True

