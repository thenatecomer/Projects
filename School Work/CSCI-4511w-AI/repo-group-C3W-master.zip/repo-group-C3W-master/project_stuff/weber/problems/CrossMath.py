# CrossMathPuzzle created by Benjamen Weber
# webe0491
# 4593981

from copy import deepcopy
from copy import copy
import operator
import itertools
import math

opDict = {'+': operator.add,
       '-': operator.sub,
       '*': operator.mul,
       '/': operator.truediv,
       '==': operator.eq,
       '!=': operator.ne,
       '<': operator.lt,
       '<=': operator.le,
       '>': operator.gt,
       '>=': operator.ge,
       'abs': operator.abs,
       '^': operator.pow
       }

# Checks if an action would violate a row equation.
# Action is a list of numbers e.g. [1,2,3]
# row is a Cross Math equation e.g. [['-', '+'], 12]
def validRow(action, row):
    ops, rowValue = row
    actionValue = 0
    for opIndex in range(len(ops)):
        if (opIndex == 0):
            actionValue = opDict[ops[opIndex]](action[opIndex], action[opIndex + 1])
        else:
            actionValue = opDict[ops[opIndex]](actionValue, action[opIndex + 1])
    if (actionValue != rowValue):
        return False
    return True

# def sieve(rowactions, colactions, colIndex, rowIndex):
#     validIntersect = []
#     for  rowaction in rowactions:
#         for colaction in colactions:
#             if rowaction[colIndex] == colaction[rowIndex]:
#                 validIntersect.append(rowaction)
#                 break
#     return validIntersect

def sieveAll(rowactions, all_colactions, rowIndex):
    validIntersects = []
    for rowaction in rowactions:
        hitcount = 0
        for j in range(len(rowaction)):
            #for each element of the row action, verify it belongs in some col_action
            currentColumnActions = all_colactions[j]
            for colaction in currentColumnActions:
                if rowaction[j] == colaction[rowIndex]:
                    hitcount +=1
                    # validIntersect.append(rowaction)
                    break
        if(hitcount == len(rowaction)):
            validIntersects.append(rowaction)
    return validIntersects


# def validCol(action, col):
#     # check all the columns
#     ops, value = col
#     actionValue = 0
#     for opIndex in range(len(ops)):
#             if (opIndex == 0):
#                 stateValue = opDict[ops[opIndex]](stateCol[opIndex], stateCol[opIndex + 1])
#             else:
#                 stateValue = opDict[ops[opIndex]](stateValue, stateCol[opIndex + 1])
#         if (stateValue != value):
#             return True
#     return False


#Finds complexity of a given puzzle based on the number of possible row combinations.
def calculateComplexity(actions, rowEquations):
    total = 1
    for row in rowEquations:
        validActions = [action for action in actions if validRow(action, row)]
        total *= len(validActions)
    return total

class CrossMathProblem(object):
    def __init__(self, initialState, evalFn=None, goal=None  ):
        # Initial state is an object of type CrossMathPuzzle
        self._rows = initialState.rows
        self._cols = initialState.cols
        self._size = initialState.size
        self._solution = initialState.solution
        self._actions = [list(perm) for perm in itertools.permutations(range(1, self._size +1), int(math.sqrt(self._size)))]

        self._allcolactions = []
        for col in self._cols:
            self._allcolactions.append([action for action in self._actions if validRow(action, col)])

        self._backtrackactions = itertools.permutations(range(1, self._size + 1), int(math.sqrt(self._size)))

        self.initial = []
        self.size = self._size
        self.goal = goal
        self.evalFn = evalFn

    # Potential additional method of getNeighbors, but essentially this is the same as expanding a node
    # so really not necessary.
    # return [ applyAction( state, a) for a in getActions( state ) ]

    # returns a unique action generator.
    def _permgen(self):
        return copy(self._backtrackactions)

    def getRandomAction( self, state ):
        # randomly produce a single action applicable for this state
        return None

    def getActions( self, state ) :
        # produce a list of actions to be applied to the current state
        # Pruning could happen here (i.e. only generate legal actions that result in legal states)
        # Completed state
        if(len(state) == len(self._rows)):
            return []

        actions = self._actions

        #prune out possible actions which don't satisfy the current row's required equation.
        rowIndex = len(state)
        actions = [action for action in actions if validRow(action, self._rows[rowIndex])]

        #prune out actions which contain numbers already in the state
        if (len(state) != 0):
            flattened = [item for sublist in state for item in sublist]
            assignedValues = set(flattened)
            actions = [action for action in actions if (len(assignedValues - set(action)) == len(assignedValues))]
        return actions

    #returns an iterable used by the DFS algorithm.
    def getActionGenerator(self, state):
        #verify the state works is legal.  If it is not legal then return empty list representing no possible further actions.
        if(len(state) < len(self._rows)):
            return self._permgen()
        else:
            return []

    def applyActionGenerator(self, state, action):
        if not action:
            return None
        else :
            action = list(action)
            rowIndex = len(state)

            #Make sure the action would not violate any row equations
            if not validRow(action, self._rows[rowIndex]):
                return None

            #Make sure the action has valid values based on the possible columns for this puzzle.
            if [] == sieveAll([action], self._allcolactions, rowIndex):
                return None

            # prune out actions which contain numbers already in the state
            flattened = [item for sublist in state for item in sublist]
            assignedValues = set(flattened)
            if (len(state) != 0):
                if (len(assignedValues - set(action)) != len(assignedValues)):
                    return None

            newState = deepcopy(state)
            newState.append(action)
            return newState

    def applyAction ( self, state, action ) :
        # Does nothing but copy the current state. This will be problem specific.
        # Apply the action to the current state to produce a new state
        # If you did not check for illegal states in getActions, then check for illegal states here
        # Can evaluate node based on path cost, heuristic function, or fitness function
        if not action :
            return []
        else :
            #the action we receive is a tuple, since our generator returns a tuple not a list.  Need to conver it.
            action = list(action)
            newState = deepcopy(state)
            newState.append(action)
            return newState

    def evaluation(self, state):
        if not self.evalFn :
            return 0
        else :
            state.evaluate( state.evalFn )

    def isGoal ( self, state ):
        # Determine if current state is goal
        # Do we have a completely filled in state.
        # print(state)
        if(len(state) > len(self._rows)):
            raise RuntimeError

        flattened = [item for sublist in state for item in sublist]
        if(len(flattened) != self._size):
            return False

        #check all the rows.
        # unnecessary, rows are always valid by the time they reach here
        if(invalidRows(state, self._rows)):
            return False


        if(invalidCols(state, self._cols)):
            return False

        # Check if there are duplicate values.
        # Unnecessary, the getaction function only continues if the values are all unique.
        flattened = [item for sublist in state for item in sublist]
        if(len(flattened) != len(set(flattened))):
            return False

        # None of the rules of crossmath have been violated so this is a goal state.
        return True

# Unused by DFS.  add at a later date.
class ProblemState(object):
    def __init__( self, state, size, value=0 ):
        self.state = state
        self.value = value
        self.size = size

    def evaluate( self, evalFn ):
        self.value = evalFn( self.state )

    def isGoal( self ) :
                # Some problems have rules that determine the goal state (e.g. Sudoku), while other problems
                # have a known goal state (e.g. Sliding Puzzle).
                # It might be appropriate to leave goal checking to this State class, or it might be better to
                # have it checked in the Problem State.
                return False

    def __str__( self ) :
                # Converts the state representation to a string (nice for printing)
                return str( self.state )

# Finds if a given state violates the equations in the CrossMath puzzle.
# rows contains these equations.
def invalidRows(state, rows):
    for i in range(len(state)):
        ops, value = rows[i]
        stateRow = state[i]
        stateValue = 0
        for opIndex in range(len(ops)):
            if (opIndex == 0):
                stateValue = opDict[ops[opIndex]](stateRow[opIndex], stateRow[opIndex + 1])
            else:
                stateValue = opDict[ops[opIndex]](stateValue, stateRow[opIndex + 1])
        if (stateValue != value):
            return True
    return False

# Finds if a given state violates the equations in the CrossMath puzzle.
# cols contains these equations.
def invalidCols(state, cols):
    transposeState = []
    # transpose the puzzle, so that it becomes a list of lists where each inner list is a column of the crossmath puzzle.
    for i in range(len(state)):
        column = []
        for j in range(len(state)):
            column.append(state[j][i])
        transposeState.append(column)
    # check all the columns
    for i in range(len(state)):
        ops, value = cols[i]
        stateCol = transposeState[i]
        stateValue = 0
        for opIndex in range(len(ops)):
            if (opIndex == 0):
                stateValue = opDict[ops[opIndex]](stateCol[opIndex], stateCol[opIndex + 1])
            else:
                stateValue = opDict[ops[opIndex]](stateValue, stateCol[opIndex + 1])
        if (stateValue != value):
            return True
    return False

# rows = [[['+', '+'], 15], [['+', '*'], 24], [['+', '-'], 14]]
# state = [[4,3,8],[5,7,2],[6,9,1]]
#
# print(invalidRows(state, rows))
# print(invalidRows([[4,5,8],[5,7,2],[6,9,1]], rows))
