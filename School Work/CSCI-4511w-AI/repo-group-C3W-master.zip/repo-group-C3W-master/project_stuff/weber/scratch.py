#10-21 1224pm version
rows = [[['*', '+', '-'], 27], [['*', '+', '-'], 116], [['-', '+', '*'], 66], [['*', '*', '-'], 269]]
cols = [[['+', '-', '-'], -2], [['*', '-', '-'], 59], [['*', '*', '*'], 420], [['-', '*', '-'], -5]]
#sol = [[8, 5, 3, 16], [9, 13, 14, 15], [12, 2, 1, 6], [7, 4, 10, 11]]


import math, itertools
from project.problems.CrossMath import *

def sieve(rowactions, colactions, colIndex, rowIndex):
    validIntersect = []
    for  rowaction in rowactions:
        for colaction in colactions:
            if rowaction[colIndex] == colaction[rowIndex]:
                validIntersect.append(rowaction)
                break
    return validIntersect

def sieveAll(rowactions, all_colactions, rowIndex):
    validIntersects = []
    for rowaction in rowactions:
        hitcount = 0
        for j in range(len(rowaction)):
            #for each element of the row action, verify it belongs in some col_action
            currentColumnActions = all_colactions[j]
            for colaction in currentColumnActions:
                if rowaction[j] == colaction[rowIndex]:
                    hitcount +=1
                    # validIntersect.append(rowaction)
                    break
        if(hitcount == len(rowaction)):
            validIntersects.append(rowaction)
    return validIntersects

if __name__ == '__main__':
    actions = [list(perm) for perm in itertools.permutations(range(1, 16 + 1), int(math.sqrt(16)))]
    allcolactions = []
    for col in cols:
        allcolactions.append([action for action in actions if validRow(action, col)])

    row0actions = [action for action in actions if validRow(action, rows[0])]
    print('len row0actions:' + str(len(row0actions)))
    validintersects = sieveAll(row0actions, allcolactions, 0)
    print('len of validintersects:' + str(len(validintersects)))
    pass
