import random

#Benjamen Weber maze generator
#uses a variation of prims algorithm to have 'rooms' instead of just corridors.
#todo doesn't create an explicit exit
class MazeGenerator():
    def __init__(self, width =5, height = 5, wallChar = '@', floorChar='.', startPosition= (0,0), endPosition = None):
        self.width = width
        self.height = height
        self.wallChar = wallChar
        self.floorChar = floorChar
        self.rng = random.seed

        self.startPosition = startPosition
        if (endPosition == None):
            self.endPosition = (width-1,height-1)
        else:
            self.endPosition = endPosition

    def isAWall(self, pos, maze):
        if(pos[0] < len(maze) and pos[1] < len(maze[0])):
            return maze[pos[0]][pos[1]] == self.wallChar

    def addWalls(self, wallsList, maze, pos):
        xpos = pos[0]
        ypos = pos[1]
        if (xpos < self.width - 1):
            right = (pos[0] + 1, pos[1])
            if(self.isAWall(right, maze)):
                wallsList.append(right)
        if (xpos > 0):
            left = (pos[0] - 1, pos[1])
            if(self.isAWall(left, maze)):
                wallsList.append(left)
        if (ypos < self.height - 1):
            down = (pos[0], pos[1]+1)
            if (self.isAWall(down, maze)):
                wallsList.append(down)
        if (ypos > 0):
            up = (pos[0], pos[1] - 1)
            if (self.isAWall(up, maze)):
                wallsList.append(up)

    def only_one_divided_cell_visited(self, wall, maze):
        xpos = wall[0]
        ypos = wall[1]
        right = None
        left = None
        up = None
        down = None
        upright = None
        upleft = None
        downleft = None
        downright = None
        if (xpos < self.width - 1):
            right = (xpos + 1, ypos)
        if (xpos > 0):
            left = (xpos - 1, ypos)
        if (ypos < self.height - 1):
            down = (xpos, ypos + 1)
        if (ypos > 0):
            up = (xpos, ypos - 1)
        if (ypos > 0 and xpos > 0):
            upleft = (xpos - 1, ypos - 1)
        if (ypos < self.height -1 and xpos < self.width - 1):
            downright = (xpos + 1, ypos + 1)
        if (ypos > 0 and xpos < self.width - 1):
            upright = (xpos + 1, ypos - 1)
        if (ypos < self.height - 1 and xpos > 0):
            downleft = (xpos - 1, ypos + 1)

        #if an opposite cell does not exist, then we only care if the existent cell is visited
        rightVisited = True
        leftVisited = True
        upVisited = True
        downVisited = True
        uprightVisited = True
        upleftVisited = True
        downleftVisited = True
        downrightVisited = True
        if (right == None or maze[right[0]][right[1]] == self.wallChar):
            rightVisited = False
        if (up == None or maze[up[0]][up[1]] == self.wallChar):
            upVisited = False
        if (left == None or maze[left[0]][left[1]] == self.wallChar):
            leftVisited = False
        if (down == None or maze[down[0]][down[1]] == self.wallChar):
            downVisited = False
        if (upright == None or maze[upright[0]][upright[1]] == self.wallChar):
            uprightVisited = False
        if (upleft == None or maze[upleft[0]][upleft[1]] == self.wallChar):
            upleftVisited = False
        if (downleft == None or maze[downleft[0]][downleft[1]] == self.wallChar):
            downleftVisited = False
        if (downright == None or maze[downright[0]][downright[1]] == self.wallChar):
            downrightVisited = False

        if(rightVisited and leftVisited):
            return False
        if(upVisited and downVisited):
            return False
        if(upleftVisited and upVisited and leftVisited):
            return False
        if(uprightVisited and rightVisited and upVisited):
            return False
        if(downleftVisited and downVisited and leftVisited):
            return False
        if(downrightVisited and downVisited and rightVisited):
            return False
        return True

    def generatePrimMaze(self):
        # generate width x hieght maze
        maze = []
        for i in range(self.width):
            row = []
            for j in range(self.height):
                row.append(self.wallChar)
            maze.append(row)

        # Start with a grid full of walls.
        # Pick a cell, mark it as part of the maze. Add the walls of the cell to the wall list.
        maze[self.startPosition[0]][self.startPosition[1]] = self.floorChar

        walls = []
        self.addWalls(walls, maze, self.startPosition)


        # While there are walls in the list:
        while(maze[self.endPosition[0]][self.endPosition[1]] != self.floorChar and len(walls) != 0):
            ## Pick a random wall from the list. If only one of the two cells that the wall divides is visited, then:
            randompos = random.randrange(len(walls))
            wall = walls[randompos]
            if(self.only_one_divided_cell_visited(wall, maze)):
                ### Make the wall a passage and mark the unvisited cell as part of the maze.
                maze[wall[0]][wall[1]] = self.floorChar
                ### Add the neighboring walls of the cell to the wall list.
                self.addWalls(walls, maze, wall)
            ## Remove the wall from the list.
            del walls[randompos]

        #just in case make sure the endposition is a floor character.

        if(maze[self.endPosition[0]][self.endPosition[1]] != self.floorChar):
            #generate a path from the end position towards any corridor to ensure there is a path from start to end.
            testPosition = maze[self.endPosition[0]][self.endPosition[1]]
            xpos = self.endPosition[0]
            ypos = self.endPosition[1]
            while(testPosition == self.wallChar):
                maze[xpos][ypos] = self.floorChar
                if(1 == random.randint(0,1)):
                    xpos-=1
                    testPosition = maze[xpos][ypos]
                else:
                    ypos -= 1
                    testPosition = maze[xpos][ypos]

        #surround with buffer walls, top, bottom,
        topwall = []
        botwall = []
        for i in range(self.width+2):
            topwall.append(self.wallChar)
            botwall.append(self.wallChar)

        for row in maze:
            row.insert(0, self.wallChar)
            row.append(self.wallChar)

        maze.insert(0, topwall)
        maze.append(botwall)

        newMaze = []
        for row in maze:
            s =''
            for c in row:
                s+=c
            newMaze.append(s)

        return newMaze


if __name__ == "__main__":
    #mazeGenerator = MazeGenerator()
    #maze = mazeGenerator.generatePrimMaze()
    #for row in maze:
    #    s = ''
    #    for char in row:
    #        s += char
    #    print(s)

    #example output
    # .........@..@...........@@.@..
    # @.@.@@.@...@..@.@.@@@.@.@..@.@
    # @.@......@@.@.@.....@@.@@@.@..
    # ....@.@.@......@.@@.....@....@
    # .@.@.@..@.@@.@......@.@...@@.@
    # @@.@..@..@@...@@.@.@.@.@.@..@.
    # ....@.@@....@.....@.......@...
    # .@@....@.@@...@.@..@.@@.@..@.@
    # ...@.@...@@.@@..@@@.......@...
    # .@.....@......@.....@@@@.@@.@.
    # ...@@.@@@.@@@..@.@.@.........@
    # .@....@@....@.@.....@.@@@.@@..
    # .@@.@....@@.....@.@........@.@
    # ..@...@.@...@.@.....@.@@.@@..@
    # @.@@.@@..@@...@.@@.@...@....@@
    # ........@...@.@......@@@@.@.@@
    # @.@.@.@...@.@...@.@@@@.@.@...@
    # @.@..@..@.@...@.@..........@.@
    # ....@..@..@.@@.@@@@.@@.@.@....
    # .@.@@@...@......@........@.@@.


    #test only_one_divided_cell_visited(self, wall, maze)
    test = MazeGenerator()
    maze = [['.', '.', '@', '@', '@', '@', '@'],
            ['.', 'FAIL', '@', '@', '@', '@', '@'],
            ['@', '@', '@', '@', '@', '.', '@'],
            ['@', '@', '.', '@', '@', 'FAIL', '.'],
            ['@', '@', 'FAIL', '@', '@', '@', '@'],
            ['@', '@', '.', '@', '@', '@', '@'],
            ['@', '@', '@', '@', '@', '@', '@'],
            ]
    # expectFalse = test.only_one_divided_cell_visited((1, 1), maze)
    # print('Expect False :' +str(expectFalse))
    # expectFalse = test.only_one_divided_cell_visited((2, 4), maze)
    # print('Expect False :' + str(expectFalse))
    # expectFalse = test.only_one_divided_cell_visited((5,3), maze)
    # print('Expect False :' + str(expectFalse))
