from BidirectionalMazePuzzle import BdMazePuzzle
from BidirectionalAstar import BdAstarSearch

class Solver(object):
    # The input parameters must be as is here
    def __init__(self, testCase, goal=None):
        self.testCase = testCase
        self.goal = goal
        self.solution = None
        self.userid = "comer028"  ### PUT THE PERSON WHO WROTE THE ALGORITHM HERE!!

        # This is a good place to create a problem instance.

        # return a solution in the specified format
        # An instance of a solver will be specific to the testCase, thus
        # the details of how to handle it will be hidden inside this method.
        def solve(self):
            return None

        # print the solution in a user-friendly way
        def printSolution(self):
            if self.solution:
                print(self.solution)

                # You can modify your solver class in any way, provided that above methods exist

from BidirectionalMazePuzzle import BdMazePuzzle
#from SlidingPuzzle import SlidingPuzzle
from BidirectionalAstar import BdAstarSearch
#from SlidingPuzzle import SlidingState

class SolverBdAStar(Solver):
    def __init__(self, testCase, problem_type = 'sliding', width = 0, height = 0):
        Solver.__init__(self, testCase)
        self.puzzle = testCase
        self.width = width
        self.height = height
        self.solution = None
        self.userid = "comer028"
        self.problem_type = problem_type

    def solve(self):
        if self.problem_type == 'maze':
            search = BdAstarSearch(self.puzzle.puzzle, self.width, self.height)
            self.solution = search.BdAstar(self.puzzle)
        elif self.problem_type == 'sliding':
            search = BdAstarSearch(self.puzzle.state.state, self.widthm, self.height)
            self.solution = search.BdAstar(self.puzzle)
        return self.solution

        # print the solution in a user-friendly way
    def printSolution(self):
        if self.solution:
            print(self.solution)


#test = SolverBdAStar(BdMazePuzzle("maze10.txt", 10, 10, .5, .5), 'maze', 10, 10)
#print(test.solve())

#test = SolverBdAStar(BdMazePuzzle("maze40.txt", 40, 40, .5, .5), 'maze', 40, 40)
#print(test.solve())

