import sys, os

sys.path.append(os.path.realpath('..') + '/repo-group-C3W/CSP')

from CSPclasses import PuzzleType
from CSPclasses import AlgoType
from CSPclasses import AlgoImplementation
from CSPclasses import PuzzleImplementation
from CSPclasses import InputPuzzleClass
from Futoshiki import Futoshiki
import CSPclasses
from AC3 import AC3
from GridPuzzleBaseClass import GridPuzzleBaseClass
import CSPtestCases
import CrossMath
import BacktrackingCSP

# _______________________________________________________________________
# PROVIDE the following for Puzzle and Algorithm Implementation:
#         THE INFORMATION BELOW REGARDING AUTHORSHIP AND IMPLEMENTATION STATUS IS REQUIRED
#         Your team can collectively create implementation classes here or in separate files
#         Make sure that paths are set properly.
# _______________________________________________________________________

### PUZZLES
##       -- If anyone completed an extra puzzle, create an instance and set algo.bonus = True


# >>>>>>> APPEND TO THIS LIST with puzzle implementation instances
puzzlesImplemented = []

ken = CSPclasses.PuzzleImplementation(CSPclasses.PuzzleType.kenken)
ken.authors = ['comer028', 'will4379']
ken.status = CSPclasses.StatusType.Complete
ken.comments = ''
puzzlesImplemented.append(ken)

futo = CSPclasses.PuzzleImplementation(CSPclasses.PuzzleType.futoshiki)
futo.authors = ['comer028', 'will4379']
futo.status = CSPclasses.StatusType.Complete
futo.comments = 'BONUS Implementation: Implemented by Nathan Comer and Lee Williams as our bonus implementation '
puzzlesImplemented.append(futo)

#crypt = CSPclasses.PuzzleImplementation(CSPclasses.PuzzleType.crypt)
#crypt.authors = None
#crypt.bonus = True
#crypt.status = CSPclasses.StatusType.NotSelected
#crypt.comments = 'Cryptarithmetic can decipher 2 words of any length with ops + and -.'
#puzzlesImplemented.append(crypt)

xmath = CSPclasses.PuzzleImplementation(CSPclasses.PuzzleType.crossmath)
xmath.authors = ['webe0491','wongx565']
xmath.status = CSPclasses.StatusType.Complete
xmath.comments = 'Hard coded for 2,3,4,5 size xmath puzzles'
puzzlesImplemented.append( xmath)

#### ALGORITHMS
##        -- AC3 and Backtracking are required parts of this assignment
##        -- Please create a class instance for each type of backtracking (with mac and forward-checking)
##        -- Create an additional class for any variable or value ordering implentation
##
##  IF your team produced multiple versions, please create a separate instance for each implementation


# >>>>>>> APPEND TO THIS LIST with algorithm implementation instances
algosImplemented = []

ac3imp = CSPclasses.AlgoImplementation(CSPclasses.AlgoType.AC3)
ac3imp.authors = ['comer028', 'will4379']
ac3imp.status = CSPclasses.StatusType.Complete
ac3imp.comments = 'Implemented by Nathan Comer and Lee Williams, .printDomain() can be used after running .solve() to see the domains'
algosImplemented.append(ac3imp)

backMac = CSPclasses.AlgoImplementation(CSPclasses.AlgoType.backtrackMAC)
backMac.authors = ['webe0491', 'wongx565']
backMac.status = CSPclasses.StatusType.Incomplete
algosImplemented.append(backMac)

backFC = CSPclasses.AlgoImplementation(CSPclasses.AlgoType.backtrackFC)
backFC.authors = ['webe0491', 'wongx565']
backFC.status = CSPclasses.StatusType.Complete
algosImplemented.append(backFC)

# Here is how you would test 2 different implementations of the same algorithm
#back2 = CSPclasses.AlgoImplementation(CSPclasses.AlgoType.backtrackMAC)
# ...

#deg = CSPclasses.AlgoImplementation(CSPclasses.AlgoType.degreeHeuristic)
#deg.authors = None
#deg.status = CSPclasses.StatusType.NotSelected
#deg.bonus = False
#algosImplemented.append(deg)

def generateConstraintsandDomain(puzzle, problemSetup):
    if puzzle.pType == PuzzleType.kenken:
        return problemSetup.kenkenSetup(puzzle.size[0], puzzle.puzzle, puzzle.solution)
    elif puzzle.pType == PuzzleType.futoshiki:
        f = Futoshiki(puzzle)
        return [f.neighbors, f.domains, f.constraints]
    elif puzzle.pType == PuzzleType.crypt:
        return problemSetup.cryptSetup(puzzle.size, puzzle.puzzle, puzzle.solution)
    elif puzzle.pType == PuzzleType.crossmath:
        #Calls our CrossMath module's builder thing.
        return CrossMath.crossmathSetup(puzzle.size, puzzle.puzzle, puzzle.solution)
    elif puzzle.pType == PuzzleType.other:
        raise RuntimeError('PuzzleType other unimplemented')
    else:
        raise RuntimeError('PuzzleType' + str(puzzle.pType) + 'is not a valid PuzzleType')


def SolverCSP(puzzle, algorithm):
    problemSetup = GridPuzzleBaseClass()

    # generateConstraintsandDomain must return a list: (neighbors, domains, constraints)
    arguments = generateConstraintsandDomain(puzzle, problemSetup)

    # Constraints format: dictionary where keys are a single variable and values are a list: ([all variables],[constraint])
        # Example: x + y + z = 5: {x: ((x,y,z),lambda), y: ((y,x,z),lambda), z: ((z,x,y),lambda)}
    # Neighbors format: Format generated from the createTableNeighbors function within gridPuzzleBaseClass
    # Domains format: dictionary where keys are variables (A0, A1, B1, etc.) and values are the remaining values in the variables domain

    if algorithm.impType == AlgoType.AC3:
        problem = AC3(arguments[0], arguments[1], arguments[2], puzzle.size[0])
    elif algorithm.impType == AlgoType.backtrackFC:
        problem = BacktrackingCSP.BacktrackCSP(arguments[0], arguments[1], arguments[2], puzzle.size[0],
                                               CSPclasses.AlgoType.backtrackFC)
    elif algorithm.impType == AlgoType.backtrackMAC:
        problem = BacktrackingCSP.BacktrackCSP(arguments[0], arguments[1], arguments[2], puzzle.size[0],
                                               CSPclasses.AlgoType.backtrackMAC)

    # this method must return an instance with methods .solve() and .printSolution()
    return problem


    # puzzle is of type CSPclasses.InputPuzzleClass
    # algorithm is of type CSPclasses.AlgoImplementation
    #
    # RETURN a class instance that has methods solve() and printSolution() with member solution

    # FILL THIS IN such that a grading script can be called that will ...


