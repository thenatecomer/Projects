import math
from copy import deepcopy
import random

class Maze:
    def __init__(self, fname = None):
        self.actions = ('U','D','R','L')
        self.maze = []
        if fname != None:
            self.load_maze(fname)
        self.goal = (len(self.maze)-1, len(self.maze)-1)
        self.isGoal = self.is_goal


    def getRandomAction(self,a=None,b=None): #other problems take two arguements, this one just puts a and b there to be compatible
        return random.choice(self.actions)

    def is_goal(self, pos):
        return pos == self.goal

    def load_maze(self, fname):
        f = open(fname, 'r')
        for line in f.readlines():
            self.maze.append(line)
    
    def manhattan_distance(self, pos1, pos2):
        return abs(pos1[0] - pos2[0]) + abs(pos1[1] - pos2[1]) 

    def maze_with_path(self, path):
        newmaze = deepcopy(self.maze)
        x = 1
        y = 1
        for step in path:
            candidate_x = x
            candidate_y = y
            if step == 'D':
                candidate_y +=1
            elif step == 'U':
                candidate_y -=1
            elif step == 'L':
                candidate_x -=1
            elif step == 'R':
                candidate_x +=1

            if newmaze[candidate_x][candidate_y] in ['.', '!']:
                x = candidate_x
                y = candidate_y
                newmaze[x] = newmaze[x][:y] + '!' + newmaze[x][y+1:] 
            else:
                return newmaze
        return newmaze 

    def path_to_state(self, path, strictness = 'partial'):
        x = 1
        y = 1
        for step in path:
            candidate_x = x
            candidate_y = y
            if step == 'D':
                candidate_y +=1
            elif step == 'U':
                candidate_y -=1
            elif step == 'L':
                candidate_x -=1
            elif step == 'R':
                candidate_x +=1
            if self.maze[candidate_x][candidate_y] == '.':
                x = candidate_x
                y = candidate_y
            else:
                return (x,y)
        return (x,y)
                
    def valid_path_length(self, path, strictness = 'partial'):
        x = 1
        y = 1
        length = 0
        for step in path:
            candidate_x = x
            candidate_y = y
            if step == 'D':
                candidate_y +=1
            elif step == 'U':
                candidate_y -=1
            elif step == 'L':
                candidate_x -=1
            elif step == 'R':
                candidate_x +=1
            if self.maze[candidate_x][candidate_y] == '.':
                x = candidate_x
                y = candidate_y
            else:
                return length
        return length
                
