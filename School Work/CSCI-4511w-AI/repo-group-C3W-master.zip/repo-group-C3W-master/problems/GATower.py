# an implementation of the Towers of Hanoi problem
# with specific functions added for genetic algorithms
#
# by Lee Williams, (will4379)

from collections import deque
from AIproblem import *
from copy import deepcopy
import random

class GAHanoi(AIproblem):
    def __init__(self, discs):
        self.discs = discs
        self.Explored = []

        # The following are to faciliate changes in rod indexing
        self.rod1 = 1
        self.rod2 = self.rod1 + 1
        self.rod3 = self.rod1 + 2

        self.state=[[],list(range(discs, 0, -1)),[],[]] # so index of first rod will be 1
        self.initial_state=[[],list(range(discs, 0, -1)),[],[]] # so index of first rod will be 1
        self.moves=( (self.rod1, self.rod2), (self.rod1, self.rod3),
                (self.rod2, self.rod1), (self.rod2, self.rod3),
                (self.rod3, self.rod1), (self.rod3, self.rod2))
        self.Explored.append(self.state)


    def getRandomAction(self, state, prune = True):
        return random.choice(self.getActions(state, prune))
                
    def getActions(self, state, prune = True):
        if not prune:
            return list(self.moves)

        possible_moves = []

        for move in self.moves:
            if not self.isValid(self.applyAction(state,move)):
                continue
            if tuple(self.applyAction(state, move)) in self.Explored:
                continue
            possible_moves.append(move)

        return possible_moves


    def getState(self):
        return self.state

    def isGoal(self,state):
        if len(state) == 0 or len(state[self.rod1]) > 0 or len(state[self.rod2]) > 0:
            return False
        else:
            return self.isValid(state)

    def isValid(self, state):
        if len(state) == 0:
            return False
        for peg in range(self.rod1,self.rod3 +1):
            if len(state[peg]) > 1:
                for i in range(len(state[peg]) -1):
                    if state[peg][i] < state[peg][i+1]:
                        return False
        return True

    def applyAction(self,state,move):
        # if this function is asked to move a disk off of an empty peg
        # it returns an empty list

        if len(state[move[0]]) == 0:
            return []

        newState = deepcopy(state)
        newState[move[1]].append(newState[move[0]].pop())

#       print(newState)
        return newState

    def print_state(self, state):
        height = max(len(state[self.rod1]),len(state[self.rod2]),len(state[self.rod3])) 
        while height >= 0:
            line = " "
            for i in range(self.rod1,self.rod3 +1):
                if height >= len(state[i]):
                    line += " |  "
                else:
                    line += " " + str(state[i][height]) + "  "
            print(line)
            height -= 1
        print("  ^___^___^")

    def path_to_state(self, path, strictness = "strict"):
        # This function takes a path, i.e a list of moves,
        # and tries to execute them, and turns the resulting state
        # The strictness determines what happens if an invalid state occurs
        # "strict" strictness returns an empty state upon failure
        # "partial" strictness returns the state up to the invalid state
        # "loose" strictness ignores the bad move and goes on to the next one
        state = deepcopy(self.initial_state)
        for move in path:
            trial_state = self.applyAction(state, move)
            if self.isValid(trial_state):
                state = trial_state
            else:
                if strictness == "strict":
                    return []
                elif strictness == "partial":
                    return state
        return state

    def valid_pathlength(self, path):
        count = 0
        state = deepcopy(self.initial_state)
        for move in path:
            trial_state = self.applyAction(state, move)
            if self.isValid(trial_state):
                state = trial_state
                count += 1
            else:
                break
        return count


    def print_path(self, path):
        print(self.path_to_str(path))

    def path_to_str(self, path):
        output = ""
        steps_in_line = 0
        for step in path:
            if steps_in_line >= 6:
                steps_in_line = 0
                output += "\n\t"
            output+= " [ " + str(step[0]) + " -> " + str(step[1]) + " ]"
            steps_in_line += 1
        return output

