import string

class GridPuzzleBaseClass2:
    def createTable(self, size):
        newlist = []
        for i in string.ascii_uppercase[:size]:
            for j in string.digits[1:size +1]:
                newlist.append( i+j )
        return newlist

    def createTableNeighbors(self, size):
        # for table-based puzzles like KenKen, the neighbors are the other cells
        # in the the same row and column
        # this function creates a dictionary with the variables as keys, and the 
        # values a list of variables
        # This function currently only works for up to 9 rows/columns.
        # It could easily be changed to do more.
        newdict = dict()
        for var in self.createTable(size):
            newdict[var] = []
        for i in string.ascii_uppercase[:size]:
            row = [i+j for j in string.digits[1:size +1]]
            for i in range(len(row)):
                for i in row:
                    for j in row:
                        if i != j and j not in newdict[i]:
                            newdict[i].append(j)
        for i in string.digits[1:size+1]:
            col = [j+i for j in string.ascii_uppercase[:size]]
            for i in range(len(col)):
                for i in col:
                    for j in col:
                        if i != j and j not in newdict[i]:
                            newdict[i].append(j)

        return newdict

    def generateAllDiff(self, constraintlist, neighbors):
        f = lambda x,y: x != y

        for k in list(neighbors.keys()):
            for neighbor in neighbors[k]:
                constraintlist[(k,neighbor)].append(f)

    def setupConstraintsDictionary(self, neighbors):
        # This function takes a list of neigbors and creates a dictionary
        # with keys consisting of variables and all neighbor pairs
        # and values equalling an empty list
        constraints = dict()
        for k in list(neighbors.keys()):
            constraints[k] = []
            for neighbor in neighbors[k]:
                constraints[(k,neighbor)] = []
        return constraints

    def setupPuzzle(self, size):
        self.neighbors = self.createTableNeighbors(size)
        self.constraints = self.setupConstraintsDictionary(self.neighbors)
        self.generateAllDiff(self.constraints, self.neighbors)
        self.domain = list(range(1, size +1))

    def puzzle(self):
        # A utility function that returns the main 3 parameters as a tuple
        return (self.neighbors, self.domain, self.constraints)
