from GridPuzzleBaseClass import GridPuzzleBaseClass
from CSPtestCases import *
import string

class Futoshiki(GridPuzzleBaseClass):
    def __init__(self, puzzle):
        puzzle_definition = self.convertPuzzle(puzzle)
        self.size = puzzle_definition[0]
        self.setupPuzzle(self.size)
        for rule in puzzle_definition[1]:
            if type(rule[1]) == int:
                self.constraints[rule[0]].append( lambda x : x == rule[1])
            else:
                self.constraints[rule].append(lambda x,y : x < y)
                self.constraints[(rule[1], rule[0])] = lambda x,y : x > y
        
    def convertPuzzle(self, puzzleClass):
        # This method converts the professor's futoshiki class into the format used in GridPuzzleBaseClass
        puzzle = []
        puzzle.append(puzzleClass.size[0])

        rules = []
        for rule in puzzleClass.puzzle:
            if type(rule[0]) == int:
                rules.append( (self.convertPair(rule[1]), rule[0])) 
            elif rule[0] == '<':
                rules.append( (self.convertPair(rule[1]), self.convertPair(rule[2])))
            elif rule[0] == '>':
                rules.append( (self.convertPair(rule[2]), self.convertPair(rule[1]) ) )
            else:
                throw('Invalid Puzzle Format')
        puzzle.append(rules)
        return puzzle

    def convertPair(self, pair):
        # This method takes in a [x,y] pair and returns a pair in the format  'A1'
        newPair = string.ascii_uppercase[pair[0]] + str(pair[1])
        return newPair


#f1 = (4, [('C1','B1'), ('C1', 'B1'), ('C1', 3), ('B2', 2), ('D3', 'D4'), ('C3', 'D3')] )
