# Cryptarithmetic created by Benjamen Weber
# webe0491
# 4593981

#Incomplete.
from copy import deepcopy
import operator
import itertools
import math

opDict = {'+': operator.add,
       '-': operator.sub,
       '*': operator.mul,
       '/': operator.truediv,
       '==': operator.eq,
       '!=': operator.ne,
       '<': operator.lt,
       '<=': operator.le,
       '>': operator.gt,
       '>=': operator.ge,
       'abs': operator.abs,
       '^': operator.pow
       }


#Newstate is a dictionary of character, value pairs
#Input words is a list of lists, with each list representing a word in the form ['W','O','R','D'], padded with
#  "None" so that all word lists have same length e.g. [[None, 'A','R'], ['F','O','O']]
#Output word is a single list representing a word as above.
def validAssignment(newState, inputwords, outputword):
    #Verify that the assignments in newState don't cause an incorrect state
    #e.g.  OOO + OOO = ZZZ, with O = 1 and Z = 3.
    #Start at end of the list, iterate to the front with a carry over value
    carry = 0
    revoutputword = list(reversed(outputword))
    for i in range(len(outputword)):
        unassignedInputChar = False
        columnValue = carry
        carry = 0
        for word in inputwords:
            word = list(reversed(word))
            char = word[i]
            if(char != None):
                value = newState.get(char)
                if value == None:
                    unassignedInputChar = True
                else:
                    # We only support addition as an operator.
                    columnValue += value
            elif(char == None):
                unassignedInputChar = True
        if (columnValue >= 10):
            carry = 1
        outputchar = revoutputword[i]
        if unassignedInputChar or outputchar == None or newState.get(outputchar) == columnValue or newState.get(outputchar) == columnValue + 1:
            continue
        else:
            return False
    return True





class CryptarithmeticPuzzle(object):
    def __init__(self, inputwords, outputword, solution = {}):
        #
        self.inputwords = inputwords
        self.outputword = outputword
        for word in inputwords:
            if(len(word) > len(outputword)):
                print('Invalid input puzzle!')

        #Solution is a dictionary of char,value pairs.  Char are letters in inputwords or outputword.  Values are 0-9.
        self.solution = solution


class CryptarithmeticProblem(object):
    def __init__(self, initialState, evalFn=None, goal=None  ):
        # Initial state is an object of type Cryptarithmetic
        self._inputwords = initialState.inputwords
        self._outputword = initialState.outputword

        # Can only be 1-9 digits for a cryptarithm character value.
        self._possibleCharacters = set()
        for word in self._inputwords:
            for char in word:
                if char != None:
                    self._possibleCharacters.add(char)
        for char in self._outputword:
            if char != None:
                self._possibleCharacters.add(char)
        #turn it back into a list so we can access it with indexing
        self._possibleCharacters = list(self._possibleCharacters)
        # self._actions = [i for i in range(1,10)]

        self.initial = dict()
        self.goal = goal
        self.size = len(self._possibleCharacters)
        self.evalFn = evalFn

    # returns a unique action generator.
    def _actiongenerator(self):
        # Our action is some permutation of 1-9 of length self._size.
        #  The state is then built from joining _possibleCharacters & a permutation to get an assc. array from chars to values.
        # return itertools.permutations(range(0, 10), self.size)
        return range(0,10)

    def getRandomAction( self, state ):
        # randomly produce a single action applicable for this state
        return None

    def getActions( self, state ) :
        # Unused by cryptarithmetic.
        return self._actions

    #returns an iterable used by the DFS algorithm.
    def getActionGenerator(self, state):
        #verify the state has further actions.  If it does not then return empty list representing no possible further actions.
        if(len(state) <= self.size):
            return self._actiongenerator()
        else:
            return []

    def applyActionGenerator(self, state, action):
        if action == None:
            return None
        else :
            #state is a dictionary of character,value pairs.
            #action is a tuple, left is a character, right is a number to assign to it.
            newState = deepcopy(state) #create new empty dictionary.

            currIndex = len(state)
            newState[self._possibleCharacters[currIndex]] = action

            #Verify no duplicates
            if(len(set(newState.values())) != len(newState.values())):
                return None

            if not validAssignment(newState, self._inputwords, self._outputword):
                print('Invalid assignment: ' + str(newState))
                return None
            return newState

    # Unused, add at a later date.
    def applyAction ( self, state, action ) :
        # Does nothing but copy the current state. This will be problem specific.
        # Apply the action to the current state to produce a new state
        # If you did not check for illegal states in getActions, then check for illegal states here
        # Can evaluate node based on path cost, heuristic function, or fitness function
        if not action :
            return []
        else :
            #the action we receive is a tuple, since our generator returns a tuple not a list.  Need to conver it.
            action = list(action)
            newState = deepcopy(state)
            newState.append(action)
            return newState

    #Unused, add at a later date.
    def evaluation(self, state):
        if not self.evalFn :
            return 0
        else :
            state.evaluate( state.evalFn )

    def isGoal ( self, state ):
        # Determine if current state is goal
        # Do we have a completely filled in state.
        print(state)
        if(len(state) != self.size):
            return False

        #Verify there are no duplicate decimal assignments(e.g. F=1, B=1)
        if (len(state.values()) != len(set(state.values()))):
            return False

        inputWordsAsStrings = []
        for word in self._inputwords:
            s = ''
            for char in word:
                if(char != None):
                    s += str(state[char])
            inputWordsAsStrings.append(s)

        outputWordAsString = ''
        for char in self._outputword:
            if (char != None):
                outputWordAsString += str(state[char])

        inputWordsAsNumbers = [int(num) for num in inputWordsAsStrings]
        outputWordAsNumber = int(outputWordAsString)

        if(sum(inputWordsAsNumbers) != outputWordAsNumber):
            return False

        return True


# Unused by Cryptarithmetic.  Possibly add at a later date.
class ProblemState(object):
    def __init__( self, state, size, value=0 ):
        self.state = state
        self.value = value
        self.size = size

    def evaluate( self, evalFn ):
        self.value = evalFn( self.state )

    def isGoal( self ) :
                # Some problems have rules that determine the goal state (e.g. Sudoku), while other problems
                # have a known goal state (e.g. Sliding Puzzle).
                # It might be appropriate to leave goal checking to this State class, or it might be better to
                # have it checked in the Problem State.
                return False

    def __str__( self ) :
                # Converts the state representation to a string (nice for printing)
                return str( self.state )
