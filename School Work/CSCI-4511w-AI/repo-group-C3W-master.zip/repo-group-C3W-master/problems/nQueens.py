# NQueens, the problem class
# 
# by Lee Williams, will4379

from node import Node
from copy import deepcopy
import random

class NQueens():
    # Implements the puzzle logic for an n-queens puzzle
    # it stores the state as a list of integers
    # and not yet positions Queens are represented by None

    def __init__(self, size):
        # Takes the parameter size, which is the n in n-Queens
        # and creates an initial state consisting of a n-element list
        # with each element set to none

        self.size = size
        self.initialState = [None] * size

    def getRandomAction(self, state):
        return random.choice(self.getActions(state))

    def getActions(self, state):
        # This function assumes that what is wanted is to put a number into the next slot
        # It does pruning by checking if applying a potential action would lead to a state
        # that has collisions, and, if not, adds it to the return list
        if not None in state:
            return []
        else:
            actions = []
            for action in range(self.size):
                if self.evaluation(self.applyAction(state,action)) == 0:
                        actions.append(action)
            return actions

    def applyAction(self,state,action):
        if not None in state:
            return state
        newstate = deepcopy(state)
        newstate[newstate.index(None)] = action
        return newstate

    def evaluation(self, state):
        # This function looks for the number of collisions, i.e. the number of times one queen could
        # capture another
        # since a number cannot be compared to None, if a none is encountered the 
        # function just returns the number of functions returned so far.
        # Implicit in this is the assumption that the list has the number values first, and the 
        # None elements last. 
        collisions = 0
        end = len(state)
        if None in state:
            end = state.index(None)
        for i in range(end - 1):
            for j in range(i+1, end):
                if j == None:
                    return collisions
                if state[i] == state[j]:
                    collisions += 1
                if state[j] == state[i] + (j-i):
                    collisions += 1
                if state[j] == state[i] - (j-i):
                    collisions += 1
        return collisions

    def isGoal(self, state):
        return not None in state and self.evaluation(state) == 0

    def print_state(self, state):
        print("")
        endline = "+"
        for i in range(len(state)):
            endline += "-+"

        print(endline)
        for i in range(len(state)):
            line = "|"
            for j in range(len(state)):
                if j == state[i]:
                    line += '*|'
                else:
                    line += ' |'
            print(line)
        print(endline)

