### Feedback for Project Part 2 : CSP ###

Run on November 28, 08:12:29 AM.

+ Fail: All required algos implemented.

+ Fail: Solve [['*', 6, [0, 0], [1, 0]], ['-', 1, [0, 1], [0, 2]], ['+', 7, [1, 1], [1, 2], [2, 2]], ['-', 1, [2, 0], [2, 1]]] (PuzzleType.kenken by ['comer028', 'will4379']) with AC3 (by ['comer028', 'will4379']). <solver>.solution does not exist

+ Fail: Solve [[3, [2, 0]], [1, [2, 1]], [1, [3, 3]], ['>', [1, 1], [1, 2]], ['>', [1, 2], [2, 2]]] (PuzzleType.futoshiki by ['comer028', 'will4379']) with AC3 (by ['comer028', 'will4379']). <solver>.solution does not exist

+ Fail: Solve [[[['+', '-'], 8], [['*', '/'], 2], [['*', '-'], 5]], [[['/', '-'], 3], [['+', '-'], 7], [['+', '+'], 16]]] (PuzzleType.crossmath by ['webe0491', 'wongx565']) with AC3 (by ['comer028', 'will4379']). Call solve() failed. 
ERROR: 'B1'

+ Fail: Solve [['*', 6, [0, 0], [1, 0]], ['-', 1, [0, 1], [0, 2]], ['+', 7, [1, 1], [1, 2], [2, 2]], ['-', 1, [2, 0], [2, 1]]] (PuzzleType.kenken by ['comer028', 'will4379']) with backtracking with mac (by ['webe0491', 'wongx565']). Call solve() failed. 
ERROR: name 'DEBUG' is not defined

+ Fail: Solve [[3, [2, 0]], [1, [2, 1]], [1, [3, 3]], ['>', [1, 1], [1, 2]], ['>', [1, 2], [2, 2]]] (PuzzleType.futoshiki by ['comer028', 'will4379']) with backtracking with mac (by ['webe0491', 'wongx565']). Call solve() failed. 
ERROR: name 'DEBUG' is not defined

+ Fail: Solve [[[['+', '-'], 8], [['*', '/'], 2], [['*', '-'], 5]], [[['/', '-'], 3], [['+', '-'], 7], [['+', '+'], 16]]] (PuzzleType.crossmath by ['webe0491', 'wongx565']) with backtracking with mac (by ['webe0491', 'wongx565']). Call solve() failed. 
ERROR: name 'DEBUG' is not defined

+ Fail: Solve [['*', 6, [0, 0], [1, 0]], ['-', 1, [0, 1], [0, 2]], ['+', 7, [1, 1], [1, 2], [2, 2]], ['-', 1, [2, 0], [2, 1]]] (PuzzleType.kenken by ['comer028', 'will4379']) with backtracking with forward checking (by ['webe0491', 'wongx565']). Call solve() failed. 
ERROR: name 'DEBUG' is not defined

+ Fail: Solve [[3, [2, 0]], [1, [2, 1]], [1, [3, 3]], ['>', [1, 1], [1, 2]], ['>', [1, 2], [2, 2]]] (PuzzleType.futoshiki by ['comer028', 'will4379']) with backtracking with forward checking (by ['webe0491', 'wongx565']). Call solve() failed. 
ERROR: name 'DEBUG' is not defined

+ Fail: Solve [[[['+', '-'], 8], [['*', '/'], 2], [['*', '-'], 5]], [[['/', '-'], 3], [['+', '-'], 7], [['+', '+'], 16]]] (PuzzleType.crossmath by ['webe0491', 'wongx565']) with backtracking with forward checking (by ['webe0491', 'wongx565']). Call solve() failed. 
ERROR: name 'DEBUG' is not defined

