import sys,os
sys.path.append('algorithms')
sys.path.append('problems')
sys.path.append( os.path.realpath('..') + '/class-repo/projectClasses' )

from algorithms.solverClass import Solver



# Nathan Comer SolverClass: #########################################################################
from MazePuzzle import MazePuzzle
from SlidingPuzzle import SlidingPuzzle
from Astar import AstarSearch
from SlidingPuzzle import SlidingState

class SolverAStar(Solver):
    def __init__(self, testCase, problem_type = 'sliding', size = 0):
        Solver.__init__(self, testCase)
        self.puzzle = testCase
        self.size = size
        self.solution = None
        self.userid = "comer028"
        self.problem_type = problem_type

    def solve(self):
        if self.problem_type == 'maze':
            search = AstarSearch(self.puzzle.puzzle, self.size)
            self.solution = search.Astar(self.puzzle)
        elif self.problem_type == 'sliding':
            search = AstarSearch(self.puzzle.state.state, self.size)
            self.solution = search.Astar(self.puzzle)
        return self.solution

        # print the solution in a user-friendly way
    def printSolution(self):
        if self.solution:
            print(self.solution)

#test = SolverAStar(MazePuzzle("maze10.txt", 10), 'maze', 10)
#test.solve()

#test = SolverAStar(MazePuzzle("maze40.txt", 40), 'maze', 40)
#test.solve()

#test = SolverAStar(SlidingPuzzle([[4, 1, 2], [7, 5, 3], [8, 0, 6]]), 'sliding')
#test.solve()

#test = SolverAStar(SlidingPuzzle([[0,5,1,4],[10,14,2,8],[13,7,3,12],[6,9,11,15]]), 'sliding')
#test.solve()

#test = SolverAStar(SlidingPuzzle([[5, 0, 8], [4, 7, 6], [2, 3, 1]]), 'sliding')
#test.solve()

###########################################################################################

###########################################################################################
# Lee Williams GA solving N Queens
from GA import *
from GATower import *
from nQueens import *

class SolveNQueens():
    def __init__(self, num_queens):
        self.solver = GAQueens(num_queens)
        self.solution = None
        self.userid = 'will4379'

    def solve():
        self.solution = solver.solve()
        return self.solution

    def printSolution(self):
        if self.solution:
            print(solver.problem_instance.print_state(self.solution))


class SolveGATower():
    def __init__(self, num_disks):
        self.solver = GATower(num_disks)
        self.solution = None
        self.userid = 'will4379'

    def solve(self):
        self.solution = self.solver.solve()
        return self.solution

    def printSolution(self):
        if self.solution:
            print(solver.problem_instance)

#### Benjamen Weber SolverClass ###########################################################
import Backtracking
import CrossMath
import tests.crossMathTests
from tests.createCrossMath import *

class SolverBacktracking(object):
    # The input parameters must be as is here
    def __init__(self, testCase, goal=None):
        self.testCase = testCase
        self.goal = testCase.solution
        self.solution = None
        self.userid = 'webe0491'  ### PUT THE PERSON WHO WROTE THE ALGORITHM HERE!!
        # This is a good place to create a problem instance.

    # return a solution in the specified format
    # An instance of a solver will be specific to the testCase, thus
    # the details of how to handle it will be hidden inside this method.
    def solve(self):
        problem = CrossMath.CrossMathProblem(self.testCase)
        self.solution = Backtracking.recursiveBacktrackDFS(problem)
        return self.solution

    # print the solution in a user-friendly way
    def printSolution(self):
        if self.solution:
            for row in self.solution:
                print(row)
        else:
            print('No solution for input problem.')


# if __name__ == '__main__':
#     puzzle = tests.crossMathTests.CrossMathPuzzle(
#         [[['+', '+'], 15], [['+', '*'], 24], [['+', '-'], 14]],
#         [[['+', '-'], 3], [['*', '-'], 12], [['/', '/'], 4]],
#         [[4, 3, 8], [5, 7, 2], [6, 9, 1]])
#     # solver = SolverBFS(puzzle)
#     solver = SolverBacktracking(puzzle)
#     solver.solve()
#     solver.printSolution()
#     print(solver.goal == solver.solution)
#
#     for i in range(15):
#         cmpuzz = createCrossMathPuzzle(9)
#         puzzle = tests.crossMathTests.CrossMathPuzzle(cmpuzz[0], cmpuzz[1], cmpuzz[2])
#         solver = SolverBacktracking(puzzle)
#         solver.solve()
#         print()
#         print(cmpuzz[0])
#         print(cmpuzz[1])
#         print(cmpuzz[2])
#         solver.printSolution()
#         if(solver.goal != solver.solution):
#             print("DIFFERING SOLUTIONS, MAKE SURE MINE IS VALID")
#     cmpuzz = createCrossMathPuzzle(4)
#     puzzle = tests.crossMathTests.CrossMathPuzzle(cmpuzz[0], cmpuzz[1], cmpuzz[2])
#     solver = SolverBacktracking(puzzle)
#     solver.solve()
#     print()
#     print(cmpuzz[0])
#     print(cmpuzz[1])
#     print(cmpuzz[2])
#     solver.printSolution()
#
#     # puzzle = Cryptarithmetic.CryptarithmeticPuzzle(
#     #     [[None, 'S','E','N','D'], [None, 'M','O','R','E']], ['M','O','N','E','Y'],[])
#     # solver = SolverBacktracking(puzzle)
#     # solver.solve()
#     # solver.printSolution()
#
#
#     # tc2 = Cryptarithmetic.CryptarithmeticPuzzle([['F','O','O'], ['B','A','R']], ['B','A','Z'],[])
#     # solver = SolverBacktracking(tc2)
#     # solver.solve()
#     # solver.printSolution()
#     # print(solver.solution == None)
#     #
#     #
#     # tc2 = Cryptarithmetic.CryptarithmeticPuzzle([['A'], ['B']], ['C'], [])
#     # solver = SolverBacktracking(tc2)
#     # solver.solve()
#     # solver.printSolution()
#     # pass
###########################################################################################
#####################################################
