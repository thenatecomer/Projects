// Nathan Comer
// Eric Bjorgan

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include <pthread.h>
#include <string.h>

char* SearchDir(const char *name, int level, char* file_name);

int main (int argc, char *argv[]){

  if (argc != 3){
    fprintf(stderr, "Incorrect Arguments!\n Usage:\n ./myfind <File Name> <Starting Directory> \n");
    return 0;
  }

  DIR *temp_dir;
  char file[256];
  strcpy(file, argv[1]);

  if(!(temp_dir = opendir(argv[2]))){
    printf("Invalid Directory\n");
    return 1;
  }
  printf("Searching for File: %s \n", file);
  char* directory = argv[2];
  printf("Starting Directory: %s \n", directory);

  // Initial call to recursive search function
  SearchDir(directory, 0, &file);
  return 0;
}

// Recursive function that searches through directories for a file named file_name
char* SearchDir(const char *name, int level, char* file_name)
{
    DIR *dir;
    struct dirent *entry;
    if (!(dir = opendir(name)))
        return "";
    if (!(entry = readdir(dir)))
        return "";
    do { // do-while: search through the specified directory

      struct stat path_stat;
      char current_file[1024];
      char path[1024];
      snprintf(current_file, sizeof(current_file)-1, "%s/%s", name, entry->d_name);
      stat(current_file, &path_stat);
      int len = snprintf(path, sizeof(path)-1, "%s/%s", name, entry->d_name);
      path[len] = 0;

        // If the current file is a directory recursively search through it
        if (S_ISDIR(path_stat.st_mode) && strcmp(entry->d_name, ".") != 0 && strcmp(entry->d_name, "..") != 0) {
            char* result = SearchDir(path, level + 1, file_name);
            if(strcmp(result,"") == 0){
              continue;
            }
            else{
              char* directory_name = entry->d_name;
              strcat(directory_name, result);
              return result;
            }
        }
        else if (strcmp(entry->d_name, file_name) == 0){
          fprintf(stderr, "File %s found!\n", entry->d_name);
          fprintf(stderr, "Path: %s \n", path);
          return entry->d_name;
        }
    } while (entry = readdir(dir));
    closedir(dir);

    // If this point is reached and level equals 0, all directories were searched and the file was not found
    if(level == 0)
      fprintf(stderr, "File name %s not found! \n", file_name);
    return "";
}
