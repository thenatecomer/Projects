// Nathan Comer
// Eric Bjorgan

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>

int main (int argc, char *argv[]){

      // Check whether the arguments are valid
      if (argc != 3 || strcmp(argv[1],"-l") != 0 ){
        fprintf(stderr, "Incorrect Arguments!\n Usage:\n ./myls <-l> <Directory> \n");
        return 0;
      }
      DIR *the_dir;
      struct dirent *the_file;
      struct stat the_stat;
      struct passwd *u_id;
      struct group *g_id;

      // Check whether the specified directory is valid
      if(!(the_dir = opendir(argv[2]))){
        printf("Invalid Directory\n");
        return 1;
      }
      char buf[512];
      printf("[Permissions]  [Blocks] [User]          [Group]         [Size] [Blocks] [File Name]     [Date Modified]\n");

      // Search through the specified directory
      while((the_file = readdir(the_dir)) != NULL){
        if(strcmp(the_file->d_name,".") != 0 && strcmp(the_file->d_name,"..") != 0){
          sprintf(buf, "%s/%s", argv[2], the_file->d_name);
          stat(buf, &the_stat);

          // Print permissions
          printf( (the_stat.st_mode & S_IRUSR) ? " r" : " -");
          printf( (the_stat.st_mode & S_IWUSR) ? "w" : "-");
          printf( (the_stat.st_mode & S_IXUSR) ? "x" : "-");
          printf( (the_stat.st_mode & S_IRGRP) ? "r" : "-");
          printf( (the_stat.st_mode & S_IWGRP) ? "w" : "-");
          printf( (the_stat.st_mode & S_IXGRP) ? "x" : "-");
          printf( (the_stat.st_mode & S_IROTH) ? "r" : "-");
          printf( (the_stat.st_mode & S_IWOTH) ? "w" : "-");
          printf( (the_stat.st_mode & S_IXOTH) ? "x" : "-");

          // Print hard links to the file
          printf(" \t%d   ", the_stat.st_nlink);

          // Print the user id as a string
          u_id = getpwuid(the_stat.st_uid);
          printf("\t%s ", u_id->pw_name);

          // Print the group id as a string
          g_id = getgrgid(the_stat.st_gid);
          printf("\t%s ", g_id->gr_name);

          // Print the file size
          printf("\t%zu ", the_stat.st_size);

          // Print the file Blocks
          printf("\t%d ", the_stat.st_blocks);

          // Print the file name
          printf("\t%s ", the_file->d_name);

          // Print the file modification date
          printf("\t\t%s ", ctime(&the_stat.st_mtime));

          printf("\n");
          }

      }
      closedir(the_dir);
}
