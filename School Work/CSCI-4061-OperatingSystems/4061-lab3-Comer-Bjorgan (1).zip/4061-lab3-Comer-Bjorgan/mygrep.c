// Nathan Comer
// Eric Bjorgan

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main (int argc, char *argv[]){

  // Check whether the arguments are valid
  if (argc != 3){
    fprintf(stderr, "Incorrect Arguments!\n Usage:\n ./mygrep <String> <File> \n");
    return 0;
  }

  FILE* file = fopen(argv[2], "r");
  if(file != NULL){
    char line[1024];

    // Line counter
    int line_number = 1;

    // Search through the lines
    while(fgets(line, sizeof(line), file)!=NULL){

      // If the string is found in this line of the file print out the line number then the line
      if(strstr(line, argv[1])!=NULL){
        fprintf(stderr, "%d %s \n", line_number, line);
      }
      line_number++;
    }
    fclose(file);
  }
  else{ // Inform the user that the specified file could not be opened
    fprintf(stderr, "Error loading file \n");
    return 1;
  }
  return 0;
}
