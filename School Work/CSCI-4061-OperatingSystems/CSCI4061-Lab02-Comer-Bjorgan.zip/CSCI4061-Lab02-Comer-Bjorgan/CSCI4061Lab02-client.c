﻿// CSCI4061 Lab2 by Nathan Comer and Eric Bjorgan

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
#include <ctype.h>
#include <fcntl.h>

#define SERVER 1L
typedef struct {
    long    msg_to;
    long    msg_fm;
    char    buffer[50];
} MESSAGE;

int msg_queue_id;
key_t key;
struct msqid_ds buf;
MESSAGE msg;
FILE *inFile;

int main(int argc, char** argv) {

    key = ftok(".", 'z');
    msg_queue_id = msgget(key, 0);

  while(1){
    fprintf(stderr, "Client: Input name to lookup:\n");

    char input[50];
    scanf("%s",&input);
	  long client_id = (long)getpid();
    int i = 0;
    for(; i < sizeof(input); i++){
       msg.buffer[i] = input[i];
    }
    msg.buffer[i+1] = '\0';

	  printf("Client: Message before sending: %s \n", msg.buffer);

	  msg.msg_to = SERVER;
	  msg.msg_fm = (long)getpid();
 	  fprintf(stderr, "Client: Sending to server\n");

    if(msgsnd(msg_queue_id, &msg, sizeof(msg.buffer), IPC_NOWAIT)==-1){
      perror("msgsnd");
      exit(-1);
    }

    fprintf(stderr,"Client: Message Sent\n");

    if(msgrcv(msg_queue_id, &msg, sizeof(msg), client_id, 0)<0){
      perror("msgrcv");
      exit(-1);
    }
    fprintf(stderr, "\nClient: Phone number received: %s\n", msg.buffer);

  }
  fprintf(stderr, "Client %ld exiting \n", (long)getpid());
  return (EXIT_SUCCESS);
}
