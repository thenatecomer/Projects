﻿// CSCI4061 Lab2 by Nathan Comer and Eric Bjorgan

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
#include <ctype.h>
#include <fcntl.h>
#include <semaphore.h>

#define SERVER 1L
typedef struct {
    long    msg_to;
    long    msg_fm;
    char    buffer[50];
} MESSAGE;

int msg_queue_id;
long client;
key_t key;
struct msqid_ds buf;
MESSAGE msg;
sem_t semaphore_flag;

/*declare struct type Record*/
struct Record
{
    char name[50];
    int id;
} rec;


/* Declare an array of Records */
struct Record record_array [10];


/* initialize all the records in the array with usable data*/
char* names[] = {"Alice", "Bob", "Charlie", "Dora", "Edward", "Frank", "Gertrude", "Holly", "Isabel", "Jack"};

char* numbers[] = {"123-4567", "234-5678", "345-6789", "456-7890", "567-8912", "678-8745", "890-4564", "137-5412", "546-8458", "587-2167"};


int FindNumber();
void UnlockSemaphore();
void RespondToClient();
void RequestAndLockSemaphore();
void MessageHandler();
void PrintStatus();

int main(int argc, char** argv) {

	sem_init(&semaphore_flag, 0, 1);
	pthread_t message_handler1_id; /* the thread identifier */
	pthread_attr_t attr_message_handler1; /* set of thread attributes */
	pthread_t message_handler2_id; /* the thread identifier */
	pthread_attr_t attr_message_handler2; /* set of thread attributes */
	pthread_t message_handler3_id; /* the thread identifier */
	pthread_attr_t attr_message_handler3; /* set of thread attributes */

	/* get the default attributes */
	pthread_attr_init(&attr_message_handler1);
	pthread_attr_init(&attr_message_handler2);
	pthread_attr_init(&attr_message_handler3);

	key = ftok(".", 'z');
    	if((msg_queue_id = msgget(key, IPC_CREAT | 0660))<0){
       		perror("Error Creating Message Queue\n");
       		exit(-1);
    	}

	/* create the threads */
	pthread_create(&message_handler1_id,&attr_message_handler1,MessageHandler,argv[1]);
	pthread_create(&message_handler2_id,&attr_message_handler2,MessageHandler,argv[1]);
	pthread_create(&message_handler3_id,&attr_message_handler3,MessageHandler,argv[1]);

	/* wait for the threads to exit */
	pthread_join(message_handler1_id,NULL);
	pthread_join(message_handler2_id,NULL);
	pthread_join(message_handler3_id,NULL);

	msgctl(msg_queue_id, IPC_RMID, (struct msqid_ds *) 0);
	fprintf(stderr, "Server: Exiting\n");
	return(EXIT_SUCCESS);
}

void MessageHandler(){

	  printf("\nServer: Thread initialized\n");
    printf("Server: Server ID: %ld\n", (long)getpid());
    printf("Server: Thread ID: %ld\n", (long)pthread_self());
    printf("Server: Message Queue ID: %d\n", msg_queue_id);

	while(1){

		RequestAndLockSemaphore();
    ReadFromQueue();
    UnlockSemaphore();
    PrintStatus();
		DoWork();
    RespondToClient();

	}
	perror("Server: Exiting thread\n");
}

void PrintStatus(){
  printf("\nServer: Message Received \n");
  printf("Server: Thread ID: %ld\n",(long)pthread_self());
  printf("Server: Received Message: %s \n", msg.buffer);
  printf("Server: Looking up phone number for %s \n", msg.buffer);
}

void RequestAndLockSemaphore(){
  sem_wait(&semaphore_flag);
}

void ReadFromQueue(){
  if(msgrcv(msg_queue_id, &msg, sizeof(msg.buffer), SERVER, 0)<0){
    perror("Server: msgrcv error\n");
  }
}

void UnlockSemaphore(){
  sem_post(&semaphore_flag);
}

void DoWork(){
  client = msg.msg_fm;
  if(FindNumber()){
    printf("Server: Phone number found: %s \n", msg.buffer);
  }else{
    printf("Server: No phone number found for %s \n", msg.buffer);
    strcpy(msg.buffer,"No phone number found");
  }
}

void RespondToClient(){
  msg.msg_fm = SERVER;
  msg.msg_to = client;
  printf("Server: Sending result to client\n");
  if(msgsnd(msg_queue_id, (struct MESSAGE*)&msg, sizeof(msg.buffer), 0)==-1){
      perror("Server: msgsnd failed \n ");
      exit(-1);
  }
}

/* function to find number using name */
int FindNumber(){
  for (int i = 0; i<10; i++){
   	if(!strcmp(msg.buffer, names[i])){
      int n;
			for(n = 0; n < sizeof(numbers[i]); n++){
				msg.buffer[n] = numbers[i][n];
			}
      msg.buffer[n] = '\0';
      return 1;
		}
  }
  return 0;
}
