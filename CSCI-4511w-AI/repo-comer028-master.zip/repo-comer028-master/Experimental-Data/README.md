Experimental Data for 4511w Final Experiment Report Submission
