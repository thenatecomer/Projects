These are the classes/files used to generate the problems/maps/puzzles used to collect data
