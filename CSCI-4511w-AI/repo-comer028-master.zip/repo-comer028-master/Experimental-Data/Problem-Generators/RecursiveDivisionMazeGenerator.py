import random
import math
import time
import time

# By Nathan Comer
# Division Maze Generator

class NC_MazeGenerator():
    def __init__(self, scale = 10, goal_depth = 0):
        random.seed()
        self.size = pow(2,scale)+1
        print("The size of this maze is: ", self.size)
        self.maze = []
        tw = []
        for i in range (0,self.size):
            tw.append("@")
        self.maze.append(tw)
        for y in range(1,self.size-1):
            row = ["@"]
            for x in range(1,self.size-1):
                row.append(".")
            row.append("@")
            self.maze.append(row)
        self.maze.append(tw)
        #value = [random.randint((self.size/pow(2,i)) - 4) for i in range(0,pow(2,self.size/2))]
        self.recur(1, self.size-2, 1, self.size-2, 0, 0, 0)


    # if rc_flag is 0 draw rows, if it is 1 draw cols
    def recur(self, col_s, col_e, row_s, row_e, rc_flag, depth, goal=0):
        #print("depth: ", depth, " Col Start: ", col_s, " Col End: ", col_e, " Row Start: ", row_s, " Row End: ", row_e)
        if goal != 0 and depth >= goal:
            return
        if (row_e-row_s) < 2 or (col_e-col_s) < 2:
            return
        if rc_flag == 0:
            value = random.randint(int(row_s+1),int(row_e-1))
            value = int(math.floor(value/2)*2)
            self.drawRow(value,col_s,col_e+1, depth)
            rc_flag = 1
            self.recur(col_s,col_e,row_s,value-1,rc_flag, depth+1, goal)
            self.recur(col_s,col_e,value+1,row_e,rc_flag,depth+1, goal)
        else:
            value = random.randint(int(col_s+1),int(col_e-1))
            value = int(math.floor(value/2)*2)
            self.drawCol(value,row_s,row_e+1, depth)
            rc_flag = 0
            self.recur(col_s,value-1,row_s,row_e,rc_flag,depth+1,goal)
            self.recur(value+1,col_e,row_s,row_e,rc_flag,depth+1,goal)


    def drawCol(self, col, start, stop, depth):
        for row in range(start,stop):
            self.maze[row][col] = '@'
        value = random.randint(start+1,stop-1)
        value = int(math.floor(value / 2) * 2 + 1)
        self.maze[value][col] = '.'

    def drawRow(self, row, start, stop, depth):
        for col in range(int(start), int(stop)):
            self.maze[row][col] = '@'
        value = random.randint(start+1,stop-1)
        value = int(math.floor(value / 2) * 2 + 1)
        self.maze[row][value] = '.'

    def convert(self):
        newmaze = []
        for row in self.maze:
            rows = ""
            for col in row:
                rows += str(col)
            newmaze.append([rows])
        self.maze = newmaze

    def printState(self):
        for row in self.maze:
            print(row[0])


maze = MazeGenerator(10)
maze.convert()
maze.printState()





