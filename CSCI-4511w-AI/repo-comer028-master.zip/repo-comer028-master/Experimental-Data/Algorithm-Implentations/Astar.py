from AIproblem import AIproblem
import queue

# By: Nathan Comer

class Node(object):

	nodeCount = 0

	def __init__( self, state, parent=None, action=None ) :
		self.state = state
		Node.nodeCount += 1
		if parent:
			self.depth = parent.depth + 1

	def expand( self, problem ) :
		return [ self.makeChild( problem, action) for action in problem.getActions( self.state ) ]

	def makeChild( self, problem, action ) :
		childState = problem.applyAction( self.state, action )
		return Node( childState )

	def getState( self ) :
		return self.state

class AstarSearch(AIproblem):

    def __init__(self, initialState, size, goal = None ):
        self.initialState = initialState
        self.size = size
        self.goal = goal
        self.nodes = 0
        self.analysisCounter = 0
        AIproblem.__init__(self, self.initialState, self.size)


    def Astar(self, problem):
        Node.nodeCount = 0
        node = Node(problem.newState(self.initialState, self.size))
        node.depth = 0

        frontier = queue.PriorityQueue()
        frontier.put(tuple([0, 0, node]))

        if problem.isGoal(node.getState()):
            print("The puzzle is already solved!")
            return [node.nodeCount ,node.getState().depth]

        already_visited = {}
        previous_state = {}
        previous_state[str(node.getState().ID)] = str([])
        already_visited[str(node.getState().ID)] = 0
        self.maxdepth = 0


        while not frontier.empty():
            curNode = frontier.get()[2]

            # Keep getting elements from the queue until you get a relatively optimal node
            while str(curNode.getState().ID) in already_visited and curNode.getState().value > already_visited[str(curNode.getState().ID)]:
                curNode = frontier.get()[2]

            self.analysisCounter += 1
            if self.analysisCounter%100000 == 0:
                print("")
                print("Progress Analysis: ")
                print("Current Node:")
                print("depth: ", curNode.depth)
                print("state: ", curNode.getState().state)
                print("value: ", curNode.getState().value)
                print("")

            if problem.isGoal(curNode.getState()):
                #print("Found the Goal!")
                #problem.printState(curNode.getState())
                return [curNode.nodeCount ,curNode.getState().depth]

            for child in curNode.expand(problem):
                new_cost = child.getState().value
                if str(child.getState().ID) not in already_visited or new_cost < already_visited[str(child.getState().ID)]:
                    already_visited[str(child.getState().ID)] = new_cost
                    child.depth = curNode.depth + 1
                    self.nodes += 1
                    frontier.put(tuple([child.getState().value, self.nodes, child]))
                    previous_state[str(child.getState().ID)] = str(curNode.getState().ID)

        print("The puzzle you entered is not solvable")
        return curNode.getState().endBehavior()