# a self=created version of AC3
# This version implements neighbors by variable, not by constraints
# when a variable or arc is pulled of the stack
# the constraint dictionary has a list of lambdas that is iterated over
#

from copy import deepcopy
from collections import deque

class AC3:
    def __init__(self, neighbors, domains, constraints, size, debug = False):
        # the AC3 solver takes as a parameter a puzzle class that provides the following members:
	#	self.neighbors, a dictionary where:
	#		the keys are variables
	#		the values are lists of neighbors of each variable
        #	self.domain, a dictionary where:
        #               the keys are the variables
        #               the values are domain of the variables
        # 	self.constraints , a dictionary of constraints where,
	#		where the key is a single varible
	#		and the value is a pair of (variables, constraint function)
        #
        self.neighbors = neighbors
        self.domain = domains
        self.constraints = constraints
        self.solved = False
        self.queue = deque()
        self.DEBUG = debug
        self.size = size

    def solve(self):
        self.processQueue()
        self.success = self.isSolved()
        if self.success:
            return self.returnResult()
        else:
            return []

    def processQueue(self):
        for var in list(self.neighbors.keys()):
                self.queue.append(var)

        while len(self.queue) > 0 :
            item = self.queue.popleft()
            if self.revise(item):
                if len(self.domain[item]) >0:
                    self.enqueueNeighbors(item)
                else:
                    print('No Solution Found')
                    break

    def isSolved(self):
        success = True
        for var in list(self.neighbors.keys()):
            if len(self.domain[var]) > 1:
                success = False
                break
        return success

    def returnResult(self):
        result = []
        keys = list(self.domain.keys())
        keys.sort()
        l = []
        for k in keys:
            l.append(self.domain[k][0])
            if len(l) == self.size:
                result.append(deepcopy(l))
                l = []
        return result

    def revise(self, item):
        # revise takes as a parameter a variable
        # it traverses over every constraint for the 'item'
        # if it can eliminate an entry from the domain of item
        # it does so, and sets revised to True
        # at the end it returns the flag revised

        revised = False
        if self.DEBUG:
            print("revising ", item)
            self.printConstraints(item)
            self.printDomain(item)

        failures = set() # a set for entries in the domain that don't fly
        for constraint in self.constraints[item]:
            # each constraint is a tuple of <variablelist, constraint_function, lambda_text>
            varlist = constraint[0]
            constraint_func = constraint[1]
            if self.DEBUG:
                lambda_text = constraint[2]

            for x in self.domain[item]:
                #print('testing on domain item ', x)
                x_works = False
                if len(varlist) == 1:
                    if constraint_func([x]):
                        x_works = True
                else:
                    for p in self.domainPermutations(varlist):
                        #print('\tvarlist -> ', varlist)
                        #print('Calling constraint on list ', [x]+p)
                        if constraint_func([x]+p):
                            x_works = True

                if not x_works:
                    failures.add(x)

        if len(failures) > 0:
            revised = True
            for flop in failures:
                self.domain[item].remove(flop)
                # print("removing ", flop, "from ", item)

        return revised

    def domainPermutations(self, varlist):
        # This method recieves a constraint i.e. a <varlist, constraint_function> fair
        # and returns a nested list containing all the domains of the variables in the list
        # not including the domain of the first variable in the variable list
        #print("Varlist is: ", varlist)
        if len(varlist) <= 1:
            return []
        newlist = []
        for var in varlist:
            if var != varlist[0]:
                newlist.append(self.domain[var])
        return permute(newlist)

    def enqueueNeighbors(self, item):
        for var in self.neighbors[item]:
            self.queue.append(var)
        if self.DEBUG:
            print("\t Queue now contains ", self.queue)

    def printDomain(self, item = None):
        if item == None:
            keys = list(self.domain.keys())
            keys.sort()
            for item in keys:
                print("Domain of ", item, " is ", self.domain[item])
        else:
            print("Domain of ", item, " is ", self.domain[item])

    def printConstraints(self, item= None):
        if item == None:
            keys = self.domain.keys()
            keys.sort()
            for item in keys:
                print("Constraints of ", item, " is ", self.domain[item])
                for constraint in self.constraints[item]:
                    print("\t", constraint[2])
        else:
            print("\tConstraints on ",item, " are:")
            for constraint in self.constraints[item]:
                print("\t", constraint[2])

def permute(a):
    if len(a) == 0:
        return []
    elif len(a) == 1:
        l = []
        for i in a[0]:
            l.append([i])
        return l
    else:
        l = []
        for i in a[0]:
            for j in permute(a[1:]):
                l.append([i] + j)
        return l


