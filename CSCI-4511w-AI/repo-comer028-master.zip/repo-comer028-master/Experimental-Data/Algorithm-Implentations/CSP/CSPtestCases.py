import enum
class PuzzleType( enum.Enum ):
  kenken = 1; futoshiki = 2; crypt = 3; crossmath = 4
  other = 5

class InputPuzzleClass :
  def __init__ ( self, size, puzzle, pType, solution=None ) :
    self.size = size
    self.pType = pType
    self.puzzle = puzzle
    self.solution = solution

  # return (domain, constraints)
  # domain is a dictionary of k-v pairs, with the key corresponding to a variable, and the value being a list of values
  # domain { var : [values], var2 : [values2], ...}
  # constraints is a dicationary, with k-v pairs where the key is a variable or tuple of variables, and the value is a constraint
  #     the constraint is a lambda function which can be applied to the key variable(s)
  # constraints { var : c1, (var,var2,...) : c2, ...}

# If your algorithm cannot solve the puzzle (which is likely if
# AC3 is used exclusively), return [] or None.
# HOWEVER, please provide a means for us to print the current
# state of the domains of all variables.

## KenKen
# If you implemented your puzzle with labels like "A1" for your boxes,
# try this ...
# cd = { 0:'A', 1:'B' ... }
# for xy in coordinates:
#    varName = '{0}{1}'.format(cd[xy[0]],xy[1]+1)
k1 = InputPuzzleClass(
  [3,3],
  [['*',6,[0,0],[1,0]],
   ['-',1,[0,1],[0,2]],
   ['+',7,[1,1],[1,2],[2,2]],
   ['-',1,[2,0],[2,1]]],
  PuzzleType.kenken,
  [[3,1,2],[2,3,1],[1,2,3]]
 )

k2 = InputPuzzleClass(
  [3,3],
  [['-', 2, [0,0],[0,1]],
   ['abs',2,[0,2]],
   ['/',2,[1,0],[2,0]],
   ['/',3,[1,1],[1,2]],
   ['-',1,[2,1],[2,2]]
   ],
  PuzzleType.kenken,
  [[3,1,2], [2,3,1], [1,2,3]] )

k3 = InputPuzzleClass(
  [4,4],
  [['*',16,[0,0],[0,1],[1,1]],
   ['+',7,[0,2],[0,3],[1,2]],
   ['abs',4,[1,3]],
   ['-',2,[1,0],[2,0]],
   ['*',12,[2,1],[3,0],[3,1]],
   ['/',2,[3,2],[3,3]],
   ['/',2,[2,2],[2,3]]
   ],
  PuzzleType.kenken,
  [[2,4,1,3],
   [1,2,3,4],
   [3,1,4,2],
   [4,3,2,1]] )

kenkens = [ k1, k2, k3 ]

## Futoshiki
f1 = InputPuzzleClass(
  [4,4],
  [[3,[2,0]],
   [1,[2,1]],
   [1,[3,3]],
   ['>',[1,1],[1,2]],
   ['>',[1,2],[2,2]]
   ],
  PuzzleType.futoshiki,
  [[4,2,1,3],
   [1,4,3,2],
   [3,1,2,4],
   [2,3,4,1]] )

f2 = InputPuzzleClass(
  [5,5],
  [[ 2, [0,3]],
   ['>',[0,0],[0,1]],
   ['<',[1,2],[1,3]],
   ['>',[1,4],[0,4]],
   ['<',[2,2],[3,2]],
   ['>',[4,1],[4,2]],
   ['>',[4,2],[3,2]],
   ['<',[4,2],[4,3]]],
  PuzzleType.futoshiki,
  [[4,3,5,2,1],
   [2,1,4,5,3],
   [5,2,1,3,4],
   [3,4,2,1,5],
   [1,5,3,4,2]] )

futos = [ f1, f2 ]

## Cross Math
c1 = InputPuzzleClass(
  [3,3],
  [
    [[['+', '-' ], 8 ],
     [['*', '/' ], 2 ],
     [['*', '-' ], 5 ]],
    [[['/','-' ], 3 ],
     [['+','-' ], 7 ],
     [['+','+' ], 16 ]]
    ],
  PuzzleType.crossmath,
  [[ 5, 6, 3],
   [ 1, 8, 4],
   [ 2, 7, 9]] )

c2 = InputPuzzleClass(
  [4,4],
  [
    [[['*', '*', '*'], 22880],
     [['+', '*', '-'], 22],
     [['+', '-', '-'], -19],
     [['*', '+', '+'], 37] ] ,
    [[['*', '+', '*'], 69],
     [['+', '*', '+'], 186],
     [['*', '*', '-'], 688],
     [['*', '*', '-'], 1553]]
    ],
  PuzzleType.crossmath,
  [[11, 16, 10, 13],
   [2, 4, 5, 8],
   [1, 9, 14, 15],
   [3, 6, 12, 7]] )

xmaths = [ c1, c2 ]

## Cryptarithmetic

p1 = InputPuzzleClass(
  None,
  [ '+', ['send','more'], 'money' ],
  PuzzleType.crypt,
  { 'o':0, 'm':1, 'y':2, 'e':5, 'n':6, 'd':8, 'r':8, 's':9 }
  )

p2 = InputPuzzleClass(
  None,
  [ '+', [ 'two', 'two'], 'four' ],
  PuzzleType.crypt,
  { 't':2, 'w':3, 'o':4, 'f':0, 'u':6, 'r':8 }
  )

p3 = InputPuzzleClass(
  None,
  [ '+', ['cp','is','fun'], 'true' ],
  PuzzleType.crypt,
  { 'c':2, 'p':3, 'i':7, 's':4, 'f':9, 'u':6, 'n':8, 't':1, 'r':0, 'e':5 }
  )

# This last one might is complicated and will not be required.
p4 = InputPuzzleClass(
  None,
  [ '*', ['abc','de'], [ 'fec' , 'dec', 'hgbc' ]],
  PuzzleType.crypt,
  { 'a':1, 'b':2, 'c':5, 'd':3, 'e':7, 'f':8, 'g':6, 'h':4 }
  )

crypts = [ p1, p2, p3, p4 ]

