Files used to collect preliminary CSP data
