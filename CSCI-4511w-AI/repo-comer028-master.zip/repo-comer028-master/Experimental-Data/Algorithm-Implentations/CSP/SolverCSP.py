import sys, os
sys.path.append('CSP')

#sys.path.append(os.path.realpath('..') + '/class-repo/projectClasses')

from CSPclasses import PuzzleType
from CSPclasses import AlgoType
from CSPclasses import AlgoImplementation
from CSPclasses import PuzzleImplementation
from CSPclasses import InputPuzzleClass
from Futoshiki import Futoshiki
import CSPclasses
from AC3 import AC3
from GridPuzzleBaseClass import GridPuzzleBaseClass
import CSPtestCases
import time

# _______________________________________________________________________
# PROVIDE the following for Puzzle and Algorithm Implementation:
#         THE INFORMATION BELOW REGARDING AUTHORSHIP AND IMPLEMENTATION STATUS IS REQUIRED
#         Your team can collectively create implementation classes here or in separate files
#         Make sure that paths are set properly.
# _______________________________________________________________________

### PUZZLES
##       -- If anyone completed an extra puzzle, create an instance and set algo.bonus = True


# >>>>>>> APPEND TO THIS LIST with puzzle implementation instances
puzzlesImplemented = []

ken = CSPclasses.PuzzleImplementation(CSPclasses.PuzzleType.kenken)
ken.authors = "Nathan Comer, Lee Williams"
ken.status = CSPclasses.StatusType.Complete
ken.comments = ''
puzzlesImplemented.append(ken)

futo = CSPclasses.PuzzleImplementation(CSPclasses.PuzzleType.futoshiki)
ken.authors = "Nathan Comer, Lee Williams"
ken.status = CSPclasses.StatusType.Complete
ken.comments = 'BONUS Implementation: Implemented by Nathan Comer and Lee Williams as our bonus implementation '
puzzlesImplemented.append(futo)

crypt = CSPclasses.PuzzleImplementation(CSPclasses.PuzzleType.crypt)
crypt.authors = None
crypt.bonus = True
crypt.status = CSPclasses.StatusType.NotSelected
crypt.comments = 'Cryptarithmetic can decipher 2 words of any length with ops + and -.'
puzzlesImplemented.append(crypt)

xmath = CSPclasses.PuzzleImplementation(CSPclasses.PuzzleType.crossmath)
xmath.authors = ['webe0491', ] #todo noah add urself
xmath.status = CSPclasses.StatusType.Incomplete
xmath.comments = 'Hard coded for 2,3,4,5 size xmath puzzles'
puzzlesImplemented.append( xmath)

#### ALGORITHMS
##        -- AC3 and Backtracking are required parts of this assignment
##        -- Please create a class instance for each type of backtracking (with mac and forward-checking)
##        -- Create an additional class for any variable or value ordering implentation
##
##  IF your team produced multiple versions, please create a separate instance for each implementation


# >>>>>>> APPEND TO THIS LIST with algorithm implementation instances
algosImplemented = []

ac3imp = CSPclasses.AlgoImplementation(CSPclasses.AlgoType.AC3)
ac3imp.authors = ['comer028', 'will4379']
ac3imp.status = CSPclasses.StatusType.Complete
ac3imp.comments = 'Implemented by Nathan Comer and Lee Williams, domain stored in variable called domain which can be accessed after solving'
algosImplemented.append(ac3imp)

backMac = CSPclasses.AlgoImplementation(CSPclasses.AlgoType.backtrackMAC)
backMac.authors = ['webe0491', 'lars1050']
backMac.status = CSPclasses.StatusType.NotSelected
#algosImplemented.append(backMac)

backFC = CSPclasses.AlgoImplementation(CSPclasses.AlgoType.backtrackFC)
backFC.authors = ['webe0491', 'lars1050']
backFC.status = CSPclasses.StatusType.Buggy
#algosImplemented.append(backFC)

# Here is how you would test 2 different implementations of the same algorithm
back2 = CSPclasses.AlgoImplementation(CSPclasses.AlgoType.backtrackMAC)
# ...

deg = CSPclasses.AlgoImplementation(CSPclasses.AlgoType.degreeHeuristic)
deg.authors = None
deg.status = CSPclasses.StatusType.NotSelected
deg.bonus = False
#algosImplemented.append(deg)

def generateConstraintsandDomain(puzzle, problemSetup):
    if puzzle.pType == PuzzleType.kenken:
        return problemSetup.kenkenSetup(puzzle.size[0], puzzle.puzzle, puzzle.solution)
    elif puzzle.pType == PuzzleType.futoshiki:
        f = Futoshiki(puzzle)
        return [f.neighbors, f.domains, f.constraints]

    elif puzzle.pType == PuzzleType.crypt:
        return problemSetup.cryptSetup(puzzle.size, puzzle.puzzle, puzzle.solution)
    elif puzzle.pType == PuzzleType.crossmath:
        return problemSetup.crossmathSetup(puzzle.size, puzzle.puzzle, puzzle.solution)
    elif puzzle.pType == PuzzleType.other:
        raise RuntimeError('PuzzleType other unimplemented')
    else:
        raise RuntimeError('PuzzleType' + str(puzzle.pType) + 'is not a valid PuzzleType')


def SolverCSP(puzzle, algorithm):
    problemSetup = GridPuzzleBaseClass()

    # generateConstraintsandDomain must return a list: (neighbors, domains, constraints)
    arguments = generateConstraintsandDomain(puzzle, problemSetup)

    # Constraints format: dictionary where keys are a single variable and values are a list: ([all variables],[constraint])
        # Example: x + y + z = 5: {x: ((x,y,z),lambda), y: ((y,x,z),lambda), z: ((z,x,y),lambda)}
    # Neighbors format: Format generated from the createTableNeighbors function within gridPuzzleBaseClass
    # Domains format: dictionary where keys are variables (A0, A1, B1, etc.) and values are the remaining values in the variables domain

    print("Stage 1 Success, generated constraints and domain")
    if algorithm.impType == AlgoType.AC3:

        problem = AC3(arguments[0], arguments[1], arguments[2], puzzle.size[0])

    # Add an elif here for each algorithm you implement
    # Every aglorithm or problem you add must work with all existing algorithms and problems!

    print("Stage 2 Success, passed arguments to algorithm")

    # this method must return an instance with methods .solve() and .printSolution()
    return problem

start_time = (time.time())
print("Futoshiki")
algo2 = AlgoImplementation(AlgoType.AC3)
puzzle = SolverCSP(InputPuzzleClass(
  [4,4],
  [[3,[2,0]],
   [1,[2,1]],
   [1,[3,3]],
   ['>',[1,1],[1,2]],
   ['>',[1,2],[2,2]]
   ],
  PuzzleType.futoshiki,
  [[4,2,1,3],
   [1,4,3,2],
   [3,1,2,4],
   [2,3,4,1]] ),algo2)
print("Solution Found:")
print(puzzle.solve())
end_time = (time.time())
time_elasped = end_time - start_time





start_time = (time.time())
print("Problem Type: KenKen")
print("Puzzle:")
algo = AlgoImplementation(AlgoType.AC3)
puzzle = SolverCSP(InputPuzzleClass(
  [3,3],
  [['*',6,[0,0],[1,0]],
   ['-',1,[0,1],[0,2]],
   ['+',7,[1,1],[1,2],[2,2]],
   ['-',1,[2,0],[2,1]],
   ['+',9,[0,0],[1,1],[2,2]],
   ['abs',3,[2,2]]],
  PuzzleType.kenken,
  [[3,1,2],[2,3,1],[1,2,3]]
 ),algo)
print("Solution found; ")
print(puzzle.solve())
end_time = (time.time())
time_elasped = end_time - start_time
print("Statistics:")
print("Run Time: ", time_elasped)
print("Memory usage: ", )
print(puzzle.printDomain())



    # puzzle is of type CSPclasses.InputPuzzleClass
    # algorithm is of type CSPclasses.AlgoImplementation
    #
    # RETURN a class instance that has methods solve() and printSolution() with member solution

    # FILL THIS IN such that a grading script can be called that will ...



#puzzles = CSPclasses.puzzlesImplemented
#algos = CSPclasses.algosImplemented
#for a in algos :
#     for p in puzzles :
#          testPuzzles = setUpPuzzles( p )
#          for t in testPuzzles :
#              print( 'Testing puzzle {0} of type {1} using algorithm {2}'.format(t, puzzleNames[t.puzzleType], a ))
#              test = SolverCSP( InputPuzzleClass( t.size, t.puzzleType, t ), a )
#              test.solve()
#              test.printSolution()
#              if t.solution == testCase.solution :
#                  print("SUCCESS")
#              else :
#                  print("FAILURE")
