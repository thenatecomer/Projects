Algorithm implementations and problem classes!
