
import node
from AIproblem import AIproblem
import math
from copy import deepcopy


class BdSlidingPuzzle(AIproblem):
    def __init__(self, initialState, goal = 0):
        initialState = SlidingState(initialState)
        #print("Sliding puzzle init")
        #print(initialState)

        self.size = len(initialState.state)
        self.goal = self.generateGoalState(self.size)
        self.state = initialState
        self.solutionMoves = []

        AIproblem.__init__(self, self.state, self.size, self.evalFunction, self.goal)

    # See which value moved into the space that was previously zero and only recalculate it!!!!
    def evalFunction(self, state, opposite_coordinates):
        stateList = state
        value = 0
        indexX = 0
        indexY = 0
        for i in range(1, self.size * self.size):
            for n in range(0, self.size):
                c1 = stateList[n].count(i)
                if c1 > 0:
                    for m in range(0, len(opposite_coordinates)):
                        c2 = opposite_coordinates[m].count(i)
                        if c2 > 0:
                            index = stateList[n].index(i)
                            index2 = opposite_coordinates[m].index(i)
                            value += self.manhattenDistance(n, index, m, index2)
        return value

    def getGoal(self):
        return self.goal

    # generates the goal state for the given size.
    def generateGoalState(self,size):
        count = 1
        state = []
        for n in range(0,size):
            state.append([count])
            count += 1
            for m in range(1,size):
                state[n].append(count)
                count +=1

        state[size-1][size-1] = 0    # in the goal state the lower right position will be empty

        return state


    def manhattenDistance(self, x1, y1, x2, y2):
        return math.sqrt((abs(x1-x2)**2) + (abs(y1-y2)**2))

    def getActions(self, passedstate):
        state = passedstate.state
        actions = []
        Rindex = 0
        Cindex = 0
        zero = 0

        rowCount = 0

        for row in state:
            if zero in row:
                Rindex = state.index(row)
                Cindex = state[Rindex].index(zero)

        if Rindex > 0:
            actions.append([Rindex - 1, Cindex])
        if Cindex > 0:
            actions.append([Rindex, Cindex - 1])
        if Rindex < self.size - 1:
            actions.append([Rindex + 1,Cindex])
        if Cindex < self.size - 1:
            actions.append([Rindex, Cindex + 1])

        return actions

    def applyAction(self, passedstate, action, opposite_coordiantes = None):
        state = passedstate.state

        if not action:
            return []
        else:
            new_state = deepcopy(state)
            Rindex = 0
            Cindex = 0
            for row in state:
                if 0 in row:
                    Rindex = state.index(row)
                    Cindex = state[Rindex].index(0)

            new_state[Rindex][Cindex] = new_state[action[0]][action[1]]
            new_state[action[0]][action[1]] = 0

            newState = SlidingState(new_state,self.size, passedstate.depth + 1)

            newState.evaluate(self.evalFunction, opposite_coordiantes)
            newState.storeMove(passedstate.solutionOrder, [action[0],action[1]])
        return newState

    def evaluation(self, passedstate):
        if not self.evalFn:
            return 0
        else:
            passedstate.evaluate(self.evalFunction)

    def isGoal(self, passedstate):
        state = passedstate.state
        for Xindex in range(0,passedstate.size):
            for Yindex in range (0,self.size):
                if state[Xindex][Yindex] != self.goal[Xindex][Yindex]:
                    return False
        return True

    def newState(self, state, size, height = None, goal = None):
        return SlidingState(state,size)

class SlidingState(object):
    def __init__(self, state, size = 0,  depth = 0, value = 0):
        self.state = state
        self.value = value
        self.depth = depth
        self.size = len(self.state)
        self.solutionOrder = []
        self.ID = ""
        for row in state:
            for col in row:
                self.ID += str(col)

    def storeMove(self, ordering, x):
        self.solutionOrder = ordering + [x]

    def endBehavior(self):
        return self.depth

    def evaluate( self, evalFn, opposite_coordinates):
        self.value = self.depth + evalFn( self.state, opposite_coordinates)

    def isGoal( self ) :
        state = self.state
        for Xindex in range(0, self.size):
            for Yindex in range(0, self.size):
                if state[Xindex][Yindex] != self.goal[Xindex][Yindex]:
                    return False
        return True

    def __str__( self ) :
                # Converts the state representation to a string (nice for printing)
                return str( self.state )



