
import node
from AIproblem import AIproblem
import math
from copy import deepcopy


# Nathan Comer
# comer028
# Striving for an A work

# evalweight1 = weighted towards goal
# evalweight2 = weighted towards other directions search

# Differences between this class and original MazePuzzle:
# -uses multiple weighted evaluation functions instead of an unweighted function
# -changes applyAction because the evalFn must know the current coordinates of the opposite state
class BdMazePuzzle(AIproblem):
    def __init__(self, initialState, width, height, evalWeight1 = .5, evalWeight2 = .5):
        if evalWeight1+evalWeight2 != 1.0:
            raise ValueError("The two weights for your evaluation functions must add to 1.0")
        self.puzzle = initialState # changed
        self.width = width
        self.height = height
        self.evalWeight1 = evalWeight1
        self.evalWeight2 = evalWeight2
        self.distance = width + height - 4

        AIproblem.__init__(self, self.width, width*height, self.evalFunction1)

    def loadMaze(self, file, size):
        maze = []
        with open(file) as f:
            for r in f.readlines():
                maze.append(r)
        return maze

    # Put your two evaluation function here:
    def evalFunction1(self, state, width, height, coordinate, opposite_coordinate):
        # opposite_coordinate[0] is a list containing the coordinates of the search from the other direction
        # opposite_coordinate[1] is a list containing the coordinates: -of the end if this is the search that started at the beginning
        #                                                              -of the beginning if this is the search that started at the end
        goal = opposite_coordinate[1]
        other_direction = opposite_coordinate[0]
        value = self.evalWeight1*(self.manhattenDistance(coordinate[0], coordinate[1], goal[0], goal[1])) + \
                self.evalWeight2*(self.manhattenDistance(coordinate[0],coordinate[1],other_direction[0],other_direction[1]))
        return value

    def evalFunction2(self, state, size, coordinate, start): # This evalfunction is not used
        value = abs(coordinate[0]- size - 1) + abs(coordinate[1] - size - 1)
        return value

    def manhattenDistance(self, x1, y1, x2, y2):
        return math.sqrt((abs(x1-x2)**2) + (abs(y1-y2)**2))

    def getGoal(self):
        return [self.width-2, self.height-2]

    def getActions(self, passedstate):
        state = passedstate.state
        actions = []
        coordinate = passedstate.coordinate

        if state[coordinate[0]-1][coordinate[1]] == ".":
            actions.append([coordinate[0] - 1, coordinate[1]])
        if state[coordinate[0]][coordinate[1]-1] == ".":
            actions.append([coordinate[0], coordinate[1]-1])
        if state[coordinate[0]+1][coordinate[1]] == ".":
            actions.append([coordinate[0]+1, coordinate[1]])
        if state[coordinate[0]][coordinate[1]+1] == ".":
            actions.append([coordinate[0], coordinate[1]+1])
        return actions

    def newState(self, state, width, height, coordinate = [1,1]):
        return MazeState(state, width, height, coordinate)

    def applyAction(self, passedstate, action, opposite_coordinate): # Updated this for bidirectional

        state = passedstate.state
        if not action:
            return []
        else:
            newState = MazeState(deepcopy(state),self.width, self.height, action, passedstate.depth + 1) # Updated this for bidirectional
            newState.state[passedstate.coordinate[0]] = state[passedstate.coordinate[0]][0:(passedstate.coordinate[1])] + str(passedstate.depth%10) + state[passedstate.coordinate[0]][(passedstate.coordinate[1])+1:]
            newState.state[action[0]] = newState.state[action[0]][0:action[1]] + "X" + newState.state[action[0]][action[1]+1:]
            newState.evaluate(self.evalFunction1, opposite_coordinate, self.evalWeight1, self.evalWeight2) # Updated this for bidirectional
        return newState

    def evaluation(self, passedstate):
        if not self.evalFn:
            return 0
        else:
            passedstate.evaluate(self.evalFunction1)

    def isGoal(self, passedstate):
        if passedstate.coordinate[0] == (passedstate.width - 2) and passedstate.coordinate[1] == (passedstate.height - 2):
            return True
        return False

    def printState(self, passedstate):
        state = passedstate.state
        for row in state:
            printrow = ""
            for x in row:
                if x == '.' or x == '@' or (x <= '9' and x >= '0') or x == 'X':
                    printrow+=str(x)
            #print(printrow)

class MazeState(object):
    def __init__(self, state, width, height, coordinate = [1,1], depth = 0, value = 0):
        self.state = state
        self.coordinate = coordinate
        self.value = value
        self.depth = depth
        self.width = width
        self.height = height
        self.ID = coordinate

    def endBehavior(self):
        return self.depth

    def storeCoordinate(self, x):
        self.coordinate = x

    def evaluate( self, evalFn, opposite_coordinate, w1, w2): # Updated this for bidirectional
        self.value = self.depth + evalFn( self.state, self.width, self.height, self.coordinate, opposite_coordinate )

    def isGoal( self ) :
        if self.coordinate[0] == (self.width - 2) and self.coordinate[1] == (self.height - 2):
            return True
        return False

    def printState(self, passedstate):
        state = passedstate.state
        for row in state:
            printrow = ""
            for x in row:
                if x == '.' or x == '@' or (x <= '9' and x >= '0') or x == 'X':
                    printrow+=str(x)
            print(printrow)

    def __str__( self ) :
                # Converts the state representation to a string (nice for printing)
                return str( self.state )
