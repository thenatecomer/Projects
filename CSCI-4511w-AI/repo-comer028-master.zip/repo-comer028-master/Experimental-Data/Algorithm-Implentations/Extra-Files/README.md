These files are needed to correctly run the algorithms and problem generators, but are not the algorithms themselves.
