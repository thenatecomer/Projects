import os
import random

class Maze:
    def __init__(self,row,col):
        self.rows, self.cols = [row,col]
        self.rows = int(self.rows)
        if (self.rows % 2) == 0:
            self.rows -= 1
        self.cols = int(self.cols)
        if self.cols % 2 == 0:
            self.cols -= 1
        self.rows -= 6
        self.cols -= 6

        self.maze = []
        self.wall_character = '@'
        self.passage_character = '.'


    def __str__(self):
        s = ""
        for row in self.maze:
            for col in row:
#               s+= self.maze[row][col]
                s+= col
            s+="\n"
        return s

    def binaryMaze(self):
        for i in range(self.rows):
            newrow = []
            for j in range(self.cols):
                if i % 2 ==0 or j % 2 == 0:
                    newrow.append(self.wall_character)
                else:
                    newrow.append(self.passage_character)

            self.maze.append(newrow)

        for i in range(1,self.rows -1, 2):
            for j in range(1,self.cols -2, 2):
                val = random.randint(0,1)
                if i == self.rows - 2 and val == 0:
                    self.maze[i][j+1] = self.passage_character
                elif i == self.rows  - 2 and val == 1:
                    self.maze[i][j+1] = self.passage_character
                    self.maze[i-1][j] = self.passage_character
                elif val == 1 or i == 1:
                    self.maze[i][j+1] = self.passage_character
                else:
                    self.maze[i-1][j] = self.passage_character
        newMaze = []
        for row in self.maze:
            s = ''
            for c in row:
                s += c
            newMaze.append(s)

        self.maze = newMaze
        return self.maze

