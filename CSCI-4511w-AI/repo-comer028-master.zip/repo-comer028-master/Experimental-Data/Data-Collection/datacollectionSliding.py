from thincorridors import *
import time
from BidirectionalMazePuzzle import BdMazePuzzle
from BidirectionalAstarSolver import SolverBdAStar
from generateSlidingPuzzle import generateSliding
from SlidingPuzzle import SlidingPuzzle
from Astar import AstarSearch
from solverClass import SolverAStar
from BidirectionSlidingPuzzle import BdSlidingPuzzle

class Datacollection(object):
    def __init__ (self, Maze_width,Maze_height,weight_forward, weight_backward ):
        self.width = Maze_width
        self.height = Maze_height
        self.W1 = weight_forward
        self.W2 = weight_backward
        self.Results = []


    def A_search(self,iterations ):
        #returns a list of nodecount, depth
        weight1 = self.W1 # Number of moves
        weight2 = self.W2
        width = self.width
        height = self.height
        depth = 0
        space = 0
        results = []
        for i in range(0,iterations):
            #This is where the call to the function goes
            #returns a list of nodecount, depth

            # test = SolverAStar(SlidingPuzzle([[4, 1, 2], [7, 5, 3], [8, 0, 6]]), 'sliding')
            # print(test.solve())
            #print("generating")
            mazeGenerated = generateSliding(width, weight1)
            maze = mazeGenerated.scramble()
            #print("Running")
            start_time = (time.time())


            #test = SolverBdAStar(BdSlidingPuzzle(maze), 'sliding')
            #results = test.solve()

            puzzle = SolverAStar(SlidingPuzzle(maze), 'sliding')
            results = puzzle.solve()

            end_time = (time.time())
            time_elasped = end_time - start_time
            self.Print_results(time_elasped, results[1], results[0], True, "Astar" )
        return self.Print_data()

    def Print_results(self, time, depth, space, optimal,search):
        #Time will be in seconds
        Seconds = time % 60
        Minutes = int(time//60)
        #if search == "Astar":
            #print ("Data collected for A* Bidirectional search with maze size ", self.width, " by ", self.height)
            #print ("Using the weights for the forward and backward, ", self.W1, " and ", self.W2, " respectively.")

        #elif search == "Genetic":
            #print ("Data collected for a Genetic search with maze size ", self.width, " by ", self.height)

        #print ("Time elapsed: ", Minutes, ":", Seconds)
        #print ("Depth requirement: ", depth)
        #print ("Space requirement: ", space)
        #if optimal:
        #    print("Result was optimal")
        #else:
        #    print("Result wasn't optimal")
        #print()
        print(self.Results)
        self.Results.append([time,depth,space])

    def Change_weights(self, weight1, weight2):
        self.weight_forward = weight1
        self.weight_backward = weight2
        return

    def Print_data(self):
        count = 0
        total_time = 0
        total_depth = 0
        total_space = 0

        for i in self.Results:
            print(i)
            total_time = total_time + i[0]
            total_depth = total_depth + i[1]
            total_space = total_space + i[2]
            count = count + 1

        ave_time = total_time/count
        ave_depth = total_depth/count
        ave_space = total_space/count

        ave_min = ave_time//60
        ave_sec = ave_time%60

        output ="Sample Size: "+ str(count) +" Size W: " + str(self.width)+ " H: " + str(self.height) + " Time: " + str(ave_min) + ":" + str(ave_sec) + " Depth: " + str(ave_depth) + " Space: " + str(ave_space)

        print("Data results for a ", self.width, " by ", self.height, " maze.")
        #print("Average time of all test cases was ", ave_min, ":", ave_sec)
        #print("Average depth requirement was ", ave_depth)
        #print("Average space requirement was ", ave_space)
        return output

#Testing out the class

def test():
    results = ""
    count = 1
    n = 0
    w = 1

    for m in range(2,n+1):
        results += "\n Puzzle size increased to: " + str(m) + " Number of moves used to scramble the puzzle: "+ str(w*m*m-1) +"\n"
        results += str("Sliding Puzzle using Bidirectional A*:") + "\n"

        for test in range(0, count):
            Test2 = Datacollection(m, m, w*m*m-1, w*m*m-1)
            results += str(Test2.A_search(1)) + " \n"

        results += "\n Puzzle size increased to: " + str(m) + " Number of moves used to scramble the puzzle: " + str(2 * w * m * m-1) + "\n"
        results += str("Sliding Puzzle using Bidirectional A*:") + "\n"

        for test in range(0, count):
            Test2 = Datacollection(m, m, 2 * w * m * m-1, 2 * w * m * m-1)
            results += str(Test2.A_search(1)) + " \n"

        results += "\n Puzzle size increased to: " + str(m) + " Number of moves used to scramble the puzzle: " + str(3 * w * m * m-1) + "\n"
        results += str("Sliding Puzzle using Bidirectional A*:") + "\n"

        for test in range(0, count):
            Test2 = Datacollection(m, m, 3 * w * m * m-1, 3 * w * m * m-1)
            results += str(Test2.A_search(1)) + " \n"

    with open('Output.txt', 'w') as f:
        f.write(results)
        print(results)

    t = 0
    p = 0
    for m in range(4,t+3):

        results += "\n Puzzle size increased to: " + str(m) + " Number of moves used to scramble the puzzle: "+ str(10) +"\n"
        results += str("Sliding Puzzle using Bidirectional A*:") + "\n"

        for test in range(0, count):
            Test2 = Datacollection(m, m, 10, 10)
            results += str(Test2.A_search(10)) + " \n"



        results += "\n Puzzle size increased to: " + str(m) + " Number of moves used to scramble the puzzle: "+ str(20) +"\n"
        results += str("Sliding Puzzle using Bidirectional A*") + "\n"

        for test in range(0, count):
            Test2 = Datacollection(m, m, 20, 20)
            results += str(Test2.A_search(10)) + " \n"

        #with open("Output"+str(p)+".txt", 'w') as f:
         #   f.write(results)
         #   print(results)
        #p+=1

        results += "\n Puzzle size increased to: " + str(m) + " Number of moves used to scramble the puzzle: "+ str(30) +"\n"
        results += str("Sliding Puzzle using Bidirectional A*") + "\n"

        for test in range(0, count):
            Test2 = Datacollection(m, m, 30, 30)
            results += str(Test2.A_search(10)) + " \n"

        with open("Output.txt", 'w') as f:
            f.write(results)
            print(results)

        results += "\n Puzzle size increased to: " + str(m) + " Number of moves used to scramble the puzzle: "+ str(40) +"\n"
        results += str("Sliding Puzzle using Bidirectional A*") + "\n"

        for test in range(0, count):
            Test2 = Datacollection(m, m, 40, 40)
            results += str(Test2.A_search(10)) + " \n"

        with open("Output.txt", 'w') as f:
            f.write(results)
            print(results)

        results += "\n Puzzle size increased to: " + str(m) + " Number of moves used to scramble the puzzle: "+ str(50) +"\n"
        results += str("Sliding Puzzle using Bidirectional A*") + "\n"

        for test in range(0, count):
            Test2 = Datacollection(m, m, 50, 50)
            results += str(Test2.A_search(10)) + " \n"

        with open("Output.txt", 'w') as f:
            f.write(results)
            print(results)



    t = 7
    results = ""
    for m in range(0,t):

        size = 10*m + 40

        results += "\n Puzzle size increased to: " + str(3) + " Number of moves used to scramble the puzzle: "+ str(size) +"\n"
        results += str("Sliding Puzzle using Bidirectional A*:") + "\n"

        for test in range(0, count):
            Test2 = Datacollection(3, 3, size, size)
            results += str(Test2.A_search(1)) + " \n"

        with open("Output1.txt", 'w') as f:
            f.write(results)
            print(results)

        results += "\n Puzzle size increased to: " + str(4) + " Number of moves used to scramble the puzzle: "+ str(size) +"\n"
        results += str("Sliding Puzzle using Bidirectional A*") + "\n"

        for test in range(0, count):
            Test2 = Datacollection(4, 4, size, size)
            results += str(Test2.A_search(1)) + " \n"

        with open("Output1.txt", 'w') as f:
            f.write(results)
            print(results)

        results += "\n Puzzle size increased to: " + str(5) + " Number of moves used to scramble the puzzle: "+ str(size) +"\n"
        results += str("Sliding Puzzle using Bidirectional A*") + "\n"

        for test in range(0, count):
            Test2 = Datacollection(5, 5, size, size)
            results += str(Test2.A_search(1)) + " \n"

        with open("Output1.txt", 'w') as f:
            f.write(results)
            print(results)

        results += "\n Puzzle size increased to: " + str(6) + " Number of moves used to scramble the puzzle: "+ str(size) +"\n"
        results += str("Sliding Puzzle using Bidirectional A*") + "\n"

        for test in range(0, count):
            Test2 = Datacollection(6, 6, size, size)
            results += str(Test2.A_search(1)) + " \n"

        with open("Output1.txt", 'w') as f:
            f.write(results)
            print(results)

        results += "\n Puzzle size increased to: " + str(7) + " Number of moves used to scramble the puzzle: "+ str(size) +"\n"
        results += str("Sliding Puzzle using Bidirectional A*") + "\n"

        for test in range(0, count):
            Test2 = Datacollection(7, 7, size, size)
            results += str(Test2.A_search(1)) + " \n"

        with open("Output1.txt", 'w') as f:
            f.write(results)
            print(results)
test()


#Test1 = Datacollection(20,20, True,.5,.5)
#Test1.Print_results(1000,800,900,True, "Astar")
#Test1.Print_results(200,400,500,False, "Genetic")