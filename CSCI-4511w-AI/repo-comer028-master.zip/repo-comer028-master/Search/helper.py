from copy import deepcopy

def permute( Alist, idx=0, Plist = None ):
	if Plist == None:
		Plist = []
	"""Logic inspired by http://stackoverflow.com/questions/8306654/finding-all-possible-permutations-of-a-given-string-in-python
	"""

	if idx >= len(Alist):
		Plist.append( Alist )

	for s in range( idx, len(Alist) ):
		newList = deepcopy( Alist )
		newList[idx], newList[s] = newList[s], newList[idx]
		permute( newList, idx+1, Plist )
	return Plist

def flatten( Alist ):
	z = []
	for el in Alist:
		z.extend(el)
	return z

def makeBoxes( Alist, bRows, bCols ) :

	puzzleSize = len(Alist)
	boxesAcrossCols = puzzleSize // bCols
	boxesDownRows = puzzleSize // bRows
	boxesTotal = boxesAcrossCols * boxesDownRows

	boxes = [ [] for b in range( boxesTotal )]
	for b in range( boxesTotal ):
		for row in range( b%boxesDownRows*bRows, b%boxesDownRows*bRows+bRows ):
			boxes[b].extend( Alist[row][b//boxesDownRows*bCols : b//boxesDownRows*bCols+bCols] )
	return boxes

def testMakeBoxes():
	A = [[1, 2, 1, 2],
		 [3, 4, 3, 4],
		 [1, 2, 1, 2],
		 [3, 4, 3, 4]]

	B2 = [
		[ 1,2, 1,2, 1, 2 ],
		[ 3,4, 3,4, 3, 4 ],
		[ 5,6, 5,6, 5, 6 ],
		[ 1,2, 1,2, 1, 2 ],
		[ 3,4, 3,4, 3, 4 ],
		[ 5,6, 5,6, 5, 6 ] ]

	B = [[ 1, 2, 3, 1, 2, 3],
	[ 4, 5, 6, 4, 5, 6],
	[ 1, 2, 3, 1, 2, 3],
	[ 4, 5, 6, 4, 5, 6],
	[ 1, 2, 3, 1, 2, 3],
	[ 4, 5, 6, 4, 5, 6]]

	C = [[ 1, 2, 3, 12, 2, 3, 19, 2, 3 ],
	[ 4, 5, 6, 4, 5, 6, 4, 5, 6 ],
	[ 7, 8, 9, 7, 8, 9, 7, 8, 9 ],
	[ 1, 2, 3, 1, 2, 3, 18, 2, 3 ],
	[ 4, 5, 6, 4, 5, 6, 4, 5, 6 ],
	[ 7, 8, 9, 7, 8, 9, 7, 8, 9 ],
	[ 1, 2, 3, 1, 2, 3, 16, 2, 3 ],
	[ 4, 5, 6, 4, 5, 6, 4, 5, 6 ],
	[ 7, 8, 9, 7, 8, 9, 7, 8, 9 ]]

	print(makeBoxes(B,2,3))


