
from copy import deepcopy
from functools import reduce

from helper import permute
from helper import flatten
from bfs import *
from Problem import *


#Test cases are at the bottom
def Solver(puzzle, r, c, search='bfs', printSolution=False):
    if (search == 'dfs'):
        solution = DFS(Problem(puzzle,r,c, printSolution))
    else:
        solution = BFS(Problem(puzzle,r,c, printSolution))

    # If the puzzle has no solution the search will return None
    if solution == None:
        print("No Solution for this Puzzle")
        return []
    return solution.getState()


# Here are the sample Sudoku to use for testing
p0 = [[1, 0, 0,0],
      [ 0,3, 0,0],
      [ 0, 0,4,0],
      [ 0,2, 0,0]]

p1 = [[1,5,0, 0,4,0],
      [2,4,0, 0,5,6],

      [4,0,0, 0,0,3],
      [0,0,0, 0,0,4],

      [6,3,0, 0,2,0],
      [0,2,0, 0,3,1]]

p12 = [[1,5,0, 0,4,0],
      [2,4,3, 1,5,6],

      [4,6,0, 5,0,3],
      [0,1,0, 2,0,4],

      [6,3,1, 4,2,0],
      [0,2,0, 0,3,1]]

p2 = [[0,0,0, 0,4,0],
      [5,6,0, 0,0,0],

      [3,0,2, 6,5,4],
      [0,4,0, 2,0,3],

      [4,0,0, 0,6,5],
      [1,5,6, 0,0,0]]

p3 = [[0,0,0, 8,4,0, 6,5,0],
      [0,8,0, 0,0,0, 0,0,9],
      [0,0,0, 0,0,5, 2,0,1],

      [0,3,4, 0,7,0, 5,0,6],
      [0,6,0, 2,5,1, 0,3,0],
      [5,0,9, 0,6,0, 7,2,0],

      [1,0,8, 5,0,0, 0,0,0],
      [6,0,0, 0,0,0, 0,4,0],
      [0,5,2, 0,8,6, 0,0,0]]


#Solver(p0, 2, 2, 'dfs', True)
#Solver(p12, 2, 3, 'dfs', True)
#Solver(p2, 2, 3, 'dfs', True)
#Solver(p1, 2, 3, 'dfs', True)
#Solver(p3, 3, 3, 'dfs', True)