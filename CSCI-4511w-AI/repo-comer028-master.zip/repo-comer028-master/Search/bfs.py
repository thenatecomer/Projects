

from copy import deepcopy
from collections import deque

class Node:

	nodeCount = 0

	def __init__(self, state, parent=None, action=None):
		self.state = state
		self.nodeCount = 0
		if parent:
			self.depth = parent.depth + 1

	def expand(self, problem):
		return [ self.makeChild( problem, action) for action in problem.getActions( self.state ) ]

	def makeChild(self, problem, action):
		Node.nodeCount += 1
		if 0 == (Node.nodeCount % 1000000) :
			print( 'nodeCount: ',Node.nodeCount )
		childState = problem.applyAction( self.state, action )
		return Node( childState )

	def getState(self ):
		return self.state


def BFS(problem):
	node = Node( problem.initial )

	if problem.isGoal( node.getState() ):
		return node

	frontier=deque()
	frontier.append(node)

	while len(frontier) > 0:
		node = frontier.popleft()
		for child in node.expand(problem):
			if problem.isGoal( child.getState() ):
				return child
			frontier.append(child)
	return None

def DFS(problem) :
	node = Node(problem.initial)

	if problem.isGoal(node.getState()):
		return node

	# Deque is a data structure that can function as both a queue and stack so we will keep it
	frontier = deque()
	frontier.append(node)

	while len(frontier) > 0:

		# Changing the pop so it removes the last node instead of the first turns the frontier into a stack
		# thus it will do depth-first traversal of the graph instead of breadth-first
		node = frontier.pop()
		for child in node.expand(problem):
			if problem.isGoal(child.getState()):
				return child
			frontier.append(child)
	return None
