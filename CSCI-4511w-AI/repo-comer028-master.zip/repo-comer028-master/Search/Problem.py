from copy import deepcopy
from functools import reduce
from helper import permute
from helper import flatten
from helper import *
from bfs import *

class Problem(object):
    def __init__(self, initial, rows, cols, printSolution = "False", goal=None):
        self.size = rows * cols
        self.initial = initial
        self.goal = goal
        # count used only for printing purposes
        self.count = 0
        self.r = rows
        self.c = cols
        self.printSolution = printSolution

        self.actions = [i for i in range(1,self.size+1)]

    def getActions( self, state ) :

        # a -1 is placed in state[0][0] to mark a state for removal (pruning)
        # this if statement will prune the node (it will have no children)
        if state[0][0] == -1:
            return []

        actionsLeft = set(self.actions)
        notLeft = set(self.actions)
        # Variable notLeft being used to find which values are present in all rows
        for row in state:
            notLeft = notLeft.intersection(set(row))

        # The difference between actionsLeft and notLeft are the values that are not already present in all rows
        # Thus all values returned from getActions will have a legal square to be placed if this state is leading
        # to the correct solution
        return list(actionsLeft.difference(notLeft))

    # sameBox is used to check if an action matches a value already within a box
    def sameBox(self, state, boxes, row, col, action):
        if self.size == 4:
            if col <= 1 and row <= 1:
                return action in boxes[0]
            elif col >= 2 and row <= 1:
                return action in boxes[2]
            elif col <= 1 and row >= 2:
                return action in boxes[1]
            else:
                return action in boxes[3]
        if self.size == 6 and self.r < self.c:
            if row <= 1 and col <= 2:
                return action in boxes[0]
            elif col >= 3 and row <= 1:
                return action in boxes[3]
            elif col <=2 and row >= 2 and row <= 3:
                return action in boxes[1]
            elif col >= 3 and row >= 2 and row <=3:
                return action in boxes[4]
            elif col <=2 and row >= 4:
                return action in boxes[2]
            else:
                return action in boxes[5]
        if self.size == 6 and self.r > self.c:
            if col <= 1 and row <= 2:
                return action in boxes[0]
            elif row >= 3 and col <= 3 and col >= 2:
                return action in boxes[3]
            elif col <=1 and row >= 3:
                return action in boxes[1]
            elif col >= 4 and row <= 2:
                return action in boxes[4]
            elif col >=2 and row <= 2 and col <=3:
                return action in boxes[2]
            else:
                return action in boxes[5]
        if self.size == 9:
            if col <= 2 and row <= 2:
                return action in boxes[0]
            elif col >= 3 and row <= 2 and col <=5:
                return action in boxes[3]
            elif col >= 6 and row <= 2:
                return action in boxes[6]

            elif col <= 2 and row >= 3 and row <= 5:
                return action in boxes[1]
            elif col >= 3 and row >= 3 and col <= 5 and row <= 5:
                return action in boxes[4]
            elif col >= 6 and row >= 3 and row <= 5:
                return action in boxes[7]

            elif col <= 2 and row >= 6:
                return action in boxes[5]
            elif col >= 6 and row >= 6:
                return action in boxes[8]
            else:
                return action in boxes[5]

    # sameCol used to check if an action matches a value already in a column
    def sameCol(self, state, col, action):
        for row in state:
            if action == row[col]:
                return True
        return False

    def applyAction ( self, state, action ) :
        newState = deepcopy(state)
        flat = flatten(state)
        idx = len(flat)
        row = 0
        col = idx % self.size

        # Make boxes
        boxify = makeBoxes(state, self.r, self.c)


        # While loop that goes through the state looking for where the action can be legally placed
        # if theres no place to legally put the action the state is illegal
        while (state[row][col] != 0) or (action in state[row]) or (Problem.sameBox(self, state, boxify, row, col, action)) or (Problem.sameCol(self, state, col, action)):
            if row >= self.size - 1 and col >= self.size - 1:
                # if this point is reached this state can't be the solution so we will mark it for removal using a -1
                newState[0][0]=-1
                return newState
            elif col >= self.size - 1:
                row += 1
                col = 0
            elif col < self.size - 1:
                col += 1

        if ( 0 == col ):
            newState[row][col] = action
        else :
            newState[row][col] = action

        return newState




    def isGoal ( self, state ):

        # If the state is empty, not done yet
        if not state:
            print("no state")
            return False
        # We have a completely filled in board. Check if there are any
        # duplicates across columns or rows
        for row in state:
            if 0 in row:
                self.count += 1
                if self.count %100000 == 0:
                    print("still contains zeroes", state)
                return False
            if len(list(set(row))) < self.size :
                print("found duplicates:", state)
                return False
        for col in range(self.size):
            if len( list(set([row[col] for row in state] ) )) < self.size :
                print('State ',state,' not goal')
                return False

        # If we got here, the board is complete and legal
        print('WINNER')
        if self.printSolution == True:
            for i in range(self.r * self.c):
                output = ''
                for j in range(self.r * self.c):
                    output += '   ' + str(state[i][j])
                print(output)
        return True
