/* Ready, Set, Go ...
$ swipl  # start prolog
?-       # now in prolog
?- consult( prologStarter ).  # load file prologStarter.pl
?- reconsult( prologStarter). # reload the file
?- append([a,b],[c],X).       # lower case are literals. Upper are variables.
?- trace.                     # trace commands
?- notrace.                   # stop tracing
?- a                          # abort the call (while in trace)
?- halt.                      # exit prolog
?- [user].                    # enter rules via command line
   .....   Ctrl-D             # stop enter mode
*/



/* example from book */
append([],X,X).
append([H|T],Y,[H|Z]) :- append(T,Y,Z).

mynext( X, Y ) :- Y is X+1.

/* not used, but might be handy */
all_different([]).
all_different([_]).
all_different([H,T]) :- \+ H=T, all_different([T]).
all_different([H,X|T]) :- \+ H=X, all_different([H|T]), all_different([X|T]).

not_in([],_).
not_in([H|T],X) :- \+ H==X, not_in( T, X ).

atmost1(L,X) :- atmost1(L,X,0).
atmost1([],_,N) :- N < 2.
atmost1([X|T],X,N) :- N2 is N+1, atmost1( T, X, N2).
atmost1([H|T],X,N) :- \+ H==X, atmost1( T, X, N).


/* --- generate unique permutations --- */

domain([one,two,three]).

unique([A1,A2,A3]) :-
    domain(X),

    member( A1, X ),
    member( A2, X ),
    member( A3, X ),

    all_different([A1,A2,A3]),

    true.

/* --------- WUMPUS STARTER ------------ */

not(pit( X, Y )) :-
    Z is 1+X, not(breeze( Z, Y )),
    Z is 1+Y, not(breeze( X, Z )).

/* -------------------- LOGIC PIE PUZZLE */
/* in prolog, type [pies]. Once loaded, type pied(X) for solution */

pies([bc,pc,ap,bb,cc]).
fruit([bc,ap,bb]).
dairy([bc,cc]).

pied([Rocky,Sam,Davis,Brandi,Mala]) :-
    pies(P),
    fruit(F),
    dairy(D),

    /* Rocky not Blueberry and not dairy */
    member(Rocky,P), \+ Rocky=bb, not_in(D,Rocky),
    atmost1( [Sam,Davis,Brandi,Mala,Rocky], Rocky ),

    /* Sam is pecan */
    Sam=pc,
    atmost1( [Sam,Davis,Brandi,Mala,Rocky], Sam ),

    /* Davis not banana cream and not fruit */
    member(Davis,P), \+ Davis=bc, not_in(F,Davis),
    atmost1( [Sam,Davis,Brandi,Mala,Rocky], Davis ),

    /* Mala not dairy */
    member(Mala,P), not_in( D, Mala),
    atmost1( [Sam,Davis,Brandi,Mala,Rocky], Mala ),

    /* Brandi is flexible */
    member(Brandi,P),
    atmost1( [Sam,Davis,Brandi,Mala,Rocky], Brandi ),

    /* "true" allows me to always have , after each line */
    true.

/* Prolog Robots Homework */

ages([3,4,5,6,8]).
odd([3,5]).

robots([Red,Green,Blue,Yellow,Orange]) :-
    ages(A),
    odd(O),

    Green=5,
    atmost1([Red,Green,Blue,Yellow,Orange], Green),

    member(Blue,A), member(Yellow,A),
    Blue is Green+1, Blue is Yellow-2,
    atmost1([Red,Green,Blue,Yellow,Orange], Blue),
    atmost1([Red,Green,Blue,Yellow,Orange], Yellow),

    member(Red,A), member(Red,O),
    atmost1([Red,Green,Blue,Yellow,Orange], Red),

    member(Orange,A),
    atmost1([Red,Green,Blue,Yellow,Orange], Orange),

    true.

/* Prolog KenKen Homework */

vars([1,2,3]).

kenken([A1, A2, A3, B1, B2, B3, C1, C2, C3]) :-
    vars(V),

    A3=2,

    member(A1,V), member(A2,V), ((A1 =:= A2+2); (A2 =:= A1+2)),

    member(B1,V), member(C1,V), ((B1 =:= 2*C1); (C1 =:= 2*B1)),

    member(B2,V), member(B3,V), ((B2 =:= 3*B3); (B3 =:= 3*B2)),

    member(C2,V), member(C3,V), ((C2 =:= 1+C3); (C3 =:= 1+C2)),

    maplist(all_different,[[A1,A2,A3],[B1,B2,B3],[C1,C2,C3]]),
    maplist(all_different,[[A1,B1,C1],[A2,B2,C2],[A3,B3,C3]]),

    true.
