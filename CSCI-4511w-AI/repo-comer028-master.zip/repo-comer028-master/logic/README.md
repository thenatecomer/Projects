All parts should be functioning correctly.

Prolog:

Robots run with: robots(X).

KenKen run with: kenken(X).


Lisp:

KenKen run with: (AC3 kenconstraints boxvars)
