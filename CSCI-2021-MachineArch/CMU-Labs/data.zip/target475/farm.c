/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_484(unsigned x)
{
    return x + 2425393752U;
}

unsigned addval_223(unsigned x)
{
    return x + 1478772827U;
}

void setval_285(unsigned *p)
{
    *p = 2428995912U;
}

unsigned getval_301()
{
    return 3281031256U;
}

void setval_433(unsigned *p)
{
    *p = 3267856712U;
}

void setval_124(unsigned *p)
{
    *p = 3284638024U;
}

void setval_340(unsigned *p)
{
    *p = 3347662876U;
}

unsigned addval_365(unsigned x)
{
    return x + 2425393232U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_404()
{
    return 3380136585U;
}

unsigned getval_314()
{
    return 3397992487U;
}

unsigned addval_306(unsigned x)
{
    return x + 3372794121U;
}

unsigned addval_432(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_187()
{
    return 3372794241U;
}

unsigned addval_337(unsigned x)
{
    return x + 3234125449U;
}

void setval_199(unsigned *p)
{
    *p = 3353381192U;
}

void setval_244(unsigned *p)
{
    *p = 3372796617U;
}

unsigned addval_466(unsigned x)
{
    return x + 2713966217U;
}

unsigned addval_166(unsigned x)
{
    return x + 2430634312U;
}

void setval_207(unsigned *p)
{
    *p = 3767027940U;
}

void setval_421(unsigned *p)
{
    *p = 3286272330U;
}

void setval_177(unsigned *p)
{
    *p = 3229144713U;
}

unsigned getval_277()
{
    return 3531915721U;
}

unsigned addval_438(unsigned x)
{
    return x + 2430634824U;
}

void setval_273(unsigned *p)
{
    *p = 3536112265U;
}

unsigned getval_143()
{
    return 3676359305U;
}

void setval_366(unsigned *p)
{
    *p = 3674259849U;
}

void setval_392(unsigned *p)
{
    *p = 3683961481U;
}

unsigned addval_492(unsigned x)
{
    return x + 3380139657U;
}

unsigned addval_116(unsigned x)
{
    return x + 2425542281U;
}

unsigned getval_215()
{
    return 3380920745U;
}

unsigned addval_485(unsigned x)
{
    return x + 2430634316U;
}

unsigned getval_410()
{
    return 3767101624U;
}

unsigned getval_156()
{
    return 2126763657U;
}

void setval_427(unsigned *p)
{
    *p = 3687104905U;
}

unsigned addval_409(unsigned x)
{
    return x + 3380923019U;
}

void setval_350(unsigned *p)
{
    *p = 3383023241U;
}

void setval_498(unsigned *p)
{
    *p = 3375942297U;
}

void setval_351(unsigned *p)
{
    *p = 3599600052U;
}

unsigned getval_435()
{
    return 3246987428U;
}

void setval_162(unsigned *p)
{
    *p = 3523789193U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
