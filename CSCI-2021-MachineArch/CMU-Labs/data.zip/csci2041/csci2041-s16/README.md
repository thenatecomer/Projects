# csci2041-s16
repository for Csci 2041 Spring 2016, day and evening.
This will be used to deposit files that are useful for homeworks and labs.
