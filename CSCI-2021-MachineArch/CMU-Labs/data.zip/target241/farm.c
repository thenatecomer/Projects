/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_242(unsigned *p)
{
    *p = 3281031256U;
}

unsigned addval_429(unsigned x)
{
    return x + 3277337108U;
}

unsigned addval_114(unsigned x)
{
    return x + 3347695791U;
}

void setval_177(unsigned *p)
{
    *p = 3284633920U;
}

unsigned getval_431()
{
    return 3284633928U;
}

unsigned addval_174(unsigned x)
{
    return x + 2428995912U;
}

void setval_206(unsigned *p)
{
    *p = 3247476824U;
}

unsigned addval_306(unsigned x)
{
    return x + 3472607064U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_315()
{
    return 3281043849U;
}

void setval_488(unsigned *p)
{
    *p = 1405340297U;
}

void setval_267(unsigned *p)
{
    *p = 3525364377U;
}

unsigned addval_418(unsigned x)
{
    return x + 2430634440U;
}

void setval_408(unsigned *p)
{
    *p = 2430601544U;
}

void setval_170(unsigned *p)
{
    *p = 3767093453U;
}

unsigned getval_344()
{
    return 3281049229U;
}

void setval_181(unsigned *p)
{
    *p = 2447411528U;
}

unsigned getval_375()
{
    return 3284244944U;
}

unsigned getval_198()
{
    return 4089627017U;
}

void setval_271(unsigned *p)
{
    *p = 3767093419U;
}

unsigned addval_143(unsigned x)
{
    return x + 3676357033U;
}

unsigned getval_262()
{
    return 3525367435U;
}

void setval_473(unsigned *p)
{
    *p = 2425539209U;
}

void setval_168(unsigned *p)
{
    *p = 3221277321U;
}

void setval_159(unsigned *p)
{
    *p = 3221799321U;
}

void setval_436(unsigned *p)
{
    *p = 3525367497U;
}

unsigned addval_133(unsigned x)
{
    return x + 3268053403U;
}

unsigned addval_447(unsigned x)
{
    return x + 3286272320U;
}

unsigned addval_370(unsigned x)
{
    return x + 4190361225U;
}

void setval_202(unsigned *p)
{
    *p = 3224950473U;
}

void setval_497(unsigned *p)
{
    *p = 3281046153U;
}

unsigned getval_394()
{
    return 3676886665U;
}

unsigned getval_146()
{
    return 3351939504U;
}

unsigned getval_111()
{
    return 3682912897U;
}

unsigned getval_396()
{
    return 3374896777U;
}

void setval_124(unsigned *p)
{
    *p = 3284238840U;
}

unsigned addval_171(unsigned x)
{
    return x + 3281043849U;
}

unsigned getval_374()
{
    return 3285617110U;
}

unsigned getval_288()
{
    return 2447411528U;
}

unsigned getval_355()
{
    return 3252717896U;
}

unsigned addval_182(unsigned x)
{
    return x + 3523789065U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
