
// Nathan Comer
// Program 3

var canvas;
var gl;
var programId;
var vNorms;
var normsBuffer;

var numCurves = 2;
var stepsPerCurve = 10;
var numAngles = 20;

var lightVec = vec4(10.0, 5.0, -10.0, 1.0); // Initial light position
var lightPosition;
var texCoordsArray;
var tBuffer;
var texMapBool;
var image;
var lightTransform = mat4(1); // Stores transformation for light position
var newlightTransform;

// Binds "on-change" events for the controls on the web page
function initControlEvents() {
    // Use one event handler for all of the shape controls
    document.getElementById("shape-select").onchange = 
    document.getElementById("numAngles").onchange =
    document.getElementById("stepsPerCurve").onchange =
        function(e) {
            var shape = document.getElementById("shape-select").value;
            numAngles = parseFloat(document.getElementById("numAngles").value);
            stepsPerCurve = parseFloat(document.getElementById("stepsPerCurve").value);
            
            // Regenerate the vertex data
            if (shape == "profile1") {init1(cntrlPnts)}
            else if (shape == "profile2") {init2(cntrlPnts)}
            else if (shape == "profile3") {init3(cntrlPnts)}
            else if (shape == "profile4") {init4(cntrlPnts)}
            else if (shape == "profile5") {init5(cntrlPnts)};
            buildSurfaceOfRevolution(cntrlPnts);
            updateBuffer();
        };

    document.getElementById("surface-select").onchange =
        function(e) {
            var surface = document.getElementById("surface-select").value;
            numAngles = parseFloat(document.getElementById("numAngles").value);
            stepsPerCurve = parseFloat(document.getElementById("stepsPerCurve").value);
            
            // Change what object is being viewed
            if (surface == "Yellow Plastic") {setPlastic()}
            else if (surface == "Brass Metal") {setBrass()}
            else if (surface == "Texture Map Wood") {setWood()}
            else if (surface == "Texture Map Tile") {setTile()}
            buildSurfaceOfRevolution(cntrlPnts);
            updateBuffer();
        };
    // Event handler for the foreground color control
    document.getElementById("foreground-color").onchange = 
        function(e) {
            updateTriangleColor(getTriangleColor());
        };
        
    // Event handler for the FOV control
    document.getElementById("fov").onchange =
        function(e) {
            updateProjection(perspective(getFOV(), 1, 0.01, 100));
        };
}

function setPlastic(){

    // Diffuse has reflectance of material
    // Specular component has non-selective reflectance
    // some ambient added so it doesn't look like it's in deep space
    var texMapBool = 0;
    gl.uniform1f(locations.texMapBool, texMapBool);
    var lightAmbient = vec4(1,1,0,1.0);
    var materialAmbient = vec4(.09,.09,0,1.0);
    var ambientProduct = mult(lightAmbient, materialAmbient);
    gl.uniform4fv(locations.ambientProduct, flatten(ambientProduct));

    var lightDiffuse = vec4(.8,.8,.00,1.0);
    var materialDiffuse = vec4(.8,.8,.00,1.0);
    var diffuseProduct = mult(lightDiffuse, materialDiffuse);
    gl.uniform4fv(locations.diffuseProduct, flatten(diffuseProduct));

    var lightSpecular = vec4(.75,.75,.75,1.0);
    var materialSpecular = vec4(.75,.75,.75,1.0);
    var specularProduct = mult(lightSpecular, materialSpecular);
    gl.uniform4fv(locations.specularProduct, flatten(specularProduct));

    var shininess = 10;
    gl.uniform1f(locations.shininess, shininess);
    buildSurfaceOfRevolution(cntrlPnts);
}

function setBrass(){

    // All specular, reflectance of material
    // Some ambient added so it doesn't look like it's in deep space
    var texMapBool = 0;
    gl.uniform1f(locations.texMapBool, texMapBool);
    var lightAmbient = vec4(1,1,1,1.0);
    var materialAmbient = vec4(.52,.47,.19,1.0);
    var ambientProduct = mult(lightAmbient, materialAmbient);
    gl.uniform4fv(locations.ambientProduct, flatten(ambientProduct));

    var lightDiffuse = vec4(1,1,1,1.0);
    var materialDiffuse = vec4(0,0,0,1.0);
    var diffuseProduct = mult(lightDiffuse, materialDiffuse);
    gl.uniform4fv(locations.diffuseProduct, flatten(diffuseProduct));

    var lightSpecular = vec4(1,1,1,1.0);
    var materialSpecular = vec4(.98,.9,.357,1.0);
    var specularProduct = mult(lightSpecular, materialSpecular);
    gl.uniform4fv(locations.specularProduct, flatten(specularProduct));

    var shininess = 48;
    gl.uniform1f(locations.shininess, shininess);
    buildSurfaceOfRevolution(cntrlPnts);
}

function setWood(){
    var texMapBool = 1;
    gl.uniform1f(locations.texMapBool, texMapBool);
    setDefault();
    image = document.getElementById("wood-img");
    initializeTextures(image);
    buildSurfaceOfRevolution(cntrlPnts);
}

function setTile(){
    var texMapBool = 1;
    gl.uniform1f(locations.texMapBool, texMapBool);
    setDefault();
    image = document.getElementById("tile-img");
    initializeTextures(image);
    buildSurfaceOfRevolution(cntrlPnts);
}

// Function for querying the current triangle color
function getTriangleColor() {
    var hex = document.getElementById("foreground-color").value;
    var red = parseInt(hex.substring(1, 3), 16);
    var green = parseInt(hex.substring(3, 5), 16);
    var blue = parseInt(hex.substring(5, 7), 16);
    return vec3(red / 255.0, green / 255.0, blue / 255.0);
}

// Function for querying the current field of view
function getFOV() {
    return parseFloat(document.getElementById("fov").value);
}

window.onload = function() {
    
    // Find the canvas on the page
    canvas = document.getElementById("gl-canvas");
    
    // Initialize a WebGL context
    gl = WebGLUtils.setupWebGL(canvas);
    if (!gl) { 
        alert("WebGL isn't available"); 
    }

    gl.enable(gl.DEPTH_TEST);
    
    // Load shaders
    programId = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(programId);
    
    // Set up events for the HTML controls
    initControlEvents();

    // Setup mouse and keyboard input
    initWindowEvents();
    
    // Configure WebGL
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(0.0, 0.0, 0.0, 1.0);
    
    // Load the initial data into the GPU
    triangleBufferId = gl.createBuffer(gl.ARRAY_BUFFER);
    tBuffer = gl.createBuffer();
    normsBuffer = gl.createBuffer();
    
   
    init1(cntrlPnts);
    buildSurfaceOfRevolution(cntrlPnts);
    setTile();

    // Associate the shader variable for position with our data buffer
    var vPosition = gl.getAttribLocation(programId, "vPosition");
    gl.vertexAttribPointer(vPosition, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    texMapBool = 1;
    locations.texMapBool = gl.getUniformLocation(programId, "texMapBoolean");
    gl.uniform1f(locations.texMapBool, texMapBool);

    updateBuffer();

    // Initialize the view and rotation matrices
    findShaderVariables();
    viewMatrix = lookAt(vec3(0,0,5), vec3(0,0,0), vec3(0,1,0));
    rotationMatrix = mat4(1);
    setDefault();
    updateModelView(viewMatrix);
    
    // Initialize the projection matrix
    updateProjection(perspective(getFOV(), 1, 0.01, 100));
    
    // Initialize the triangle color
    updateTriangleColor(getTriangleColor());

    // Start continuous rendering
    window.setInterval(render, 33);
};

function updateBuffer(){
    gl.bindBuffer(gl.ARRAY_BUFFER, normsBuffer );
    gl.bufferData(gl.ARRAY_BUFFER, flatten(vNorms), gl.DYNAMIC_DRAW);

    var vNormal = gl.getAttribLocation(programId, "vNormal");
    gl.vertexAttribPointer(vNormal, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vNormal);
}

function log(msg) {
    setTimeout(function() {
        throw new Error(msg);
    }, 0);
}

// The current view matrix
var viewMatrix;

// The current rotation matrix produced as the result of cumulative mouse drags.
// I chose to implement the effect of mouse dragging as "rotating the object."
// It would also be acceptable to implement it as "moving the camera."
var rotationMatrix;

// The OpenGL ID of the vertex buffer containing the current shape
var triangleBufferId;

// The number of vertices in the current vertex buffer
var trianglePointCount;

// Sets up keyboard and mouse events
function initWindowEvents() {

    // Affects how much the camera moves when the mouse is dragged.
    var sensitivity = 1;

    // Additional rotation caused by an active drag.
    var newRotationMatrix;
    
    // Whether or not the mouse button is currently being held down for a drag.
    var mousePressed = false;
    var shiftPressed = false;
    
    // The place where a mouse drag was started.
    var startX, startY;

    canvas.onmousedown = function(e) {
        // A mouse drag started.
        mousePressed = true;
        
        // Remember where the mouse drag started.
        startX = e.clientX;
        startY = e.clientY;
    }

    canvas.onmousemove = function(e) {
        if (mousePressed && !shiftPressed) {
            // Handle a mouse drag by constructing an axis-angle rotation matrix
            var axis = vec3(e.clientY - startY, e.clientX - startX, 0.0);
            var angle = length(axis) * sensitivity;
            if (angle > 0.0) {
                // Update the temporary rotation matrix
                newRotationMatrix = mult(rotate(angle, axis), rotationMatrix);
                
                // Update the model-view matrix.
                updateModelView(mult(viewMatrix, newRotationMatrix));
            }
        } else if(mousePressed && shiftPressed){
            var axis = vec3(e.clientY - startY, e.clientX - startX, 0.0);
            var angle = length(axis) * sensitivity;
            if (angle > 0.0) {
                // Update the temporary rotation matrix
                
                newlightTransform = mult(rotate(angle, axis),lightTransform);

                updateLight(newlightTransform);
            }
        }
    }

    window.onmouseup = function(e) {
        // A mouse drag ended.
        mousePressed = false;
        
        if (newRotationMatrix && !shiftPressed) {
            // "Lock" the temporary rotation as the current rotation matrix.
            rotationMatrix = newRotationMatrix;
        }else if (newRotationMatrix && shiftPressed){
            lightTransform = newlightTransform;
        }
        shiftPressed = false;
        newRotationMatrix = null;
    }
    
    var speed = 0.1; // Affects how fast the camera pans and "zooms"
    window.onkeydown = function(e) {
        if (e.keyCode === 190) { // '>' key
            // "Zoom" in
            viewMatrix = mult(translate(0,0,speed), viewMatrix);
        }
        else if (e.keyCode === 188) { // '<' key
            // "Zoom" out
            viewMatrix = mult(translate(0,0,-speed), viewMatrix);
        }
        else if (e.keyCode === 37) { // Left key
            // Pan left
            viewMatrix = mult(translate(speed,0,0), viewMatrix);
            
            // Prevent the page from scrolling, which is the default behavior for the arrow keys
            e.preventDefault(); 
        }
        else if (e.keyCode === 38) { // Up key
            // Pan up
            viewMatrix = mult(translate(0,-speed,0), viewMatrix);
            
            // Prevent the page from scrolling, which is the default behavior for the arrow keys
            e.preventDefault();
        }
        else if (e.keyCode === 39) { // Right key
            // Pan right
            viewMatrix = mult(translate(-speed,0,0), viewMatrix);
            
            // Prevent the page from scrolling, which is the default behavior for the arrow keys
            e.preventDefault();
        }
        else if (e.keyCode === 40) { // Down key
            // Pan down 
            viewMatrix = mult(translate(0,speed,0), viewMatrix);
            
            // Prevent the page from scrolling, which is the default behavior for the arrow keys
            e.preventDefault();
        }
        else if (e.keyCode == 16){
            if(mousePressed){
                shiftPressed = true;
            }
            e.preventDefault();
        }
        
        // Update the model-view matrix and render.
        if(!shiftPressed){
            updateModelView(mult(viewMatrix, rotationMatrix));
            render();
        }
        
    }

}

function setDefault(){
    
    var lightAmbient = vec4(.2,.2,.2,1.0);
    var materialAmbient = vec4(.2,.2,.2,1.0);
    var ambientProduct = mult(lightAmbient, materialAmbient);
    locations.ambientProduct = gl.getUniformLocation(programId, "ambientProduct");
    gl.uniform4fv(locations.ambientProduct, flatten(ambientProduct));

    var lightDiffuse = vec4(.75,.75,.75,1.0);
    var materialDiffuse = vec4(.75,.75,.75,1.0);
    var diffuseProduct = mult(lightDiffuse, materialDiffuse);
    locations.diffuseProduct = gl.getUniformLocation(programId, "diffuseProduct");
    gl.uniform4fv(locations.diffuseProduct, flatten(diffuseProduct));

    var lightSpecular = vec4(.8,.8,.8,1.0);
    var materialSpecular = vec4(.8,.8,.8,1.0);
    var specularProduct = mult(lightSpecular, materialSpecular);
    locations.specularProduct = gl.getUniformLocation(programId, "specularProduct");
    gl.uniform4fv(locations.specularProduct, flatten(specularProduct));

    lightPosition = lightVec;
    locations.lightPosition = gl.getUniformLocation(programId, "lightPosition");
    gl.uniform4fv(locations.lightPosition, flatten(lightPosition));

    lightTransform = lightTransform;
    locations.lightTransform = gl.getUniformLocation(programId, "lightTransform");
    gl.uniformMatrix4fv(locations.lightTransform, false, flatten(lightTransform));

    var shininess = 8;
    locations.shininess = gl.getUniformLocation(programId, "shininess");
    gl.uniform1f(locations.shininess, shininess);
}

//
// Create data for a surface of revolution
//

var cntrlPnts = [];

function init1(theCntrlPnts) {
    
    var numControlPoints = numCurves * 3 + 1;
    
    // Initialize control point data
    for (var i = 0; i < numControlPoints; i++)
    {
        theCntrlPnts[i] = vec4(0.5, i / (numControlPoints - 1.0) * 1.6 - 0.8, 0, 1);
    }
}

function init2(theCntrlPnts) {

    theCntrlPnts[0] = vec4(0.1, -1.0, 0.0, 1);
    theCntrlPnts[1] = vec4(0.3, -0.8, 0.0, 1);
    theCntrlPnts[2] = vec4(0.4, -0.4, 0.0, 1);
    theCntrlPnts[3] = vec4(0.45,  0.0, 0.0, 1);
    theCntrlPnts[4] = vec4(0.5,  0.4, 0.0, 1);
    theCntrlPnts[5] = vec4(0.7,  0.8, 0.0, 1);
    theCntrlPnts[6] = vec4(0.9,  1.0, 0.0, 1);
}

function init3(theCntrlPnts) {
    
    theCntrlPnts[0] = vec4(0.9, -1.0, 0.0, 1);
    theCntrlPnts[1] = vec4(0.7, -0.8, 0.0, 1);
    theCntrlPnts[2] = vec4(0.5, -0.4, 0.0, 1);
    theCntrlPnts[3] = vec4(0.5,  0.0, 0.0, 1);
    theCntrlPnts[4] = vec4(0.5,  0.4, 0.0, 1);
    theCntrlPnts[5] = vec4(0.7,  0.8, 0.0, 1);
    theCntrlPnts[6] = vec4(0.9,  1.0, 0.0, 1);
}

function init4(theCntrlPnts) {
    
    theCntrlPnts[0] = vec4(0.1, -1.0, 0.0, 1);
    theCntrlPnts[1] = vec4(0.5, -0.8, 0.0, 1);
    theCntrlPnts[2] = vec4(0.7, -0.4, 0.0, 1);
    theCntrlPnts[3] = vec4(0.7,  0.0, 0.0, 1);
    theCntrlPnts[4] = vec4(0.7,  0.4, 0.0, 1);
    theCntrlPnts[5] = vec4(0.5,  0.8, 0.0, 1);
    theCntrlPnts[6] = vec4(0.1,  1.0, 0.0, 1);
}

function init5(theCntrlPnts) {
    
    theCntrlPnts[0] = vec4(0.1, -1.0, 0.0, 1);
    theCntrlPnts[1] = vec4(0.5, -0.8, 0.0, 1);
    theCntrlPnts[2] = vec4(0.3, -0.4, 0.0, 1);
    theCntrlPnts[3] = vec4(0.2,  0.0, 0.0, 1);
    theCntrlPnts[4] = vec4(0.1,  0.4, 0.0, 1);
    theCntrlPnts[5] = vec4(0.1,  0.8, 0.0, 1);
    theCntrlPnts[6] = vec4(0.1,  1.0, 0.0, 1);
}

function getTVector(vt)
{
    // Compute value of each basis function
    var mt = 1.0 - vt;
    return vec4(mt * mt * mt, 3 * vt * mt * mt, 3 * vt * vt * mt, vt * vt * vt);
}

function dotProduct(pnt1, pnt2, pnt3, pnt4, tVal)
{
    // Take dot product between each basis function value and the x, y, and z values
    // of the control points
    return vec3(pnt1[0]*tVal[0] + pnt2[0]*tVal[1] + pnt3[0]*tVal[2] + pnt4[0]*tVal[3],
                pnt1[1]*tVal[0] + pnt2[1]*tVal[1] + pnt3[1]*tVal[2] + pnt4[1]*tVal[3],
                pnt1[2]*tVal[0] + pnt2[2]*tVal[1] + pnt3[2]*tVal[2] + pnt4[2]*tVal[3]);
}


// You will want to edit this function to compute the additional attribute data
// for texturing and lighting

function buildSurfaceOfRevolution(controlPoints)
{
    var dt = 1.0 / stepsPerCurve;
    var da = 360.0 / (numAngles);
    
    var vertices = [];
    vNorms = [];
    
    var p = 0;
    for (var i = 0; i < numCurves; i++)
    {
        var bp1 = controlPoints[i * 3 + 0];
        var bp2 = controlPoints[i * 3 + 1];
        var bp3 = controlPoints[i * 3 + 2];
        var bp4 = controlPoints[i * 3 + 3];
        
        for (var t = 0; t < stepsPerCurve; t++) {
            var p1 = dotProduct(bp1, bp2, bp3, bp4, getTVector(t * dt));
            var p2 = dotProduct(bp1, bp2, bp3, bp4, getTVector((t + 1) * dt));
            
            var savedP = p;
            for (var a = 0; a < numAngles; a++) {
                vertices[p++] = vec3(Math.cos(a * da * Math.PI / 180.0) * p1[0], p1[1],
                                     Math.sin(a * da * Math.PI / 180.0) * p1[0]);
                
                vertices[p++] = vec3(Math.cos(a * da * Math.PI / 180.0) * p2[0], p2[1],
                                     Math.sin(a * da * Math.PI / 180.0) * p2[0]);
            }
            vertices[p++] = vertices[savedP];
            vertices[p++] = vertices[savedP + 1];
        }
    }

    // Pass the new set of vertices to the graphics card
    trianglePointCount = p;

    buildNormals(vertices);
    updateTexture(vertices);
    gl.bindBuffer(gl.ARRAY_BUFFER, triangleBufferId );
    gl.bufferData(gl.ARRAY_BUFFER, flatten(vertices), gl.DYNAMIC_DRAW);

}

function initializeTextures(image){
    
    gl.bindBuffer(gl.ARRAY_BUFFER,tBuffer);
    locations.vTexCoord = gl.getAttribLocation(programId, "vTexCoord");   
    gl.vertexAttribPointer(locations.vTexCoord, 2,  gl.FLOAT,   false,  0,  0);
    gl.enableVertexAttribArray(locations.vTexCoord);

    var texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, texture);
    
    gl.texImage2D( gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, image);
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.activeTexture(gl.TEXTURE0);  
    gl.bindTexture( gl.TEXTURE_2D, texture);  
    gl.uniform1i(gl.getUniformLocation( programId, "texMap"),  0);

    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT );
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT );
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER,  gl.NEAREST  );  
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER,  gl.NEAREST  );
}

function updateTexture(vertices){
    texCoordsArray = [];
    width = document.getElementById("wood-img").naturalWidth;
    height = document.getElementById("wood-img").naturalHeight;

    var shapeHeight = stepsPerCurve*numCurves+1;
    var yCoef;
    texCoordsArray[0]=vec2(0,0);

    for (var t = 1; t < trianglePointCount; t++){
        if(t%2==0 && t>0){
            yCoef = 0;
            var xCoord = ((t%((numAngles+1)*2)) / (2*(numAngles+1)));
        }else{
            yCoef = 1;
            xCoord=previousX;
        }
        var yCoord = ((((t-(t%((numAngles+1)*2)))/(2*(numAngles+1))) + yCoef) / shapeHeight);
        var previousX = xCoord;
        texCoordsArray[t] = vec2(xCoord,yCoord);
    }
    texCoordsArray[1][0]=0;

    gl.bindBuffer(gl.ARRAY_BUFFER, tBuffer);    
    gl.bufferData(gl.ARRAY_BUFFER, flatten(texCoordsArray),gl.STATIC_DRAW);

}

var texCoordsArray = [ ];
var texCoord = [vec2(0,0), vec2(0,1), vec2(1,1), vec2(1,0)];

function buildNormals(vertices){
    t1 = subtract(vertices[1], vertices[0]);
    t2 = subtract(vertices[2], vertices[0]);
    vNorms[0] = vec3(normalize(cross(t1,t2)));
    for (var t = 1; t < trianglePointCount-1; t++){
        var isDone = false;
        n = 0;
        while(isDone == false && n < t){
            if(equal(vertices[t],vertices[n])){
                isDone = true;
                vNorms[t] = vNorms[n];
            }else{
                t1 = subtract(vertices[t+1], vertices[t]);
                t2 = subtract(vertices[t-1], vertices[t]);
                vNorms[t] = vec3(normalize(cross(t1,t2)));  
            }
            n++;
        }   
    }

    vNorms[trianglePointCount-1] = vNorms[trianglePointCount-2];//vec3(normalize(cross(t1,t2)));
}

// The locations of the required GLSL uniform variables.
var locations = {};

// Looks up the locations of uniform variables once.
function findShaderVariables() {
    locations.modelView = gl.getUniformLocation(programId, "modelView");
    locations.projection = gl.getUniformLocation(programId, "projection");
    locations.triangleColor = gl.getUniformLocation(programId, "triangleColor");
}

// Pass an updated model-view matrix to the graphics card.
function updateModelView(modelView) {
    gl.uniformMatrix4fv(locations.modelView, false, flatten(modelView));
}

// Pass an updated projection matrix to the graphics card.
function updateProjection(projection) {
    gl.uniformMatrix4fv(locations.projection, false, flatten(projection));
}

function updateLight(newlightTransform){
    lightPosition = lightVec;
    gl.uniform4fv(locations.lightPosition, flatten(lightPosition));
    gl.uniformMatrix4fv(locations.lightTransform, false, flatten(newlightTransform));

}

// Pass an updated projection matrix to the graphics card.
function updateTriangleColor(triangleColor) {
    gl.uniform3fv(locations.triangleColor, triangleColor);
}


// Render the scene
function render() {
    // Clear the canvas
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    
    // Draw the triangle strips
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, trianglePointCount);
}
