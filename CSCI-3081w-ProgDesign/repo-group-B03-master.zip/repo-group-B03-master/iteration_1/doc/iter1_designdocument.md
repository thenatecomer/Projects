# Design Justifications for BrushWork
#### Group Name:
B03

#### Members:
- Cong Sun (Connor)
- Jonathan Lehne
- Nathan Comer
- Qing Yang

#### Instructions 
> Respond to each of the design questions below.  Make your answers factual and compelling.  Where appropriate, reference alternative designs you considered, code snippets, and diagrams within your writing in order to be clear and back up your claims.  As we have discussed in class, when writing with reference to figures make sure to tell the reader what to look for in the diagram or what exactly you want the reader to notice in the code snippet.  Remember that the design of your project is worth 1/3 of the total project grade.  Also remember that when grading the design portion of the project, this design justification document is the only thing we will look at.  This document must stand on its own.  Rather than linking to your actual code, carefully pick the most important code snippets from your project to include here in order to provide convincing detail for your answers to the questions below.


## 1  Design Question One
> This iteration of the project is all about tools. Naturally, a key design decision is how these tools are represented. Each tool has several characteristics, including the shape of the tool, its size, and the way it blends with the canvas when the tool is applied. Some tools share characteristics with other tools, such as how the pen and calligraphy pen tools blend with the canvas in the same manner. 
> First, in the **Design Description** section below, describe the design you developed to address this challenge. We expect that you will include at least one figure showing the relationships of the classes affected by your design. Second, in the **Design Justification** section below present the most compelling argument you can for why this design is justified.  Note that our expectation is that you will need to discuss the pros (and maybe cons) of your final design as compared to alternative designs that you discussed in your group in order to make a strong case for justifying your design.

### 1.1 Design Description
 As illustrated in the graph, the tool implementation included a parent Tool class with six child classes each specifies an individual tool. In the Tool class the protected class variables include a mask, which is a dynamically allocated two dimensional array used to store the opacity of each pixel within the mask, an integer variable for mask size, and an integer variable for tool ID. These protected variables are important for the child classes as they would use them to update and store the information about the mask based on each specific tool. In addition, the parent Tool class also includes function ApplyTool and SetColor to apply color to specific mask accordingly.
  
 UML Diagram for Tool and specific tool classes: 
![alt text](https://github.umn.edu/umn-csci-3081F16a/repo-group-B03/blob/ProjectFolderBranch/iteration_1/doc/designq1.png "Tool UML")

### 1.2 Design Justification
  On one hand, SetColor is used by the BrushWorkApp class to set current color in the Tool class. In the case of Eraser, only the SetColor function is overwritten, so that the current color is set to background color. The special tool also overwrites the SetColor function to generate random color everytime when the left mouse button is pressed. The randomization takes place by generating a random number between 0 to 1 and by mulplying the number to the current color. The SetColor incorporates not only the RGB data but also the current pixel buffer as the argument, so that the background color can be determined dynamically by using member function background_color() in the PixelBuffer class.

  On the other hand, ApplyTool takes in the coordinates on canvas, the pointer to current pixel buffer, and the background color as arguments. The generic ApplyTool function is designed to set current color to each pixel within the mask based on the mask design specified by each individual child class. The function makes full use of get_pixel and set_pixel functions to ensure that the color is well mixed and properly overlaid onto the existing color. And it also ensures that when the coordinate is close to the boundary of the canvas, the program would not attempt to get or set color to a pixel that’s out of boundaries. In the case of Highlighter, to mimic the behavior of the real highlighter, the color underneath has to be taken into account, so that the ApplyTool function is overwritten in the child class. The overwritten highlighter ApplyTool multiplies the luminance of the color that’s already on the canvas with the opacity specifies by the mask, so that the darker the color that is underneath, the lower the luminance, and the less color would be applied.

  Overall, the inheritance of variables and functions maximizes the efficiency of the program. The use of PixelBuffer pointer instead of a pixelbuffer, followed by dereferencing within the function, ensures minimal amount of data being passed during function calls. 

## 2  Design Question Two
> Unlike most of the tools, the Eraser returns the canvas to its original color. One of the challenges in this iteration is giving the eraser the authority or information required to have this effect while having minimal impact on the way the rest of the tools are defined. 
> First, in the **Design Description** section below, describe the design you developed to address this challenge.  Second, in the **Design Justification** section below present the most compelling argument you can for why this design is justified.  Note that our expectation is that you will need to discuss the pros (and maybe cons) of your final design as compared to alternative designs that you discussed in your group in order to make a strong case for justifying your design.

### 2.1 Design Description

We designed our Tool class so that the color is set seperately from applying the tool to the canvas. We accomplished this by having a class member variable of type ColorData in the tool class that is set with it's own method (SetColor). Then when the ApplyTool method is called it just applies the color specified by the color variable instead of having the color variable passed to it as an argument.

### 2.2 Design Justification

When designing our Tool class we had two designs for how to implement eraser. The first was to override the function that applies the tool to the canvas, thus allowing us to apply the background color. The second was to create a seperate method to set the color instead of setting the color in the apply tool function. We chose the second option being it made the tool class more versatile and allowed us to implement eraser without overriding one of the most complex methods in our tool class. It also took some of the complexity away from the apply tool function, and made the ApplyTool function's job more specific. This also helps with the applicability of future tools, for example if we wanted to implement a tool that changes color as it's being used, such as a rainbow effect, that tool can simply override the SetColor method instead of having to override the entire ApplyTool function. For our special tool we implemented a tool whose color is dependent upon real-world time, thus it takes advantage of the fact that it can override the SetColor method instead of the ApplyTool method. A third way of applying eraser would have been to handle the color selection in the BrushWorkApp class. We avoided this design because it would have added unnecessary complexity to the BrushWorkApp class. The BrushWorkApp class also contains already working code, thus we wanted to minimize what we added to it.

## 3  Design Question Three
> A new developer on your team must add a new tool to BrushWork. This tool is called  _Pencil._ This tool is a single, non-transparent pixel that completely replaces the existing colors on the canvas in the same way as the pen or calligraphy pen blend.  
> Describe in the form of a tutorial (including code snippets) exactly what changes would need to be made to your program in order to fully integrate this new tool.

### Programming Tutorial: Adding a New Pencil Tool to BrushWork

## Making pencil.cc and pencil.h
1. Make sure your new tool inherits from the Tool class
    -Study the class to understand architecture

2. The job of your class is to define what the mask will. 
   -This can be done by using the inherited member variable float** mask and defining how at each index how much you need the tool to affect the canvas using a float from the range of 0.0 to 1.0
     -0.0 is the weekest, and 1.0 is the strongest

3. Make pencil known to brushworkapp.h

   - Now that the class and header file are created, include the newtool.h into brushworkapp.h using the form 
    #include "../src/include/pencil.h"
4. Add a new GLUI_RadioButton() in BrushWorkApp::InitGlui(void)

Code Snippet
void BrushWorkApp::InitGlui(void) {

    GLUI_Panel *tool_panel = new GLUI_Panel(glui(), "Tool Type");
    GLUI_RadioGroup *radio = new GLUI_RadioGroup(tool_panel,
                                                 &cur_tool_,
                                                 UI_TOOLTYPE,
                                                 s_gluicallback);

    // Create interface buttons for different tools:
    new GLUI_RadioButton(radio, "Pen");
    new GLUI_RadioButton(radio, "Eraser");
    new GLUI_RadioButton(radio, "Spray Can");
    new GLUI_RadioButton(radio, "Caligraphy Pen");
    new GLUI_RadioButton(radio, "Highlighter");
    new GLUI_RadioButton(radio, "Checker");
    /*TODO: add new radio button for new tool example below*/
    new Glui_RadioButton(radio, "Pencil")
    
5. In void BrushWorkApp::Init add a the new tool object to the tools_array_ in the same order as the radio button was added
    -refference code snippet below

6. Adjust the amount of indecies in tools_array_ to match the amount of radio buttons there are for tools
    -In this example the Pencil Radio button was added 7th, the Pencil object must be the 7th entry (tool_array_[6])

Code Snippet from BrushWorkApp::Init(){

    tools_array_ = new Tool*[6](); /* this will need to change to tools_array_ = new Tool*[7]()*/
    // Initialize Tools

    tools_array_[0] = new Pen();
    tools_array_[1] = new Eraser();
    tools_array_[2] = new SprayCan();
    tools_array_[3] = new CalligraphyPen();
    tools_array_[4] = new Highlighter();
    tools_array_[5] = new Checker();
    /*TODO: add new tool to the array of tools, example below*/
    tools_array_[6] = new Pencil();
