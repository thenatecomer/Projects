/* Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
   Author: Qing Yang  */
#include <iostream>
#include <cmath>
#include "include/tool.h"
#include "include/highlighter.h"

#define OPACITY 0.4
namespace image_tools {

Highlighter::Highlighter() {
  SetMask(15);
}

void Highlighter::SetMask(int size) {
  mask_size_ = size;
  toolid_ = 4;

  mask = new float*[mask_size_];
  if (!mask) {
    fprintf(stderr, "Mask allocation error!");
    exit(EXIT_FAILURE);
  }

  for (int i = 0; i < mask_size_; i++) {
    if (!((mask[i] = new float[mask_size_]))) {
      fprintf(stderr, "Mask allocation error!");
      exit(EXIT_FAILURE);
    }
  }

  // 000001111100000 * 15 pixel in height 5 pixel wide
  for (int i = 0; i < mask_size_; i++) {
    for (int j = 0; j < mask_size_; j++) {
      if ((i > mask_size_/3 - 1) && (i < mask_size_ * 2 / 3)) {
        mask[i][j] = OPACITY;
        // set the mask to 40% opacity
      } else {
        mask[i][j] = 0.0;
      }
    }
  }
}

Highlighter::~Highlighter() {
  for (int i = 0; i < mask_size_; i++) {
    free(mask[i]);
  }
  free(mask);
}

void Highlighter::ApplyTool(int x, int y,
PixelBuffer *pixel, ColorData bg_color) {
  // Need to ensure the mask is within the canvas range
  int i, j, width, height, bufferX, bufferY, curX, curY;
  float intensity;
  ColorData tempColor;

  bufferX = x - (mask_size_/2) - 1;
  bufferY = y - (mask_size_/2) - 1;

  width = (*pixel).width();
  height = (*pixel).height();

  for (i = 0; i < mask_size_; i++) {
    for (j = 0; j <mask_size_; j++) {
      if ((i + bufferX > 0) && (j + bufferY > 0)
      && (i + bufferX < width) && (j + bufferY < height)
      && (i > mask_size_/3 - 1) && (i < mask_size_ * 2 / 3)) {
      // Extra steps to ensure the target pixel is within the canvas
        curX = i + bufferX;
        curY = height - j - bufferY;
        tempColor = (*pixel).get_pixel(curX, curY);
        intensity = mask[i][j] * tempColor.luminance();
        (*pixel).set_pixel(curX, curY,
        cur_color_ * intensity + tempColor * (1 - intensity));
      }
    }
  }
}
}  // namespace image_tools
