/* Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
   Author: Qing Yang, Nathan Comer, Jonathan Lehne  */
#include <iostream>
#include <cmath>
#include "include/tool.h"
#include "include/eraser.h"
namespace image_tools {

Eraser::Eraser() {
  SetMask(21);
}

void Eraser::SetMask(int size) {
  toolid_ = 1;
  // set eraser Tool ID to 1
  mask_size_ = size;

  mask = new float*[mask_size_];
  if (!mask) {
    fprintf(stderr, "Mask allocation error!");
    exit(EXIT_FAILURE);
  }

  for (int i = 0; i < mask_size_; i++) {
    if (!((mask[i] = new float[mask_size_]))) {
      fprintf(stderr, "Mask allocation error!");
      exit(EXIT_FAILURE);
    }
  }

  int r = mask_size_/2;
  // The center of the 2D array is [r,r], in C++: 21/2=10
  // Initialize a circle that's 21 pixel in diameter, i.e. r=10
  for (int i = 0; i < mask_size_; i++) {
    for (int j = 0; j < mask_size_; j++) {
      if (((i - r) * (i - r) + (j - r) * (j - r)) <= r*r) {
        mask[i][j] = 1.0;
      } else {
        mask[i][j] = 0.0;
      }
    }
  }
}

// Overwriting the SetColor function, instead of setting the color to
// tool color, set the color to background
void Eraser::SetColor(float r, float g, float b, PixelBuffer *canvas) {
  cur_color_ = (*canvas).background_color();
}

Eraser::~Eraser() {
  for (int i = 0; i < mask_size_; i++) {
    free(mask[i]);
  }
  free(mask);
}
}  // namespace image_tools
