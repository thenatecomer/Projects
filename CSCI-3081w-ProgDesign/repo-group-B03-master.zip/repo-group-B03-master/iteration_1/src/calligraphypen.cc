/* Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
   Author: Qing Yang  */
#include <iostream>
#include <cmath>
#include "include/tool.h"
#include "include/calligraphypen.h"
namespace image_tools {

CalligraphyPen::CalligraphyPen() {
  SetMask(15);
}

void CalligraphyPen::SetMask(int size) {
  toolid_ = 3;
  // set calligraphy pen Tool ID to 3
  mask_size_ = size;

  mask = new float*[mask_size_];
  if (!mask) {
    fprintf(stderr, "Mask allocation error!");
    exit(EXIT_FAILURE);
  }

  for (int i = 0; i < mask_size_; i++) {
    if (!((mask[i] = new float[mask_size_]))) {
      fprintf(stderr, "Mask allocation error!");
      exit(EXIT_FAILURE);
    }
  }

  for (int i = 0; i < mask_size_; i++) {
    for (int j = 0; j < mask_size_; j++) {
    if ((i > mask_size_/3 - 1) && (i < mask_size_ * 2 / 3)) {
        mask[i][j] = 1.0;
      } else {
        mask[i][j] = 0.0;
      }
    }
  }
}

CalligraphyPen::~CalligraphyPen() {
  for (int i = 0; i < mask_size_; i++) {
    free(mask[i]);
  }
  free(mask);
}
}  // namespace image_tools
