/* Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
   Author: Nathan Comer, Qing Yang  */
#include <cmath>
#include <iostream>
#include "include/brushwork_app.h"
#include "include/tool.h"

using std::cout;
using std::endl;
namespace image_tools {
// I think that we want to put all of this in a Tool class?
// Need to declare and initialize px, py,

/*Default constructor to allocate mask*/
Tool::Tool() {
  int i, j;

  mask_size_ = MASK_SIZE;
  mask = new float*[mask_size_];
  if (!mask) {
    fprintf(stderr, "Mask allocation error!");
    exit(EXIT_FAILURE);
  }

  for (int i = 0; i < mask_size_; i++) {
    if (!((mask[i] = new float[mask_size_]))) {
      fprintf(stderr, "Mask allocation error!");
      exit(EXIT_FAILURE);
    }
  }

  for (i = 0; i < mask_size_; i++) {
    for (j = 0; j < mask_size_; j++) {
      mask[i][j]= 0.0;
    }
  }
  previous_x_ = 0;
  previous_y_ = 0;
}


float** Tool::GetMask() {
  return mask;
}

/* Following constructor is for furture iterations
 * It allows initialize a tool with specified size
Tool::Tool(int size) {
  mask_size_ = size;
  mask = (float**)malloc(mask_size_ * sizeof(float*));
  int i, j;

  if (!mask) {
    fprintf(stderr, "Mask allocation error!");
    exit(EXIT_FAILURE);
  }

  for (i = 0; i < mask_size_; i++) {
    if (!((mask[i] = (float*)malloc(mask_size_ * sizeof (float))))) {
      fprintf(stderr, "Mask allocation error!");
      exit(EXIT_FAILURE);
    }
  }

  for (i = 0; i < mask_size_; i++) {
    for (j = 0; j < MASK_SIZE; j++) {
      mask[i][j] = 0.0;
    }
  }

  previous_x_ = 0;
  previous_y_ = 0;
  mask_size_ = MASK_SIZE;
}
*/


void Tool::ApplyTool(int x, int y, PixelBuffer *pixel, ColorData bg_color) {
  // Use pointer array of pixel to improve efficiency
  // Need to ensure the mask is within the canvas range
  // std::cout << "APPLY TOOL PRINT: " << x << " " << y << std::endl;
  int i, j,  bufferX, bufferY, curX, curY;
  ColorData tempColor;

  bufferX = x - (mask_size_/2) - 1;
  bufferY = y - (mask_size_/2) - 1;

  int const width = (*pixel).width();
  int const height = (*pixel).height();

  // std::cout << "APPLY TOOL PRINT: " << width << " " << height << std::endl;
  // SetColor(0.5,0.5,0.5);
  // (*pixel).set_pixel(x,y,cur_color_);

  for (i = 0; i < mask_size_; i++) {
    for (j = 0; j <mask_size_; j++) {
      if ((i + bufferX > 0) && (j + bufferY > 0)
      && (i + bufferX < width) && (j + bufferY < height)) {
        curX = bufferX + i;
        curY = height - bufferY - j;
        tempColor = (*pixel).get_pixel(curX, curY) * (1 - mask[i][j]);
        (*pixel).set_pixel(curX, curY, tempColor + cur_color_ * mask[i][j]);
      }
    }
  }
}

void Tool::SetColor(float r, float g, float b, PixelBuffer *canvas) {
  cur_color_.red(r);
  cur_color_.green(g);
  cur_color_.blue(b);
}

// void Tool::ScaleMask (float scaleX, float scaleY);
// Will be implemented for iteration 2.
// Delete the previous the mask, scale the new one based on the original

void Tool::Interpolate(int x, int y, PixelBuffer *pixel, ColorData bg_color) {
  int iterate_index;
  double iterate_x, iterate_y, diff_x, diff_y,
         length, iterate, x_accumulator, y_accumulator;

  diff_x = x-previous_x_;
  diff_y = y-previous_y_;

  length = sqrt(pow(diff_x, 2) + pow(diff_y, 2));

  x_accumulator = previous_x_;
  y_accumulator = previous_y_;
  StoreDragEvent(x, y);

  if (length > mask_size_/4) {
    iterate = (6*length)/mask_size_;
    iterate_x = diff_x/iterate;
    iterate_y = diff_y/iterate;
    for (iterate_index = 0; iterate_index < iterate-1; iterate_index += 1) {
      x_accumulator += iterate_x;
      y_accumulator += iterate_y;
      ApplyTool(static_cast<int> (x_accumulator),
      static_cast<int> (y_accumulator), pixel, bg_color);
    }
  }
}

void Tool::StoreDragEvent(int x, int y) {
  previous_x_ = x;
  previous_y_ = y;
}

}  // namespace image_tools
