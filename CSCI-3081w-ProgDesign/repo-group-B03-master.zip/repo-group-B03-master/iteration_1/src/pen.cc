/* Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
   Author: Qing Yang, Cong Sun (Connor)  */
#include <iostream>
#include <cmath>
#include "include/tool.h"
#include "include/pen.h"
namespace image_tools {

Pen::Pen() {
  SetMask(3);
}

void Pen::SetMask(int size) {
  mask_size_ = size;
  toolid_ = 0;
  int r = mask_size_/2;

  mask = new float*[mask_size_];
  if (!mask) {
    fprintf(stderr, "Mask allocation error!");
    exit(EXIT_FAILURE);
  }

  for (int i = 0; i < mask_size_; i++) {
    if (!((mask[i] = new float[mask_size_]))) {
      fprintf(stderr, "Mask allocation error!");
      exit(EXIT_FAILURE);
    }
  }

  // 010 fill in when distance < radius
  // 111 distance = sqrt((i-r)^2 + (j-r)^2)
  // 010
  for (int i = 0; i < mask_size_; i++) {
    for (int j = 0; j < mask_size_; j++) {
      if (((i - r) * (i - r) + (j - r) * (j - r)) <= r*r) {
        mask[i][j] = 1.0;
      } else {
        mask[i][j] = 0.0;
      }
    }
  }
}

Pen::~Pen() {
  for (int i = 0; i < mask_size_; i++) {
    free(mask[i]);
  }
  free(mask);
}
}  // namespace image_tools
