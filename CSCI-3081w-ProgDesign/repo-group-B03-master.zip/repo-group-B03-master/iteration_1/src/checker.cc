// Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
// Author: Cong Sun (Connor), Qing Yang

#include "include/checker.h"
#include <stdlib.h>
#include <ctime>
#include <cmath>
#include <random>
#include <iostream>
#include "include/tool.h"

namespace image_tools {

Checker::Checker() {
  SetMask(9);
}

void Checker::SetMask(int size) {
  mask_size_ = size;
  toolid_ = 5;
  int oneThirdMask = mask_size_/3;

  mask = new float*[mask_size_];
  if (!mask) {
    fprintf(stderr, "Mask allocation error!");
    exit(EXIT_FAILURE);
  }

  for (int i = 0; i < mask_size_; i++) {
    if (!((mask[i] = new float[mask_size_]))) {
      fprintf(stderr, "Mask allocation error!");
      exit(EXIT_FAILURE);
    }
  }

  // fill in whole mask first
  for (int i = 0; i < mask_size_; i++) {
    for (int j = 0; j < mask_size_; j++) {
        mask[i][j] = 1.0;
    }
  }
  for (int i = 0; i < oneThirdMask; i++) {
    // set  1/3 left top square to blink
    for (int j = 0; j < oneThirdMask; j++) {
        mask[i][j] = 0.0;
    }
    // set 1/3 right top squre to blink
    for (int j = 2 * oneThirdMask; j < mask_size_; j++) {
        mask[i][j] = 0.0;
    }
  }
  for (int i = 2 * oneThirdMask; i < mask_size_; i++) {
    // set 1/3 left down square to blink
    for (int j = 0; j < oneThirdMask; j++) {
        mask[i][j] = 0.0;
    }
    // set 1/3 right down square to blink
    for (int j = 2 * oneThirdMask; j < mask_size_; j++) {
        mask[i][j] = 0.0;
    }
  }
}

void Checker::SetColor(float r, float g, float b, PixelBuffer *canvas) {
  std::mt19937 gen(std::time(nullptr));
  std::uniform_int_distribution<int> dist(1, 100);
  cur_color_.red(static_cast<float> (dist(gen) / 100.0));
  cur_color_.green(static_cast<float> (dist(gen) / 100.0));
  cur_color_.blue(static_cast<float> (dist(gen) / 100.0));
}

Checker::~Checker() {
  for (int i = 0; i < mask_size_; i++) {
    free(mask[i]);
  }
  free(mask);
}
}  // namespace image_tools
