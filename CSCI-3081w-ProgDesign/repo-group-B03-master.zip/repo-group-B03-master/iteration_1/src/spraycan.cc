/* Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
   Author: Qing Yang, Cong Sun (Connor)  */
#include <iostream>
#include <cmath>
#include "include/tool.h"
#include "include/spraycan.h"

#define OPACITY 0.2
namespace image_tools {

SprayCan::SprayCan() {
  SetMask(20);
}

void SprayCan::SetMask(int size) {
  mask_size_ = size;
  toolid_ = 2;

  int r = mask_size_/2;
  double distance = 0;

  mask = new float*[mask_size_];
  if (!mask) {
    fprintf(stderr, "Mask allocation error!");
    exit(EXIT_FAILURE);
  }
  for (int i = 0; i < mask_size_; i++) {
    if (!((mask[i] = new float[mask_size_]))) {
      fprintf(stderr, "Mask allocation error!");
      exit(EXIT_FAILURE);
    }
  }

  for (int i = 0; i < mask_size_; i++) {
    for (int j = 0; j < mask_size_; j++) {
      // same idea as pen with different radius
      distance = sqrt((i - r) * (i - r) + (j - r) * (j - r));
      if (distance <= r) {
        // gradually fade, based on distance to the center
        mask[i][j]= OPACITY - OPACITY * distance / r;
      } else {
        mask[i][j] = 0.0;
      }
    }
  }
}

SprayCan::~SprayCan() {
  for (int i = 0; i < mask_size_; i++) {
    free(mask[i]);
  }
  free(mask);
}
}  // namespace image_tools
