/* Copyright CSCI 3081W Fall 2016 Group Bo3 All rights reserved
   Author: Qing Yang, Cong Sun (Connor)  */
#ifndef ITERATION_1_SRC_INCLUDE_ERASER_H_
#define ITERATION_1_SRC_INCLUDE_ERASER_H_
#include "../src/include/tool.h"
#include "../src/include/color_data.h"
#include "../src/include/pixel_buffer.h"
namespace image_tools {

class Eraser: public Tool {
 public:
  Eraser();
  virtual ~Eraser();
  void SetMask(int size);

  virtual void SetColor(float r, float g, float b, PixelBuffer *canvas);
};
}  // namespace image_tools
#endif  // ITERATION_1_SRC_INCLUDE_ERASER_H_
