/* Copyright CSCI 3081W Fall 2016 Group Bo3 All rights reserved
   Author: Qing Yang, Cong Sun (Connor)  */
#ifndef ITERATION_1_SRC_INCLUDE_PEN_H_
#define ITERATION_1_SRC_INCLUDE_PEN_H_
#include "../src/include/tool.h"
namespace image_tools {

class Pen: public Tool {
 public:
  Pen();
  virtual ~Pen();
  void SetMask(int size);
};
}

#endif  // ITERATION_1_SRC_INCLUDE_PEN_H_
