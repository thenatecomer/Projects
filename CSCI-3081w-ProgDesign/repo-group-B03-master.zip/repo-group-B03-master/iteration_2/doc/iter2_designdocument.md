# Design Justifications for FlashPhoto
#### Group Name:
B03

#### Members:
- Connor Sun
- Jonathan Lehne
- Nathan Comer
- Qing Yang

#### Instructions 
> Respond to each of the design questions below.  Make your answers factual and compelling.  Where appropriate, reference alternative designs you considered, code snippets, and diagrams within your writing in order to be clear and back up your claims.  As we have discussed in class, when writing with reference to figures make sure to tell the reader what to look for in the diagram or what exactly you want the reader to notice in the code snippet.  Remember that the design of your project is worth 1/3 of the total project grade.  Also remember that when grading the design portion of the project, this design justification document is the only thing we will look at.  This document must stand on itsd own.  Rather than linking to your actual code, carefully pick the most important code snippets from your project to include here in order to provide convincing detail for your answers to the questions below.  
> A few tips to maximize the success of your design document:  
>   1. Make sure the **description** of your design decision only contains an objective description of how you structured your design and how it was implemented (specifically how your solution solves the problem given in the prompt). Save any arguments in favor of your design for the **justification** section.
>
>   2. Your justification will probably need to compare against at least one alternative, and you will need to provide a compelling argument for why your solution is better than the alternative.
>
>   3. Edit this file when writing your design document. Do not move or rename this file. Do not direct to any outside resources for your images or code. Place all images and code in this document. Please match the formatting of the [Example Design Document](https://github.umn.edu/umn-csci-3081F16/Example-Design-Document/blob/master/doc/DesignDocument.md) and [its source](https://raw.github.umn.edu/umn-csci-3081F16/Example-Design-Document/master/doc/DesignDocument.md?token=AAADyd5L8wd57F_qLX4Nf-2nVvfRlMj5ks5YH-qHwA%3D%3D) as precisely as possible, especially in regards to:
>     - **Formatting code** (do not include images of your code, make sure that your code is formatted with C++ coloring)
>     - **Inserting images**
>     - **Numbered lists for your tutorial**
>     - **Captioning your Figures**
>     - **Including the original prompts in their original quote form**  
> 
>  This formatting helps us grade your assignments effectively, and thus failure to meet these requirements may result in point deductions. Any material that is not presented in this design document will not be graded.
>   4. When including a class diagram, only show the classes and members that convey the point you're trying to make. For example, showing the class BaseGfxApp in a UML diagram will probably not be appropriate.





## 1  Design Question One
> This iteration of the project introduces the concept of filters. You had to implement several filters, which fell into two types: pixel-independent (where each pixel is filtered independently), and convolution-based (where filtering a pixel requires information about its neighboring pixels by means of a kernel). Naturally, a key design decision is how these filters are represented. Each filter has a different algorithm for modifying the canvas, and only some of these algorithms require kernels. 
> First, in the **Design Description** section below, describe the design you developed to address this challenge. We expect that you will include at least one figure showing the relationships of the classes affected by your design. Second, in the **Design Justification** section below present the most compelling argument you can for why this design is justified.  Note that our expectation is that you will need to discuss the pros (and maybe cons) of your final design as compared to alternative designs that you discussed in your group in order to make a strong case for justifying your design.

### 1.1 Design Description
![undo redo uml](https://github.umn.edu/umn-csci-3081F16a/repo-group-B03/blob/master/iteration_2/doc/Filter_UML.png)

**We made four major design decisions for filters:**

**1. Encapsulating Effects**

Our design for filters uses the strategy design method to encapsulate the components that make up the filters. The most important part of the convultion-based filters are their kernels thus we encapsulated all of the kernel generation code together in the FilterKernel class. The most important component of pixel-independent filters are the equations that modify the ColorData so we encapsulated all of these equations together in the FilterEffects class. Then in the filter factory class the kernel and/or pixel-independent effect that a filter uses are linked to that filter instance.

**2. Handling Arguments**

![undo redo uml](https://github.umn.edu/umn-csci-3081F16a/repo-group-B03/blob/master/iteration_2/doc/Arguments_UML.png)

We choose to handle arguments using a struct so we could pass them around allowing effects and kernels to use whatever arguments they neeeded. We also realized that passing around all the arguments for all the effects and kernels was excessive being only one kernel could be applied at a time. Thus we decided to utulize argument generalization, we categorized similar arguments from different filters into one single argument inside the struct. So kernels and effects can choose which of the arguments inside of the struct best suit the type of argument that is being used. For example, there is an argument glui_value which is used by all of the current filters to indicate the intensity of the effect that should be applied.

**3. General ApplyFilter Function**

We decided to create a versatile ApplyFilter method that is capable of applying any of the filters. All of the convulution filters use kernels that can be applied the same way, and all of the pixel-independent filters have their effects encapsulated in methods that take in ColorData and return ColorData. Thus it was the obvious choice to use one ApplyFilter method that applies the kernel, the effect, or both. We decided to allow filters to use both a kernel and pixel-indepdent effect together simulaneously. This is demonstrated by our special filter which applies the Emboss effect, which uses a kernel, and the inverse effect, which uses a pixel-indepdent effect.

**4. Filter Factory for Creating Filters**

Being the components of the filters are easily interchangable we were able to use a factory to easily create the filters in a manner that is versatile and easily extensible. Inside of the filter factory each filter starts with an instance of the filter class, then selects which kernel it wants to use, and which pixel-independent effect is used. This allows effects and kernels to be easily added to our existing code from one isolated file. Thus limited the possibiltiy of new code effecting existing code.

### 1.2 Design Justification
**1. Encapsulating Effects**

We believe that encapulating similar effects is the best approach to implementing the filters in this iteration. For starters this design is easy to understand, if someone wanted to go in an change an effect it's easy for them to find and modify an effect or kernel without having to wade through dozens of lines of code to find the effect that want to modify. An important aspect our design is that it provides a lot of abstraction, it hides the details that are not important, such as how the kernel is or effect is applied to each pixel. Users can add new effects and kernels without ever thinking about how they're applied on a lower level. This also protects all of the vital code in the filter class, and allows people to add effects and kernels to the existing code without risk to the code inside of the filter class. It also makes it easy to add an entirely new category of effect by adding a new encapsulation class to store the new effects, then adding a line of code into the ApplyFilter function to call the needed effect function.

``` cpp
ColorData FilterEffects::ThresholdEffect(ColorData color, glui_arguments* filter_arguments) {
  color.red(color.red() > (*filter_arguments).glui_value ? 1.0 : 0.0);
  color.green(color.green() > (*filter_arguments).glui_value ? 1.0 : 0.0);
  color.blue(color.blue() > (*filter_arguments).glui_value ? 1.0 : 0.0);
  return color;
}
```
Effects are concisely encapsulated inside of a method that is easy to modify and understand.

``` cpp
case 8:  /// FILTER_SPECIAL:
  (*filter).SetEffect(FilterEffects::GetEffect(8));  // Sets Inverse Effect
  (*filter).SetKernel(4);  // Sets Emboss kernel
  break;
```
The use of encapsulation and a filter factory makes it easy to mix and match different effects, such as our special filter which applies the Emboss, and Inverse effects.

Another design we considered was inheritance, creating an abstract base filter class and making each filter a sub-class. This seemed inappropriate for filters given that it would make it difficult to add new filters without fully understanding the existing code. Also The only differences between the classes would be the kernels and pixel-independent effects. Our design is more extensible than inheritance because you can easily add a new effect, kernel, or both without making a new class or having to worry about which methods you need to inherit or override.

**2. Handling Arguments**

Handling arguments with a struct is extremely versatile and extensible. If an argument is needed that's not already present it can simply be added to the struct than used wherever it's needed. Using a struct that generalizes arguments is also beneficial because it prevents an argument explosion. If dozens of filters were added and they were generalized into only a small number of arguments it would be impossible to keep track of them all.

``` cpp
  void Filter::ApplyFilter(PixelBuffer* pixel, glui_arguments* glui_arg) {
```
All of the arguments are passed between functions in a structure using a pointer, making them easy to keep track of and access.

Another design we considered to handle arguments was to pass individual arguments to each individual filter, this would have been less versatile especially considering the similarities between many of the arguments used by the filters. This also hurts the versatility of the method that would apply the effect to the canvas because it's arguments would be dependent upon the arguments needed by the effect. So if you wanted to add an argument to an effect, you would also have to change every method between the FlashPhoto class and the ApplyFilter function.

**3. General ApplyFilter Function**

Being all of the convultion-filters can be applied in a similar manner there was no need to create a different ApplyFilter method for each filter. One of the benefits of doing filters in this manner is that it's extremely easy to add new filters and modify existing filters, it also provides a lot of versatility and is easily extensible, for example with only a few lines of code you could allow filters to apply multiple effects, or even add in an entirely new kind of effect, different from both convulution based filters and pixel-independent filters. An example of the versatility of our design is our special tool, which without any additional code except for the emboss kernel generation and inverse effect outlined below is capable of applying both the inverse effect outlined in design question 3 and apply the emboss effect efficiently and simultaneously allowing for an Inverse-Emboss filter.

Another design we considered was giving each filter it's own ApplyFilter method and coding the desired effects into each apply function. This design is hard to extend because to change the effect of a filter you would have to rewrite most of the ApplyFilter function for that filter. It also has no abstraction, anyone who wants to modify the effect of a kernel will have to fully understand how the entire filter works in order to effectively add to or modify it.

**4. Filter Factory for Creating Filters**

Using a filter factory to create the filters makes it easy to see which pixel-independent effects and kernels are linked to which filters, and also makes it easy to change which effects are linked to which filters. If you wanted to change the Edge Detection filter so it also applied an Inverse effect to the canvas you would only have to link the Inverse effect to the Edge Detection filter, which requires only one line of code to be changed, instead of having to write most of the ApplyFilter method for that filter.

``` cpp
case 0:  /// FILTER_BLUR:
  (*filter).SetEffect(FilterEffects::GetEffect());
  (*filter).SetKernel(0);
  break;
  // more entries below
```
Each effect has a short easy to understand entry in the filter factory where it's pixel-independent effect and kernel are set.

Using inheritance instead of encapsulation for effects would have provided an alternative to the filter factory that we used. But, this makes it difficult to see which filters apply which effects, especially if dozens of filters were added to the program, whereas a filter factory provides a concise summary of how each filter works.



## 2  Design Question Two
> One common software feature included in this iteration is the undo/redo mechanic, where any modification to the canvas can be reversed, and then optionally re-applied. 
> First, in the **Design Description** section below, describe the design you developed to address this challenge.  Second, in the **Design Justification** section below present the most compelling argument you can for why this design is justified.  Note that our expectation is that you will need to discuss the pros (and maybe cons) of your final design as compared to alternative designs that you discussed in your group in order to make a strong case for justifying your design.

### 2.1 Design Description
Undo/Redo has been implemented through inheritance of an abstract class StateImplementation. This use of inheritance allows StateManager to have a StateImplementation pointer that can be initialized as a child of the StateImplementation parent class. Each child must have the 3 basic operations of adding a previous state, retrieving a previous state, and retrieving a previously undone state before a new state is added. Provided is a UML diagram to illustrate.

![undo redo uml](https://github.umn.edu/umn-csci-3081F16a/repo-group-B03/blob/master/iteration_2/doc/undo-redo_uml.png)

Changes that were made to implement this solution into FlashPhotoApp.
 1. Adding state_manager_.AddOperation() to undoable operations such as
   I) Filter applications (in FlashPhotoApp)
  II) After one continuous Tool application i.e. when the left mouse up callback function is activated
 2. Destruction and creation of the state_manager_'s state_impl_ object when a new image is loaded to the canvas
 3. Adding

Changes that were made to the StateManager class
 1. The undo_toggle and redo_toggle are now always set to true, and the return value is handled by the StateImplementation class
 2. Function suite for StateManager that use the StateImplementation object pointer.

```cpp
void StateManager::UndoOperation(PixelBuffer* display_buf) {
  state_impl_->get_previous_state(display_buf);
}

void StateManager::RedoOperation(PixelBuffer* display_buf) {
  state_impl_->get_previous_undo(display_buf);
}

void StateManager::AddOperation(PixelBuffer* display_buf){
  state_impl_->add_previous_state(display_buf);
}
void StateManager::InitStateHolder(PixelBuffer* display_buf){
  state_impl_->InitState(display_buf);
}
```

### 2.2 Design Justification

The main justification for this design decision is it allows for easy integration of new ways to implement an undo/redo structure. Currently a "stack" is used to hold the previous states in the user's local memory, but perhaps in the future a new implementation one may want to add a cloud based implementation. This keeps the class explosion in the Children of the StateImplementation. Each Class can make its own data structure, and how it interacts with that data structure keeping the StateManager agnostic to these changes. 

The framework for:
 1. adding to,
 2. (undo) retreiving a previous state from,
 3. (redo) retreiving a previously undone state before a new state is added to,

the StateImplementation object has already been integrated into the FlashPhotoApp and StateManager. This makes integrating a newly created implementation trivial. In the state_manager.h file one would change the include line from

 ```cpp
 #../src/include/state_current_implementation.h
 ```

to

 ```cpp
 #../src/include/state_new_implementation.h
 ```

In the state_manager.cc file one would change the constructor to

  ```cpp
  StateManager::StateManager(void) :
      undo_btn_(nullptr),
      redo_btn_(nullptr),
      state_impl_(nullptr){
    /// Change new implementation here
    state_impl_ = new NewStateImplementation(50);
  }
  ```

So long as the class NewStateImplementation class was created following the inheritance design correctly these are the only necessary changes to already working code.

Strategy design is not a suitable design solution for this problem since algorithms in this case are specific to the data structure it is working on. For example, a heap has a vastly different way of popping, than the way a stack pops off the top of the stack. Keeping these algorithms local to their classes and not having the possibility for a future developer to mix and match reduces risk in the future.

## 3  Design Question Three
> A new developer on your team must add a new filter to FlashPhoto. This filter is called  _Invert._ This filter performs the following conversion to all pixels in the canvas:
> ```
> newColor's red   = 1 - oldColor's red
> newColor's green = 1 - oldColor's green
> newColor's blue  = 1 - oldColor's blue
> ```
> Describe in the form of a tutorial (including code snippets) exactly what changes would need to be made to your program in order to fully integrate this new filter.

### Programming Tutorial: Adding a New Invert Filter to FlashPhoto
GENERAL OUTLINE FOR ADDING:


1. Typically, there are three components to be added to allow the new filter to function properly: a new filter member, a new effect method, and/or a new filter kernel. However, for Invert filter, the filter is a pixel-indepdent effect so there is no need to set a kernel. To add the filter member, first go to filter_factory.cc. Inside of the FilterFactory::CreateFilter function, add an additional switch case as illustrated in the code snippet below:

  ```cpp
  switch (filter_id) {
    // ... Previous 8 other filter cases
    case 9:  // FILTER_INVERT:
      (*filter).SetKernel(9);
      break;
    // ... Default case
  }
  ```

2. After adding the filter to the filter factory, the next step would be adding the new filter effect. To add the filter effect, go to filter_effects.cc and make two changes:

  a. The invert filter will take the ColorData at every single pixel and perform the inversion by substracting 1 by the current color number devided in Red, Blue, and Green. For implementation, add the following function to FilterEffects (filter_effects.cc) class encapsulation. (Don't forget to update the header file!):

    ```cpp
      ColorData FilterEffects::InvertEffect(ColorData color, glui_arguments* filter_arguments){
        color.red(1 - color.red());
        color.green(1 - color.green());
        color.blue(1 - color.blue());
        return color;
      }
    ```
  b. Update the switch case inside of the FilterEffects::GetEffect function. The added case should be added in following fashion:

    ```cpp
    switch(effect_id) {
      // ... Previous 8 cases
      case 9:  // Invert effect
          std::cout << "initializing invert effect" << std::endl;
          return FilterEffects::InvertEffect;
          break;
      // ... Default case
    }
    ```

3. As mentioned above, the Invert filter will not be using a filter kernel so no changes are needed inside of the filter_kernel.cc. In the case of adding an additional filter that utilizes its own special kernel, simply go to filter_kernel.cc, add a kernel, add a switch case to return that kernel function, and update the header file.

4. After adding the three components for the filter. The following steps are required to make the program aware of the additional filter, and to make the components aware of each other. It is important to link the new filter to correct filter kernel and filter effect, as new filters can use any combination of new or existing kernels/effects. To link the filter to its effect and kernel, go to filter_factory.cc again, and add case 9 inside of the FilterFactory::CreateFilter implementation as following:

  ```cpp
  switch (filter_id) {
    // ... Previous 8 filter cases
    case 9:  /// INVERT_FILTER:
    (*filter).SetEffect(FilterEffects::GetEffect(9)); // Set the effect of the invert filter to be the case 9 of special effect
    (*filter).SetKernel(); // This is not needed being the invert effect doesn't need a kernel but is here for demonstration purposes
    break;
    // ... Default case
  }
  ```
Note that the GetEffect function has called the special filter effect for invert, assigned as number 9. In this effect function, the color is inverted. On the other hand, being no kernel is needed for this effect, one does not need to be set. For clear organization, all of the filter id, kernel id and effect id are matched, even though some of the effect/kernel ids do not name a corresponding special effect/kernel as the filter uses the default effect/kernel.

5. Finally to make this new filter show up in the user interface, there are a few additional steps:

  a. Add the filter function to filter manager to make it aware of the new filter. To do this go to filter_manager.cc and add the following function (don't forget to update header file):

  ```cpp
  void FilterManager::ApplyInvert(PixelBuffer* pixel) {
    Filter* filter = filters_.at(9);
    SetArgumentsValue(1.0);  // The argument value is not important in this case
    SetArgumentsSize(1);
    (*filter).ApplyFilter(pixel, FilterManager::filter_arguments_);
  }
  ```  

  b. Also inside of the function InitGlui in the filter_manager.cc, add the following settings for initialize the UI buttons. As the invert filter is designed to perform single-step operation, no other UI parameter setting area is needed, just the apply filter button.

  ```cpp
  GLUI_Panel *InvertFilterPanel = new GLUI_Panel(filter_panel,
                                                  "Invert Filter");
  {
    new GLUI_Button(specialFilterPanel,
                    "Apply",
                    UICtrl::UI_APPLY_INVERT_FILTER,
                    s_gluicallback);
                  }
  }
  ```

  c. To make the application aware of the new filter and what to do when that button is clicked, go to flashphoto_app.cc, and inside the switch condition of the function FlashPhotoApp::GluiControl, add a new switch case as following:

  ```cpp
  switch (control_id) {
    // ... Other switch cases
    case UICtrl::UI_INVERT_FILTER:
    filter_manager_.ApplyInvert(display_buffer_);  // This calls the filter manager function ApplyInvert
    state_manager_.AddOperation(display_buffer_);  // This is necessary for undo and redo function
    break;
    // ... Other switch cases
  }
  ```

  d. Last but not least, this UI variable name would not become aware of the rest of the classes related to filter unless we update the ui_ctrl.h. Inside of the enum type add the corresponding variable name:

  ```cpp
  enum Type {
    // ... other UI types
    UI_APPLY_INVERT_FILTER,
    // ... other UI types
  };
  ```
And this concludes the step-by-step guide for adding a new filter to the existing FlashPhoto App!

### Instructions for library configuration
(Start in ../iteration_2/ directory)
FIRST make sure you have done
     module unload soft/gcc
 1. cd to ext folder
     $ cd ext
 2. type 'pwd' (without quotes) into command line, and copy the result
     $ pwd
 3. Now go to ../iteration_2/config directory
     $ cd ../config
 4. Give yourself permision to use configure and install using
     $ chmod 0700 configure
     $ chmod 0700 install.sh
 5. type './configure --enable-shared=no --prefix='<step 2 result>/lib''
     NOTE - the additional /lib added, this must be done to work with the makefile
 6. Now you should be setup to run 'make' on the command line
     $ cd ..
     $ make
