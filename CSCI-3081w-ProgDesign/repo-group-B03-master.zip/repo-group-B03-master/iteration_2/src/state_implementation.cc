/*******************************************************************************
 * Name            : state_implementation.cc
 * Project         : FlashPhoto
 * Module          : state_manager
 * Description     : Abstract state implementation
 * Copyright       : 2016 CSCI3081W GROUP B03. All rights reserved.
 * Creation Date   : 11/13/2016
 * Original Author : Jonathan Lehne
 *
 ******************************************************************************/

/*******************************************************************************
 * Includes
 ******************************************************************************/
#include "../src/include/state_implementation.h"
#include <iostream>
namespace image_tools {

/*******************************************************************************
 * Constructors/Destructor
 ******************************************************************************/

StateImplementation::StateImplementation(void) {}
StateImplementation::~StateImplementation(void) {}

/*******************************************************************************
 * Member Functions
 ******************************************************************************/
}  // namespace image_tools
