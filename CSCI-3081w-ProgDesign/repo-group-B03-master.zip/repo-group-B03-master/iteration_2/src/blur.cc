/* Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
   Author: Qing Yang  */
#include "../src/include/blur.h"
#include <iostream>
#include <cmath>
#include "../src/include/tool.h"

#define OPACITY 0.0025
namespace image_tools {

Blur::Blur() {
  SetMask(20);
}

void Blur::SetMask(int size) {
  mask_size_ = size;
  toolid_ = 2;

  int r = mask_size_/2;
  double distance = 0;

  mask = new float*[mask_size_];
  if (!mask) {
    fprintf(stderr, "Mask allocation error!");
    exit(EXIT_FAILURE);
  }
  for (int i = 0; i < mask_size_; i++) {
    if (!((mask[i] = new float[mask_size_]))) {
      fprintf(stderr, "Mask allocation error!");
      exit(EXIT_FAILURE);
    }
  }

  for (int i = 0; i < mask_size_; i++) {
    for (int j = 0; j < mask_size_; j++) {
      // same idea as pen with different radius
      distance = sqrt((i - r) * (i - r) + (j - r) * (j - r));
      if (distance <= r) {
        // gradually fade, based on distance to the center
        mask[i][j]= 0.5 - 0.5 * distance / r;
      } else {
        mask[i][j] = 0.0;
      }
    }
  }
}

Blur::~Blur() {
  for (int i = 0; i < mask_size_; i++) {
    free(mask[i]);
  }
  free(mask);
}


void Blur::ApplyTool(int x, int y,
PixelBuffer *pixel, ColorData bg_color) {
  // Need to ensure the mask is within the canvas range
  int i, j, width, height, bufferX, bufferY, curX, curY, maskX, maskY,
    curmaskX, curmaskY;
  float intensity;
  ColorData tempColor;

  bufferX = x - (mask_size_/2) - 1;
  bufferY = y - (mask_size_/2) - 1;

  width = (*pixel).width();
  height = (*pixel).height();

  for (i = 0; i < mask_size_; i++) {
    for (j = 0; j <mask_size_; j++) {
      curX = i + bufferX;
      curY = height - j - bufferY;
      if ((curX > -1) && (curY > -1)
      && (curX < width) && (curY < height)) {
        tempColor = (*pixel).get_pixel(curX, curY);

        for (maskX = 0; maskX < mask_size_; maskX++) {
          for (maskY = 0; maskY < mask_size_; maskY++) {
            curmaskX = curX - mask_size_/2 - 1 + maskX;
            curmaskY = curY - mask_size_/2 - 1 + maskY;
            if ((curmaskX > -1) && (curmaskX < width)
            && (curmaskY > -1) && (curmaskY < height)) {
              tempColor = tempColor +
              (*pixel).get_pixel(curmaskX, curmaskY) * OPACITY;
            }
          }
        }
        intensity = mask[i][j] * ((*pixel).get_pixel(curX, curY)).luminance();
        tempColor = (*pixel).get_pixel(curX, curY) * (1 - intensity)
        +(tempColor - (*pixel).get_pixel(curX, curY)) * intensity;
        (*pixel).set_pixel(curX, curY, tempColor);
      }
    }
  }
}
}  // namespace image_tools
