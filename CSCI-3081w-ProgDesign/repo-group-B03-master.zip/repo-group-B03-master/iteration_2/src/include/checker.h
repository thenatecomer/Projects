/* Copyright CSCI 3081W Fall 2016 Group Bo3 All rights reserved
   Author: Qing Yang, Cong Sun (Connor)  */
#ifndef ITERATION_2_SRC_INCLUDE_CHECKER_H_
#define ITERATION_2_SRC_INCLUDE_CHECKER_H_
#include <stdlib.h>
#include "../src/include/tool.h"

namespace image_tools {

class Checker: public Tool {
 public:
  Checker();
  virtual ~Checker();
  void SetMask(int size);

  virtual void SetColor(float r, float g, float b, PixelBuffer *canvas);
};
}  // namespace image_tools

#endif  // ITERATION_2_SRC_INCLUDE_CHECKER_H_
