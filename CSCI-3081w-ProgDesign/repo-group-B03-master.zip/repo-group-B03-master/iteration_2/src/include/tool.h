/* Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
   Author: Nathan Comer, Qing Yang  */
#ifndef ITERATION_2_SRC_INCLUDE_TOOL_H_
#define ITERATION_2_SRC_INCLUDE_TOOL_H_
#include "../src/include/color_data.h"
#include "../src/include/pixel_buffer.h"


namespace image_tools {
#define MASK_SIZE 10
class Tool {
 public:
  Tool();
  // Default constructor create a mask with size 10

  virtual ~Tool();
  // Default desctructor free memory

  float** GetMask();
  // Getter function to return current mask

  virtual void ApplyTool(int x, int y, PixelBuffer *pixel, ColorData bg_color);
  // Default ApplyTool function to apply specified
  // color into the mask at the specified pixel

  virtual void SetColor(float r, float g, float b, PixelBuffer *canvas);

  // void ScaleMask (float scaleX, float scaleY);
  // Delet the previous the mask, then scale
  // the new one based on the original one

  void Interpolate(int x, int y, PixelBuffer *pixel, ColorData bg_color);

  void StoreDragEvent(int x, int y);

  void ResetDragEvent();

  void SetDragEvent();

 protected:
  int mask_size_;  // Use mask_size_, keep mask as square
  float** mask;
  int toolid_;
  ColorData cur_color_;

 private:
  double previous_x_;
  double previous_y_;
};
}  // namespace image_tools
#endif  // ITERATION_2_SRC_INCLUDE_TOOL_H_
