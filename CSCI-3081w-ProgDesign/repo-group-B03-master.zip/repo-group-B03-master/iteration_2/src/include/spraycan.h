/* Copyright CSCI 3081W Fall 2016 Group Bo3 All rights reserved
   Author: Qing Yang, Cong Sun (Connor)  */
#ifndef ITERATION_2_SRC_INCLUDE_SPRAYCAN_H_
#define ITERATION_2_SRC_INCLUDE_SPRAYCAN_H_
#include "../src/include/tool.h"
namespace image_tools {
class SprayCan: public Tool {
 public:
  SprayCan();
  virtual ~SprayCan();
  void SetMask(int size);
};
}  // namespace image_tools
#endif  // ITERATION_2_SRC_INCLUDE_SPRAYCAN_H_
