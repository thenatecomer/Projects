// Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
// Author: Nathan Comer

#ifndef ITERATION_2_SRC_INCLUDE_FILTER_H_
#define ITERATION_2_SRC_INCLUDE_FILTER_H_
#include <cmath>
#include <iostream>
#include "../src/include/tool.h"
#include "../src/include/color_data.h"
#include "../src/include/filter_kernel.h"
#include "../src/include/filter_effects.h"
#include "../src/include/pixel_buffer.h"

using std::cout;
using std::endl;

namespace image_tools {
class Filter {
 public:
  Filter();

  void ApplyFilter(PixelBuffer* pixel, glui_arguments* glui_argument);

  void SetKernel(int kernel_id);

  void SetKernel(void);

  void SetEffect(ColorData (*e_f)(ColorData, glui_arguments* glui_argument));

  glui_arguments GetArguments(void);

 private:
  int kernel_size_;
  int filter_id_;
  int kernel_id_;
  ColorData (*filter_effect_)(ColorData, glui_arguments*);
  float** filter_kernel_;
};
}  // namespace image_tools
#endif  // ITERATION_2_SRC_INCLUDE_FILTER_H_
