/* Copyright CSCI 3081W Fall 2016 Group Bo3 All rights reserved
   Author: Qing Yang */
#ifndef ITERATION_2_SRC_INCLUDE_STAMP_H_
#define ITERATION_2_SRC_INCLUDE_STAMP_H_
#include "../src/include/tool.h"
#include "../src/include/color_data.h"
#include "../src/include/pixel_buffer.h"
namespace image_tools {

class Stamp: public Tool {
 public:
  explicit Stamp(PixelBuffer* stamp_input_);
  virtual ~Stamp();
  void SetMask(int size);
  void SetMask(int width, int height);

  void ApplyTool(int x, int y, PixelBuffer *pixel, ColorData bg_color);

 private:
  PixelBuffer *stamp_;
};
}  // namespace image_tools
#endif  // ITERATION_2_SRC_INCLUDE_STAMP_H_
