/* Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
 * Author: Jonathan Lehne, Qing Yang */
#ifndef ITERATION_2_SRC_INCLUDE_JPG_MANAGER_H_
#define ITERATION_2_SRC_INCLUDE_JPG_MANAGER_H_
#include "include/pixel_buffer.h"
#include "include/color_data.h"

/*******************************************************************************
 * Namespaces
 ******************************************************************************/
namespace image_tools {

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/	
class JpgManager {
 public:
  PixelBuffer* read_JPEG_file(char* name, PixelBuffer* buffer);
  void write_JPEG_file(char* name, PixelBuffer* buffer);
};
}  // namespace image_tools
#endif  // ITERATION_2_SRC_INCLUDE_JPG_MANAGER_H_"
