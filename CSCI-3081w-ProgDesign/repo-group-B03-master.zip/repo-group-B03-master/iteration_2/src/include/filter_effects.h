/* Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
   Author: Nathan Comer  */

#ifndef ITERATION_2_SRC_INCLUDE_FILTER_EFFECTS_H_
#define ITERATION_2_SRC_INCLUDE_FILTER_EFFECTS_H_


namespace image_tools {
struct glui_arguments {
  float glui_value;
  float glui_value_red;
  float glui_value_green;
  float glui_value_blue;
  int glui_direction;
  int glui_size = 1;
};

class FilterEffects {
 public:
  FilterEffects();

  typedef ColorData (*effec_func)(ColorData, glui_arguments*);

  static effec_func GetEffect(int effect_id);
  static effec_func GetEffect(void);

  static ColorData NoEffect(ColorData color,
    glui_arguments* filter_arguments);

  static ColorData ThresholdEffect(ColorData color,
    glui_arguments* filter_arguments);

  static ColorData SaturationEffect(ColorData color,
    glui_arguments* filter_arguments);

  static ColorData RGBEffect(ColorData color,
    glui_arguments* filter_arguments);

  static ColorData QuantizeEffect(ColorData color,
    glui_arguments* filter_arguments);

  static ColorData EmbossEffect(ColorData color,
    glui_arguments* filter_arguments);

 private:
};
}  // namespace image_tools
#endif  // ITERATION_2_SRC_INCLUDE_FILTER_EFFECTS_H_
