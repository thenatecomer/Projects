/*******************************************************************************
 * Name            : state_implementation.h
 * Project         : FlashPhoto
 * Module          : App
 * Description     : Header file for StateImplementation class
 * Copyright       : 2016 CSCI3081W GROUP B03
 * Creation Date   : 11/13/2016
 * Original Author : Jonathan Lehne
 ******************************************************************************/
#ifndef ITERATION_2_SRC_INCLUDE_STATE_IMPLEMENTATION_H_
#define ITERATION_2_SRC_INCLUDE_STATE_IMPLEMENTATION_H_
#include "../src/include/pixel_buffer.h"
/*******************************************************************************
 * Namespaces
 ******************************************************************************/
namespace image_tools {

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
class StateImplementation{
 public:
  StateImplementation(void);
  virtual ~StateImplementation(void);
  virtual void InitState(PixelBuffer* canvas_ptr) = 0;
  virtual void get_previous_state(PixelBuffer* canvas_ptr_adr) = 0;
  virtual void get_previous_undo(PixelBuffer* canvas_ptr_adr) = 0;
  virtual void add_previous_state(PixelBuffer* canvas_ptr) = 0;
  virtual void add_previous_undo(PixelBuffer* canvas_ptr) = 0;
};
}  // namespace image_tools
#endif  // ITERATION_2_SRC_INCLUDE_STATE_IMPLEMENTATION_H_
