/* Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
   Author: Nathan Comer  */
#ifndef ITERATION_2_SRC_INCLUDE_FILTER_KERNEL_H_
#define ITERATION_2_SRC_INCLUDE_FILTER_KERNEL_H_
#include "../src/include/color_data.h"
#include "../src/include/pixel_buffer.h"
#include "../src/include/filter_effects.h"
#include "../src/include/filter.h"


namespace image_tools {

class FilterKernel {
 public:
  FilterKernel();

  static float** GetKernel(int filter_id, glui_arguments* arguments);

  static float** EdgeDetectionFilter(int scale, float amount);

  static float** SharpenFilter(int scale, float amount);

  static float** BlurFilter(int scale, float amount);

  static float** MotionBlurFilter(int scale, int dirction, float amount);

  static float** EmbossFilter(int scale, float amount);

  static float** DefaultFilter();
};
}  // namespace image_tools
#endif  // ITERATION_2_SRC_INCLUDE_FILTER_KERNEL_H_
