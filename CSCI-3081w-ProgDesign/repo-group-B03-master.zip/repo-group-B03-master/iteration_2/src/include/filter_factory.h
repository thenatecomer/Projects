/* Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
   Author: Nathan Comer  */
#ifndef ITERATION_2_SRC_INCLUDE_FILTER_FACTORY_H_
#define ITERATION_2_SRC_INCLUDE_FILTER_FACTORY_H_


#include <vector>
#include "../src/include/filter.h"
#include "../src/include/filter_effects.h"


namespace image_tools {

class FilterFactory {
 public:
  static Filter* CreateFilter(int filter_id);

  enum FILTERS {
    FILTER_BLUR = 0,
    FILTER_MOTION_BLUR = 1,
    FILTER_SHARPEN = 2,
    FILTER_EDGE_DETECTION = 3,
    FILTER_THRESHOLD = 4,
    FILTER_SATURATION = 5,
    FILTER_CHANNELS = 6,
    FILTER_QUANTIZE = 7,
    FILTER_SPECIAL = 8,
    NUMFILTERS = 9
  };

  static int num_filters(void) {
    return NUMFILTERS;
  }
};
}  /* namespace image_tools */
#endif  /* ITERATION_2_SRC_INCLUDE_FILTER_FACTORY_H_ */
