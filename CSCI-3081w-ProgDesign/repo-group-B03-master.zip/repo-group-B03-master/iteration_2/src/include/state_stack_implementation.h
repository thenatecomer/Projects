/*******************************************************************************
 * Name            : state_stack_implementation.h
 * Project         : FlashPhoto
 * Module          : state_manager
 * Description     : Header file for StateStackImplementation class
 * Copyright       : 2016 CSCI3081W GROUP B03
 * Creation Date   : 11/13/2016
 * Original Author : Jonathan Lehne
 ******************************************************************************/
#ifndef ITERATION_2_SRC_INCLUDE_STATE_STACK_IMPLEMENTATION_H_
#define ITERATION_2_SRC_INCLUDE_STATE_STACK_IMPLEMENTATION_H_
#include "../src/include/state_implementation.h"
/*******************************************************************************
 * Namespaces
 ******************************************************************************/
namespace image_tools {

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
class StateStackImplementation : public StateImplementation {
 public:
  explicit StateStackImplementation(int stack_sz);
  ~StateStackImplementation(void);

  void InitState(PixelBuffer* canvas_ptr);
  void get_previous_state(PixelBuffer* canvas_ptr_adr);
  void get_previous_undo(PixelBuffer* canvas_ptr_adr);
  void add_previous_state(PixelBuffer* canvas_ptr);
  void add_previous_undo(PixelBuffer* canvas_ptr);

 private:
  int stack_size_;
  int undo_top_;
  int undo_bottom_;
  int redo_top_;
  int redo_bottom_;
  bool full_stack_;
  PixelBuffer **undo_ptr_stack_;
};
}  // namespace image_tools
#endif  // ITERATION_2_SRC_INCLUDE_STATE_STACK_IMPLEMENTATION_H_
