// Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
// Author: Qing Yang
#ifndef ITERATION_2_SRC_INCLUDE_PNG_MANAGER_H_
#define ITERATION_2_SRC_INCLUDE_PNG_MANAGER_H_
#include "include/pixel_buffer.h"
#include "include/color_data.h"

/*******************************************************************************
 * Namespaces
 ******************************************************************************/
namespace image_tools {

/*******************************************************************************
 * Class Definitions
 ******************************************************************************/
class PngManager {
 public:
  PixelBuffer* read_PNG_file(char* name, PixelBuffer* buffer);
  void write_PNG_file(char* name, PixelBuffer* buffer);
};
}  /* namespace image_tools */
#endif  // ITERATION_2_SRC_INCLUDE_PNG_MANAGER_H_
