// Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
// Author: Nathan Comer
#include "../src/include/filter.h"
#include <cmath>
#include <iostream>
#include "../src/include/tool.h"
#include "../src/include/filter_kernel.h"
#include "../src/include/filter_effects.h"
#include "../src/include/pixel_buffer.h"

using std::cout;
using std::endl;
namespace image_tools {

  Filter::Filter() {
    this->SetEffect(FilterEffects::GetEffect());
    this->SetKernel();
  }

  /**
   * Sets the id of the kernel that will be used when applying the filter
   **/

  void Filter::SetKernel(int kernel_id) {
    kernel_id_ = kernel_id;
  }

  /**
   * Sets that no kernel should be used for the filter
   **/

  void Filter::SetKernel(void) {
    kernel_id_ = -1;
    kernel_size_ = 1;
  }

  /**
   * Sets which effect should be used when applying the filter
   **/

  void Filter::SetEffect(ColorData(*e_f)
  (ColorData, glui_arguments* glui_argument)) {
    filter_effect_ = e_f;
  }

  /**
   * Applies the filter to the canvas using:
   * -The effect function pointed to by filter_effect_
   * -The kernel with id: kernel_id_
   **/

  void Filter::ApplyFilter(PixelBuffer* pixel, glui_arguments* glui_arg) {
    filter_kernel_ = FilterKernel::GetKernel(kernel_id_, glui_arg);
    std::cout << "Printing Kernel:"<< std::endl;
    int size = glui_arg->glui_size;
    for (int n = 0; n < size; n++) {
      for (int m = 0; m < size; m++) {
        std::cout << " " << filter_kernel_[n][m];
      }
      std::cout << std::endl;
    }

    ColorData color_accumulator = ColorData(0, 0, 0);
    PixelBuffer* temp = new PixelBuffer(*pixel);
    PixelBuffer temp_pixel_buffer = (*temp);

    int canvas_width = (*pixel).width();
    int canvas_height = (*pixel).height();

    int filter_width = glui_arg->glui_size;
    int filter_height = glui_arg->glui_size;

    for (int canvas_x = 0; canvas_x < canvas_width; canvas_x++) {
      for (int canvas_y = 0; canvas_y < canvas_height; canvas_y++) {
        color_accumulator = ColorData(0, 0, 0, 0);
        int start_x = (canvas_x-((filter_width - 1) / 2)) < 0? -
        (canvas_x) + ((filter_width - 1) / 2) : 0;
        int start_y = (canvas_y - ((filter_height - 1) / 2)) < 0? -
        (canvas_y) + ((filter_height - 1) / 2) : 0;
        int end_x = (canvas_x + ((filter_width - 1) / 2)) >=
        canvas_width?filter_width - (canvas_x + ((filter_width - 1) / 2) -
        canvas_width) - 3 : filter_width;
        int end_y = (canvas_y + ((filter_height - 1) / 2)) >=
        canvas_height?filter_height - (canvas_y + ((filter_height - 1) / 2) -
        canvas_height) - 3 : filter_height;
        for (int filter_x = start_x; filter_x < end_x; filter_x++) {
          for (int filter_y = start_y; filter_y < end_y; filter_y++) {
            color_accumulator = color_accumulator +
            (temp_pixel_buffer.get_pixel(canvas_x - ((filter_width - 1) / 2) +
            filter_x, canvas_y - ((filter_height - 1) / 2) + filter_y) *
            static_cast<float>(filter_kernel_[filter_x][filter_y]));
          }
        }
        color_accumulator = filter_effect_(color_accumulator, glui_arg);
        // color_accumulator.alpha(1.0);
        (*pixel).set_pixel(canvas_x, canvas_y, color_accumulator);
      }
    }
    std::cout << "Finished applying the filter!"<< std::endl;
  }
}  // namespace image_tools
