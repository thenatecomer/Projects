/* Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
   Author: Nathan Comer  */
#include "../src/include/filter_factory.h"
#include <cmath>
#include <iostream>
#include "../src/include/flashphoto_app.h"
#include "../src/include/filter.h"
#include "../src/include/filter_effects.h"


using std::cout;
using std::endl;
namespace image_tools {

Filter* FilterFactory::CreateFilter(int filter_id) {
    Filter* filter;
    filter = new Filter();
    
    /**
     * SetKernel(kernel_id)
     * kernel_id table:
     * 0: Blur Kernel
     * 1: Motion Blur Kernel
     * 2: Sharpen Kernel
     * 3: Edge Detection Kernel
     * 
     * SetEffect(FilterEffects::GetEffect(effect_id))
     * effect_id table:
     * 4: Threshold Effect
     * 5: Saturation Effect
     * 6: Channels Effect
     * 7: Quantize Effect
     **/

    switch (filter_id) {
      case 0:  /// FILTER_BLUR:
        (*filter).SetKernel(0);
        break;
      case 1:  /// FILTER_MOTION_BLUR:
        (*filter).SetKernel(1);
        break;
      case 2:  /// FILTER_SHARPEN:
        (*filter).SetKernel(2);
        break;
      case 3:  /// FILTER_EDGE_DETECTION:
        (*filter).SetKernel(3);
        break;
      case 4:  /// FILTER_THRESHOLD:
        (*filter).SetEffect(FilterEffects::GetEffect(4));
        break;
      case 5:  /// FILTER_SATURATION:
        (*filter).SetEffect(FilterEffects::GetEffect(5));
        break;
      case 6:  /// FILTER_CHANNELS:
        (*filter).SetEffect(FilterEffects::GetEffect(6));
        break;
      case 7:  /// FILTER_QUANTIZE:
        (*filter).SetEffect(FilterEffects::GetEffect(7));
        break;
      case 8:  /// FILTER_SPECIAL:
        (*filter).SetEffect(FilterEffects::GetEffect(8));
        (*filter).SetKernel(4);
        break;
      default:  /// FILTER_DEFAULT:
        (*filter).SetEffect(FilterEffects::GetEffect());
        (*filter).SetKernel();
        break;
    }
    return filter;
  }
}  // namespace image_tools
