// Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
// Author: Jonathan Lehne, Qing Yang
#include "../src/include/jpg_manager.h"
#include <setjmp.h>
#include <stdio.h>
#include <string.h>
#include <stddef.h>
#include <stdlib.h>
#include <iostream>
#include <cstdlib>
#include <cmath>
#include "../ext/lib/include/jpeglib.h"
#include "../ext/lib/include/jconfig.h"
#include "../src/include/pixel_buffer.h"
#include "../src/include/color_data.h"

/*******************************************************************************
 * Namespaces
 ******************************************************************************/
namespace image_tools {
/*******************************************************************************
 * Member Functions
 ******************************************************************************/
PixelBuffer* JpgManager::read_JPEG_file(char* name, PixelBuffer* buffer) {
  unsigned char *raw_image = NULL;
  struct jpeg_decompress_struct cinfo;
  struct jpeg_error_mgr jerr;
  JSAMPROW row_pointer[1];
  int row_stride;
  FILE *infile;
  if ((infile = fopen(name, "rb")) == NULL) {
    fprintf(stderr, "can't open %s\n", name);
    exit(1);
  }

  uint64_t location = 0;
  cinfo.err = jpeg_std_error(&jerr);
  // setup decompression process and source, then read JPEG header
  jpeg_create_decompress(&cinfo);
  // this makes the library read from infile
  jpeg_stdio_src(&cinfo, infile);
  // reading the image header which contains image information
  (void) jpeg_read_header(&cinfo, TRUE);

  // Start decompression jpeg here
  (void) jpeg_start_decompress(&cinfo);

  // now actually read the jpeg into the raw buffer
  raw_image = new unsigned char
    [cinfo.output_width*cinfo.output_height*cinfo.num_components];
  row_pointer[0] = new unsigned char[cinfo.output_width*cinfo.num_components];

  // read one scan line at a time
  while (cinfo.output_scanline < cinfo.output_height) {
    (void) jpeg_read_scanlines(&cinfo, row_pointer, 1);
    for (int jpg_width=0;
    jpg_width < cinfo.image_width*cinfo.num_components; jpg_width++)
      raw_image[location++] = row_pointer[0][jpg_width];
    }

    /*initialize a new displayBuffer using image size (cinfo.image_width, cinfo.image_height, ColorData(1,1,0.95));
     * red the information of each pixel of the image and convert it to ColorData type we have
     * get red, green and blue color and divide by 255
    */

    (void) jpeg_finish_decompress(&cinfo);
    PixelBuffer *m_new_displayBuffer = new PixelBuffer
      (cinfo.image_width, cinfo.image_height, ColorData(1, 1, 0.95));
    for (int jpg_height = 0; jpg_height < cinfo.image_height; jpg_height++) {
      for (int jpg_width=0; jpg_width < cinfo.image_width; jpg_width++) {
        float R = static_cast<float>(raw_image[
    (jpg_height*cinfo.image_width*3)+(jpg_width*3)+0])/255.0;  // Red Pixel
        float G = static_cast<float>(raw_image[
    (jpg_height*cinfo.image_width*3)+(jpg_width*3)+1])/255.0;  // Green Pixel
        float B = static_cast<float>(raw_image[
    (jpg_height*cinfo.image_width*3)+(jpg_width*3)+2])/255.0;  // Blue Pixel
        int row_offset = 0;
        // apply the each pixel to the new buffer
        m_new_displayBuffer->set_pixel
        (jpg_width, cinfo.image_height - jpg_height -1, ColorData(R, G, B));
        }
    }

    /*change the size of current canvas
     *delete old displayBuffer
     *replace with the new displayBuffer we create
     *using the function setWindowDimensions to set the canvas size same as the image size
    */
    // delete buffer;
    // buffer = m_new_displayBuffer;

    // destroy objects, free pointers and close open files
    buffer->~PixelBuffer();
    jpeg_destroy_decompress(&cinfo);
    delete [] row_pointer[0];
    delete [] raw_image;
    fclose(infile);
    return m_new_displayBuffer;
}


void JpgManager::write_JPEG_file(char* name, PixelBuffer* buffer) {
  struct jpeg_compress_struct cinfo;
  struct jpeg_error_mgr jerr;

  unsigned char *raw_image = NULL;
  JSAMPROW row_pointer[1];  // pointer to JSAMPLE row[s]

  cinfo.err = jpeg_std_error(&jerr);
  jpeg_create_compress(&cinfo);

  FILE * outfile;  // target file
  if ((outfile = fopen(name, "wb")) == NULL) {
    fprintf(stderr, "can't open %s\n", name);
    exit(1);
  }
  jpeg_stdio_dest(&cinfo, outfile);

  cinfo.image_width = buffer->width();     // image width and height, in pixels
  cinfo.image_height = buffer->height();
  cinfo.input_components = 3;              // # of color components per pixel
  cinfo.in_color_space = JCS_RGB;          // colorspace of input image

  jpeg_set_defaults(&cinfo);
  // jpeg_set_quality(&cinfo, 100, TRUE);
  // cinfo.dct_method = JDCT_FLOAT;
  jpeg_start_compress(&cinfo, TRUE);

  raw_image = new unsigned char[cinfo.image_width*cinfo.image_height*
                               cinfo.num_components];
  ColorData pixelinfo;
  int offset;
  for (int jpg_height=0; jpg_height < cinfo.image_height; jpg_height++) {
    for (int jpg_width=0; jpg_width < cinfo.image_width; jpg_width++) {
      offset = (jpg_height * cinfo.image_width * 3) + (jpg_width * 3);
      pixelinfo = buffer->get_pixel(jpg_width,
    cinfo.image_height - jpg_height -1);
      pixelinfo = pixelinfo.clamped_color();
      raw_image[offset+0] = (pixelinfo.red()*255.0);
      raw_image[offset+1] = (pixelinfo.green()*255.0);
      raw_image[offset+2] = (pixelinfo.blue()*255.0);
      }
  }
    while (cinfo.next_scanline < cinfo.image_height) {
      row_pointer[0] = &raw_image[cinfo.next_scanline * cinfo.image_width * 3];
      (void) jpeg_write_scanlines(&cinfo, row_pointer, 1);
    }

    jpeg_finish_compress(&cinfo);
    fclose(outfile);
    jpeg_destroy_compress(&cinfo);
    free(raw_image);
}
}  // namespace image_tools
