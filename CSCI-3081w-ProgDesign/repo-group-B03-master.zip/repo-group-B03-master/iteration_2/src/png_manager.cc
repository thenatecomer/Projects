// Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
// Author: Qing Yang, Jonathan Lehne
#include "../src/include/png_manager.h"
#include <stdio.h>
#include <png.h>
#include <setjmp.h>
#include <zlib.h>
#include <string.h>
#include <stddef.h>
#include <stdlib.h>
#include <iostream>
#include <cstdlib>
#include <cmath>
#include "../src/include/pixel_buffer.h"
#include "../src/include/color_data.h"
#include "../ext/lib/include/jconfig.h"

/*******************************************************************************
 * Namespaces
 ******************************************************************************/
namespace image_tools {
/*******************************************************************************
 * Member Functions
 ******************************************************************************/
PixelBuffer* PngManager::read_PNG_file(char* name, PixelBuffer* buffer) {
  int width, height;
  png_byte color_type;
  png_byte bit_depth;
  png_bytep *row_pointers;

  FILE *infile;
    if ((infile = fopen(name, "rb")) == NULL) {
      fprintf(stderr, "can't open %s\n", name);
      exit(1);
    }
  std::cout << "Before png struct"<< std::endl;
  png_structp png = png_create_read_struct
    (PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
  if (!png)
    abort();

  png_infop info = png_create_info_struct(png);
  if (!info)
    abort();

  if  (setjmp(png_jmpbuf(png))) abort();
  // std::cout << "Before png init_io"<< std::endl;
  png_init_io(png, infile);
  // std::cout << "Before png read"<< std::endl;
  png_read_info(png, info);

  width = png_get_image_width(png, info);
  height = png_get_image_height(png, info);
  color_type = png_get_color_type(png, info);
  bit_depth  = png_get_bit_depth(png, info);

  if (bit_depth == 16)
    png_set_strip_16(png);

  if (color_type == PNG_COLOR_TYPE_PALETTE)
    png_set_palette_to_rgb(png);

  // PNG_COLOR_TYPE_GRAY_ALPHA is always 8 or 16bit depth.
  if (color_type == PNG_COLOR_TYPE_GRAY && bit_depth < 8)
    png_set_expand_gray_1_2_4_to_8(png);

  if (png_get_valid(png, info, PNG_INFO_tRNS))
    png_set_tRNS_to_alpha(png);

  // These color_type don't have an alpha channel then fill it with 0xff.
  if (color_type == PNG_COLOR_TYPE_RGB ||
    color_type == PNG_COLOR_TYPE_GRAY ||
    color_type == PNG_COLOR_TYPE_PALETTE)
      png_set_filler(png, 0xFF, PNG_FILLER_AFTER);

  if (color_type == PNG_COLOR_TYPE_GRAY ||
    color_type == PNG_COLOR_TYPE_GRAY_ALPHA)
      png_set_gray_to_rgb(png);

  png_read_update_info(png, info);

  // Modified it to c++ memory allocation
  row_pointers = new png_bytep[height];
  for (int png_height = 0; png_height < height; png_height++) {
    row_pointers[png_height]
      = new png_byte[png_get_rowbytes(png, info)/sizeof(png_byte)];
  }
  png_read_image(png, row_pointers);
  PixelBuffer* m_new_displaybuffer
    = new PixelBuffer(width, height, (*buffer).background_color());
  for (int png_height=0; png_height < height; png_height++) {
    for (int png_width=0; png_width < width; png_width++) {
    // loop through every pixel in the canvas
      float R = static_cast<float>
        (row_pointers[png_height][(png_width * 4) + 0] / 255.0);
      float G = static_cast<float>
        (row_pointers[png_height][(png_width * 4) + 1] / 255.0);
      float B = static_cast<float>
        (row_pointers[png_height][(png_width * 4) + 2] / 255.0);
      float A = static_cast<float>
        (row_pointers[png_height][(png_width * 4) + 3] / 255.0);

      // apply the color by multiple the alpha value
      m_new_displaybuffer->set_pixel
        (png_width, height - png_height -1, ColorData(R, G, B, A));
    }
  }
  for (int png_height = 0; png_height < height; png_height++) {
    free(row_pointers[png_height]);
  }
  // Destroy old memory to prevent memory leaks!
  buffer->~PixelBuffer();
  delete [] row_pointers;
  fclose(infile);
  // free(row_pointers);
  return m_new_displaybuffer;
}

void PngManager::write_PNG_file(char* name, PixelBuffer* buffer) {
  FILE *output;
  png_structp png_ptr = NULL;
  png_infop info_ptr = NULL;
  png_bytep *row_pointers;
  int m_width =  buffer->width();
  int m_height = buffer->height();
  output = fopen(name, "wb");

  if (output == NULL) {
    fprintf(stderr, "Could not open file for writing");
    exit(1);
  }
  // Initialize write structure
  png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
  if (png_ptr == NULL) {
    fprintf(stderr, "Could not allocate write struct\n");
    exit(1);
  }

  // Initialize info structure
  info_ptr = png_create_info_struct(png_ptr);
  if (info_ptr == NULL) {
    fprintf(stderr, "Could not allocate info struct\n");
    exit(1);
  }

  // Setup Exception handling
  if (setjmp(png_jmpbuf(png_ptr))) {
    fprintf(stderr, "Error during png creation\n");
    exit(1);
  }

  png_init_io(png_ptr, output);

  // Write header (8 bit colour depth)

  png_set_IHDR(png_ptr, info_ptr,
    m_width, m_height,
    8, PNG_COLOR_TYPE_RGB_ALPHA,
    PNG_INTERLACE_NONE,
    PNG_COMPRESSION_TYPE_BASE,
    PNG_FILTER_TYPE_BASE);

  png_write_info(png_ptr, info_ptr);


  row_pointers = new png_bytep[m_height];

  for (int png_height = 0; png_height < m_height; png_height++) {
    row_pointers[png_height] = new png_byte[m_width*4];
  // Write image data
  }


  for (int png_height=0 ; png_height< m_height ; png_height++) {
    for (int png_width=0 ; png_width< m_width ; png_width++) {
      ColorData pixelinfo
        = buffer->get_pixel(png_width, m_height - png_height -1);
      pixelinfo = pixelinfo.clamped_color();
      row_pointers[png_height][(png_width*4)+0]
        = (png_byte)(pixelinfo.red()*255.0);
      row_pointers[png_height][(png_width*4)+1]
        = (png_byte)(pixelinfo.green()*255.0);
      row_pointers[png_height][(png_width*4)+2]
        = (png_byte)(pixelinfo.blue()*255.0);
      row_pointers[png_height][(png_width*4)+3]
        = (png_byte)(pixelinfo.alpha()*255.0);
    }
  }

  png_write_image(png_ptr, row_pointers);
  // End write

  for (int png_height = 0; png_height < m_height; png_height++) {
    free(row_pointers[png_height]);
  }
  free(row_pointers);
  fclose(output);
  //  png_write_end(png_ptr, NULL);
}
}  /* namespace image_tools */
