/*******************************************************************************
 * Name            : state_manager.cc
 * Project         : FlashPhoto
 * Module          : state_manager
 * Description     : Implementation of StateManager class
 * Copyright       : 2016 CSCI3081W TAs. All rights reserved.
 * Creation Date   : Sun Oct 2 20:47:05 2016
 * Original Author : jharwell
 * Editing Authors : Qing Yang Jonathan Lehne
 *
 ******************************************************************************/

/*******************************************************************************
 * Includes
 ******************************************************************************/
#include "../src/include/state_manager.h"
#include <iostream>
#include "../src/include/ui_ctrl.h"

/*******************************************************************************
 * Namespaces
 ******************************************************************************/
namespace image_tools {

/*******************************************************************************
 * Constructors/Destructor
 ******************************************************************************/
StateManager::StateManager(void) :
    undo_btn_(nullptr),
    redo_btn_(nullptr),
    state_impl_(nullptr) {
}

/*******************************************************************************
 * Member Functions
 ******************************************************************************/
void StateManager::InitGlui(const GLUI *const glui,
                            void (*s_gluicallback)(int)) {
  undo_btn_ = new GLUI_Button(const_cast<GLUI*>(glui), "Undo", UICtrl::UI_UNDO,
                              s_gluicallback);
  undo_toggle(true);

  redo_btn_  = new GLUI_Button(const_cast<GLUI*>(glui), "Redo", UICtrl::UI_REDO,
                               s_gluicallback);
  redo_toggle(true);
}

void StateManager::UndoOperation(PixelBuffer* display_buf) {
  state_impl_->get_previous_state(display_buf);
}

void StateManager::RedoOperation(PixelBuffer* display_buf) {
  state_impl_->get_previous_undo(display_buf);
}

void StateManager::AddOperation(PixelBuffer* display_buf) {
  state_impl_->add_previous_state(display_buf);
}
/// Create our snapshot holder for undoing and redoing
void StateManager::InitStateHolder(PixelBuffer* display_buf) {
  state_impl_ = new StateStackImplementation(51);
  state_impl_->InitState(display_buf);
}
/** To allow for loading of new canvas without having
 *  memory leaks we must delete our state holder entirely */
void StateManager::CleanStateHolder(void) {
  delete state_impl_;
}

}  /* namespace image_tools */
