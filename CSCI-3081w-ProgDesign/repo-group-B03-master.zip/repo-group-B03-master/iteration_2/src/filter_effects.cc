/* Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
   Author: Nathan Comer, Qing Yang  */
#include <cmath>
#include <iostream>
#include "../src/include/flashphoto_app.h"
#include "../src/include/color_data.h"

using std::cout;
using std::endl;
namespace image_tools {

/**
 * Defines effec_func to be a pointer to a pixel-independent effect
 **/
 
  typedef ColorData (*effec_func)(ColorData, glui_arguments* glui_arguments);

/**
 * Returns the pointer corresponding to effect indicated by the effect_id
 **/
 
  effec_func FilterEffects::GetEffect(int effect_id) {
    switch (effect_id) {
      case 4:  /// Threshold effect
          std::cout << "initializing threshold effect" << std::endl;
        return FilterEffects::ThresholdEffect;
        break;
      case 5:  /// Saturation effect
          std::cout << "initializing saturation effect" << std::endl;
        return FilterEffects::SaturationEffect;
        break;
      case 6:  /// Channels effect
          std::cout << "initializing rgb effect" << std::endl;
        return FilterEffects::RGBEffect;
        break;
      case 7:  /// Quantize effect
          std::cout << "initializing quantize effect" << std::endl;
        return FilterEffects::QuantizeEffect;
        break;
      case 8:
        return FilterEffects::EmbossEffect;
        break;
    }
    return FilterEffects::NoEffect;
}

effec_func FilterEffects::GetEffect(void) {
  return FilterEffects::NoEffect;
}

/**
 * NoEffect, to be used by filters with no pixel-independent effect, such as convolution filters
 **/
 
ColorData FilterEffects::NoEffect
(ColorData color, glui_arguments* filter_arguments) {
  return color;
}

ColorData FilterEffects::ThresholdEffect
(ColorData color, glui_arguments* filter_arguments) {
  color.red(color.red() > (*filter_arguments).glui_value ? 1.0 : 0.0);
  color.green(color.green() > (*filter_arguments).glui_value ? 1.0 : 0.0);
  color.blue(color.blue() > (*filter_arguments).glui_value ? 1.0 : 0.0);
  return color;
}

ColorData FilterEffects::SaturationEffect
(ColorData color, glui_arguments* filter_arguments) {
  ColorData gray_scale = (ColorData(1, 1, 1) * color.luminance());
  ColorData rate = color - gray_scale;
  color = (rate * (*filter_arguments).glui_value) + gray_scale;
  return color;
}

ColorData FilterEffects::RGBEffect
(ColorData color, glui_arguments* filter_arguments) {
  color.red(color.red()*(*filter_arguments).glui_value_red);
  color.green(color.green()*(*filter_arguments).glui_value_green);
  color.blue(color.blue()*(*filter_arguments).glui_value_blue);
  return color;
}

ColorData FilterEffects::QuantizeEffect
(ColorData color, glui_arguments* filter_arguments) {
  int glui_v = static_cast<int>(((1/(*filter_arguments).glui_value)*255));
  color.red(((255 * color.red()) -
  (static_cast<float>(static_cast<int>(255 * color.red())%glui_v)))/255);
  color.green(((255 * color.green()) -
  (static_cast<float>(static_cast<int>(255 * color.green())%glui_v)))/255);
  color.blue(((255 * color.blue()) -
  (static_cast<float>(static_cast<int>(255 * color.blue())%glui_v)))/255);
  return color;
}

ColorData FilterEffects::EmbossEffect
(ColorData color, glui_arguments* filter_arguments) {
  color.red(1- color.red());
  color.green(1- color.green());
  color.blue(1- color.blue());
  return color;
}

}  // namespace image_tools
