/*******************************************************************************
 * Name            : state_stack_implementation.h
 * Project         : FlashPhoto
 * Module          : state_manager
 * Description     : Stack implementation of undoing and redoing
 *                   the top of the stack is the most recent state of the canvas,
 *                   and the "bottom" is the last reachable state. The "bottom"
 *                   of the stack can move around within the array so it must be
 *                   handled in those cases.
 * Copyright       : 2016 CSCI3081W GROUP B03
 * Creation Date   : 11/13/2016
 * Original Authors: Jonathan Lehne Qing Yang
 ******************************************************************************/
#include "../src/include/state_stack_implementation.h"
#include <iostream>
namespace image_tools {

/*******************************************************************************
 * Constructors/Destructor
 ******************************************************************************/

StateStackImplementation::StateStackImplementation(int stack_sz)
  : stack_size_(stack_sz),
    undo_top_(1),
    undo_bottom_(0),
    redo_bottom_(0),
    redo_top_(0),
    full_stack_(false)
    {}

StateStackImplementation::~StateStackImplementation(void) {
  for (int clean_ctr = 0; clean_ctr < stack_size_; clean_ctr++) {
    delete undo_ptr_stack_[clean_ctr];
  }
  free(undo_ptr_stack_);
}

/*******************************************************************************
 * Member Functions
 ******************************************************************************/
void StateStackImplementation::InitState(PixelBuffer *canvas_ptr) {
  undo_ptr_stack_ = new PixelBuffer*[50];
  /// Initialize an array of pixel buffer pointers to be treated as a stack
  for (int stk_itr = 0; stk_itr < stack_size_; stk_itr++) {
    undo_ptr_stack_[stk_itr] = new PixelBuffer(*canvas_ptr);
  }
}

/** The "bottom" of the stack has the ability to move around so these
 *  situations must be handled correctly
    A possible situation of the array
  bottom -> 5. Oldest reachable state
     top -> 4. New state to add
            3. Last saved state
            2. Older state
            1. Second oldest state
 */
void StateStackImplementation::get_previous_state(PixelBuffer* canvas_ptr) {
  undo_bottom_ = undo_bottom_ % stack_size_;
  /// logic to handle where the top of the stack is when undoing
  if ((undo_top_ == 0)  && (undo_bottom_ > 0)) {
    undo_top_ = stack_size_ - 1;
  } else if (undo_top_ == undo_bottom_) {
    *canvas_ptr = *undo_ptr_stack_[undo_top_];
    return;
  } else {
    undo_top_-= 1;
  }
  *canvas_ptr = *undo_ptr_stack_[undo_top_];
  redo_top_++;
}

/** Redoing is handleded by counting the amount of undos that have been done
 *  and allowing as many redo's as there have been undos
 */
void StateStackImplementation::get_previous_undo(PixelBuffer* canvas_ptr) {
  if (redo_top_ == 0) {
    return;
  } else {
    redo_top_--;
    undo_top_ += 1;
    if ((undo_top_ == stack_size_ && undo_bottom_ == 0) ||
         (undo_top_ == undo_bottom_)) {
      full_stack_ = true;
      undo_top_ = undo_top_ % stack_size_;
    }
    undo_top_ = undo_top_ % stack_size_;
    *canvas_ptr = *undo_ptr_stack_[undo_top_];
  }
}
/** The top and the bottom of that stack will be moved together if
 *  the stack is "full" (meaning there are stack_size_ reachable states)
 *  otherwise just the top will move
 */
void StateStackImplementation::add_previous_state(PixelBuffer* canvas_ptr) {
  undo_top_ = undo_top_ % stack_size_;
  undo_bottom_ = undo_bottom_ % stack_size_;

  if (full_stack_) {
    undo_bottom_++;
    undo_top_++;
  } else {
    undo_top_++;
  }
  undo_top_ = undo_top_ % stack_size_;
  redo_bottom_ = undo_top_;
  redo_top_ = 0;
  *(undo_ptr_stack_[undo_top_]) = *canvas_ptr;
  if (undo_top_ == undo_bottom_) {
    full_stack_ = true;
    undo_bottom_++;
  }
}
/** A function that may be usefull for other implementations but not
 *  necessary in this one
 */
void StateStackImplementation::add_previous_undo(PixelBuffer* canvas_ptr) {
}
}  // namespace image_tools
