/* Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
   Author: Qing Yang  */
#include "../src/include/stamp.h"
#include <iostream>
#include <cmath>
#include "../src/include/tool.h"

namespace image_tools {

Stamp::Stamp(PixelBuffer* stamp_input_) {
  // set the sqaure mask based on the size of the stamp
  SetMask((*stamp_input_).width(), (*stamp_input_).height());
  stamp_ = stamp_input_;
}

void Stamp::SetMask(int width, int height) {
  mask_size_ = fmax(width, height);

  mask = new float*[width];
  if (!mask) {
    fprintf(stderr, "Mask allocation error!");
    exit(EXIT_FAILURE);
  }

  for (int i = 0; i < width; i++) {
    if (!((mask[i] = new float[height]))) {
      fprintf(stderr, "Mask allocation error!");
      exit(EXIT_FAILURE);
    }
  }

  for (int i = 0; i < width; i++) {
    for (int j = 0; j < height; j++) {
      mask[i][j] = 1.0;
    }
  }
}

Stamp::~Stamp() {
  for (int i = 0; i < mask_size_; i++) {
    free(mask[i]);
  }
  free(mask);
}

void Stamp::ApplyTool(int x, int y,
PixelBuffer *pixel, ColorData bg_color) {
  // Need to ensure the mask is within the canvas range
  int i, j, width, height, bufferX, bufferY, curX, curY, stamp_X, stamp_Y;
  float intensity;
  ColorData tempColor;

  width = (*pixel).width();
  height = (*pixel).height();
  int stamp_width = (*stamp_).width();
  int stamp_height = (*stamp_).height();

  // Initialize bufferX and bufferY to the corner of the mask

  bufferX = x - (stamp_width/2) - 1;
  bufferY = y - (stamp_height/2) - 1;



  for (i = 0; i < stamp_width; i++) {
    for (j = 0; j <stamp_height; j++) {
      if ((i + bufferX > 0) && (j + bufferY > 0)
      && (i + bufferX < width) && (j + bufferY < height)) {
      // Extra steps to ensure the target pixel is within the canvas
        curX = bufferX + i;
        curY = height - bufferY - j;
        stamp_X = i;
        stamp_Y = stamp_height - j;
        if ((stamp_X < (*stamp_).width()) && (stamp_Y < (*stamp_).height())) {
          tempColor = (*stamp_).get_pixel(stamp_X, stamp_Y) *
          mask[i][j] * (*stamp_).get_pixel(stamp_X, stamp_Y).alpha();
          tempColor = tempColor + (*pixel).get_pixel(curX, curY)
          * (1 - (*stamp_).get_pixel(stamp_X, stamp_Y).alpha());
          (*pixel).set_pixel(curX, curY, tempColor);
        }
      }
    }
  }
}
}  // namespace image_tools
