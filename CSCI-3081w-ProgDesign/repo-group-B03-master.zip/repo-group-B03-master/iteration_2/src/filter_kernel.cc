/* Copyright CSCI 3081W Fall 2016 Group B03 All rights reserved.
   Author: Nathan Comer, Cong Sun (Connor), Qing Yang  */
#include "../src/include/filter_kernel.h"
#include <cmath>
#include <iostream>
#include "../src/include/flashphoto_app.h"
#include "../src/include/filter_effects.h"
#include "../src/include/filter.h"

using std::cout;
using std::endl;
namespace image_tools {

/**
 * Returns the kernel corresponding to filter_id
 * Uses the user input from glui_arguments* to generate kernels that apply varying effect intensities
 **/

float** FilterKernel::GetKernel(int filter_id, glui_arguments* arguments) {
    switch (filter_id) {
        case 0:  /// Blur Kernel
            return FilterKernel::BlurFilter((static_cast<int>
            ((arguments->glui_size-arguments->glui_size%2)/2)), 1);
            break;
        case 1:  /// Motion Blur Kernel
            return FilterKernel::MotionBlurFilter((static_cast<int>
            ((arguments->glui_size-arguments->glui_size%2)/2)),
            arguments->glui_direction, 1);
            break;
        case 2:  /// Sharpen Kernel
            return FilterKernel::SharpenFilter((static_cast<int>
            ((arguments->glui_size-arguments->glui_size%2)/2)),
            arguments->glui_value/5);
            break;
        case 3:  /// Edge Detection Kernel
            return FilterKernel::EdgeDetectionFilter((static_cast<int>
            ((arguments->glui_size-arguments->glui_size%2)/2)), .25);
            break;
        case 4:  /// Emboss
            return FilterKernel::EmbossFilter((static_cast<int>
            ((arguments->glui_size-arguments->glui_size%2)/2)),
            arguments->glui_value);
            break;
    }
    return FilterKernel::DefaultFilter();
}

/**
 * Returns the a kernel that will have no effect for filters that do not utilize a kernel
 **/

float** FilterKernel::DefaultFilter() {
  std::cout << "generating default kernel" << std::endl;
  float** kernel = new float*[1];
  kernel[0] = new float[1];
  kernel[0][0] = 1.0;
  return kernel;
}

float** FilterKernel::BlurFilter(int scale, float amount) {
  std::cout << "generating blur kernel" << std::endl;
    int size = scale * 2 + 1;
    int factor = size;
    float** kernel = new float*[size];
    if (!kernel) {
      fprintf(stderr, "kernel allocation error!");
      exit(EXIT_FAILURE);
    }

    for (int i = 0; i < size; i++) {
      if (!((kernel[i] = new float[size]))) {
        fprintf(stderr, "kernel allocation error!");
        exit(EXIT_FAILURE);
      }
    }

    for (int coef = size-2; coef > 0; coef -= 2) {
      factor = factor + 2 * coef;
    }

  for (int rowIndex = 0; rowIndex < size; rowIndex++) {
    for (int colIndex = 0; colIndex < size; colIndex++) {
      if(scale+1 > abs(rowIndex-scale) + abs(colIndex-scale)){
           kernel[rowIndex][colIndex] = 1.0 / factor;
      } else {
        kernel[rowIndex][colIndex] = 0;
      }
    }
  }
  std::cout << "Scale inside kernel creation: "
  << scale << " size variable: "<< size << std::endl;
  return kernel;
}

// for dirction 1 for N-S 2
//             2 for W-E 4
//             3 for NW-SE
//             4 for NE-SW
float** FilterKernel::MotionBlurFilter(int scale, int direction, float amount) {
  std::cout << "generating motion blur kernel" << std::endl;
  int size = scale * 2 + 1;
  int factor = size;
  float** kernel = new float*[size];
  if(size < 2){
    size = 1;
  }
  if (!kernel) {
    fprintf(stderr, "kernel allocation error!");
    exit(EXIT_FAILURE);
  }

  for (int i = 0; i < size; i++) {
    if (!((kernel[i] = new float[size]))) {
      fprintf(stderr, "kernel allocation error!");
      exit(EXIT_FAILURE);
    }
  }

  if(size < 2){
    kernel[0][0] = 1.0;
    return kernel;
  }

  for (int coef = size - 2; coef > 0; coef -= 2) {
      factor = factor + 2 * coef;
  }
  for (int rowIndex = 0; rowIndex < size; rowIndex++) {
      for (int colIndex = 0; colIndex < size; colIndex++) {
            kernel[rowIndex][colIndex] = 0;
      }
  }
  // N-S
  if (direction == 0) {
    for (int rowIndex = 0; rowIndex < size; rowIndex++)
      kernel[rowIndex][scale] = 1.0 / size;
  // W-E
  } else if (direction == 1) {
    for (int colIndex = 0; colIndex < size; colIndex++) {
      kernel[scale][colIndex] = 1.0 / size;
    }
  // NW-SE
  } else if (direction == 3) {
    for (int rowIndex = 0; rowIndex < size; rowIndex++) {
      for (int colIndex = 0; colIndex< size; colIndex++) {
        if (rowIndex == colIndex)
          kernel[rowIndex][colIndex] = 1.0 / size;
      }
    }
  // NE-SW
  } else if (direction == 2) {
    for (int rowIndex = 0; rowIndex < size; rowIndex++) {
      for (int colIndex = 0; colIndex < size; colIndex++) {
        if (rowIndex == (size - 1 - colIndex))
          kernel[rowIndex][colIndex] = 1.0 / size;
      }
    }
  // if there is no direction then will be as regular blurFileter
  } else {
    for (int rowIndex = 0; rowIndex < (size-1); rowIndex++) {
      for (int rowIndex = 0; rowIndex < size; rowIndex++) {
        for (int colIndex = 0; colIndex < size; colIndex++) {
          if (((rowIndex - scale) * (rowIndex - scale) + (colIndex - scale) *
             (colIndex - scale)) <= scale*scale)
              kernel[rowIndex][colIndex] = 1.0 / factor * amount;
          else
            kernel[rowIndex][colIndex] = 0;
        }
      }
    }
  }
    return kernel;
}

float** FilterKernel::EmbossFilter(int scale, float amount) {
      std::cout << "generating Emboss kernel" << std::endl;
  int size = scale * 2 + 1;
  float** kernel = new float*[size];
  if (!kernel) {
    fprintf(stderr, "kernel allocation error!");
    exit(EXIT_FAILURE);
  }

  for (int i = 0; i < size; i++) {
    if (!((kernel[i] = new float[size]))) {
      fprintf(stderr, "kernel allocation error!");
      exit(EXIT_FAILURE);
    }
  }

  for (int row_index = 0; row_index < size; row_index++) {
    for (int col_index = 0; col_index < size; col_index++) {
      if (row_index + col_index == size-1) {
        kernel[row_index][col_index] = 0.0;
      } else if (col_index + row_index < size) {
        kernel[row_index][col_index] = -.8*amount;
      } else {
        kernel[row_index][col_index] = 1.0*amount;
      }
    }
  }
  return kernel;
}

float** FilterKernel::EdgeDetectionFilter(int scale, float amount) {
  std::cout << "generating sharpen kernel" << std::endl;
  int size = scale * 2 + 1;
  float** kernel = new float*[size];
  if (!kernel) {
    fprintf(stderr, "kernel allocation error!");
    exit(EXIT_FAILURE);
  }

  for (int i = 0; i < size; i++) {
    if (!((kernel[i] = new float[size]))) {
      fprintf(stderr, "kernel allocation error!");
      exit(EXIT_FAILURE);
    }
  }
  for (int rowIndex = 0; rowIndex < size; rowIndex++) {
    for (int colIndex = 0; colIndex < size; colIndex++) {
      kernel[rowIndex][colIndex] = 1.0 * amount;
    }
  }
  kernel[scale][scale] = -(size * size -2) * amount;
  return kernel;
}

float** FilterKernel::SharpenFilter(int scale, float amount) {
  std::cout << "generating sharpen kernel" << std::endl;
  int size = scale * 2 + 1;
  int factor = size;
  float** kernel = new float*[size];
  if (!kernel) {
    fprintf(stderr, "kernel allocation error!");
    exit(EXIT_FAILURE);
  }

  for (int i = 0; i < size; i++) {
    if (!((kernel[i] = new float[size]))) {
      fprintf(stderr, "kernel allocation error!");
      exit(EXIT_FAILURE);
    }
  }
  int counter = 0;
  for (int rowIndex = 0; rowIndex < size; rowIndex++) {
    for (int colIndex = 0; colIndex < size; colIndex++) {
      kernel[rowIndex][colIndex] = 0;
    }
  }

  for (int rowIndex = 0; rowIndex < size; rowIndex++) {
    for (int colIndex = 0; colIndex < size; colIndex++) {
      if (rowIndex == 0 || colIndex == 0 ||
        rowIndex == size-1 || colIndex == size-1)
        kernel[rowIndex][colIndex] = amount*-1.0/8.0;
      }
  }

  for (int rowIndex = 0; rowIndex < size; rowIndex++) {
    for (int colIndex = 0; colIndex < size; colIndex++) {
      if (rowIndex == 1 || colIndex == 1 || rowIndex == size-2 ||
        colIndex == size-2) {
        if (kernel[rowIndex][colIndex] == 0) {
          kernel[rowIndex][colIndex] = amount * 2.0 / 8.0;
        }
          counter++;
      }
    }
  }
  kernel[scale][scale] = static_cast<float>(counter / 16.0);
  return kernel;
}
};  // namespace image_tools
